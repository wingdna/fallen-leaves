
import React, { useState, useEffect, createContext, useContext, ReactNode, useRef } from 'react';
import { Difficulty, SupportedLanguage } from '../types';

export interface GameSettings {
    language: SupportedLanguage;
    setLanguage: (lang: SupportedLanguage) => void;
    difficulty: Difficulty;
    setDifficulty: (diff: Difficulty) => void;
    oneClickPlay: boolean;
    setOneClickPlay: (enable: boolean) => void;
    isMuted: boolean;
    setIsMuted: (muted: boolean) => void;
    isRiskAlertOn: boolean;
    setIsRiskAlertOn: (on: boolean) => void;
    showSuitHistory: boolean;
    setShowSuitHistory: (show: boolean) => void;
    graphicsQuality: 'HIGH' | 'MEDIUM' | 'LOW';
    setGraphicsQuality: (quality: 'HIGH' | 'MEDIUM' | 'LOW') => void;
    githubAutoSync: boolean;
    setGithubAutoSync: (auto: boolean) => void;
    showPaperDolls: boolean;
    setShowPaperDolls: (show: boolean) => void;
    isMobileDevice: boolean;
    baseScore: number;
    setBaseScore: (score: number) => void;
    masterFrequency: 'LOW' | 'NORMAL' | 'HIGH'; 
    setMasterFrequency: (freq: 'LOW' | 'NORMAL' | 'HIGH') => void;
    
    // New: Rule Engine Version Switch
    ruleEngineVersion: 'V1_CLASSIC' | 'V2_HIGH_COURSE';
    setRuleEngineVersion: (v: 'V1_CLASSIC' | 'V2_HIGH_COURSE') => void;

    // New: Day/Night System
    timeOfDay: number; // 0.0 - 24.0
    setTimeOfDay: (time: number) => void;
    isTimeCycleOn: boolean;
    setIsTimeCycleOn: (on: boolean) => void;
}

// Export Context for Bridge
export const GameSettingsContext = createContext<GameSettings | null>(null);

// Helper to detect performance tier
const detectPerformanceTier = (): 'HIGH' | 'MEDIUM' | 'LOW' => {
    if (typeof navigator === 'undefined') return 'HIGH';

    const ua = navigator.userAgent.toLowerCase();
    const isMobile = /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/i.test(ua);
    
    // @ts-ignore
    const memory = navigator.deviceMemory || 4; // Assume 4GB if unknown
    const cores = navigator.hardwareConcurrency || 4;

    if (isMobile) {
        if (memory <= 2 || cores <= 4) return 'LOW'; 
        if (memory <= 4 || cores <= 6) return 'MEDIUM'; 
        return 'HIGH'; 
    } else {
        if (cores <= 4) return 'MEDIUM'; 
        return 'HIGH'; 
    }
};

export const GameSettingsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    // --- State Definition ---
    const [language, setLanguage] = useState<SupportedLanguage>('zh_CN');
    const [difficulty, setDifficulty] = useState<Difficulty>(Difficulty.MEDIUM);
    const [oneClickPlay, setOneClickPlay] = useState<boolean>(true);
    const [isMuted, setIsMuted] = useState<boolean>(false); 
    const [isRiskAlertOn, setIsRiskAlertOn] = useState<boolean>(true);
    const [showSuitHistory, setShowSuitHistory] = useState<boolean>(true);
    const [githubAutoSync, setGithubAutoSync] = useState<boolean>(true); 
    const [baseScore, setBaseScore] = useState<number>(2); 
    const [masterFrequency, setMasterFrequency] = useState<'LOW' | 'NORMAL' | 'HIGH'>('NORMAL');
    const [ruleEngineVersion, setRuleEngineVersion] = useState<'V1_CLASSIC' | 'V2_HIGH_COURSE'>('V1_CLASSIC');
    
    // Day/Night System
    // Default to 20:00 (Night) for atmosphere
    const [timeOfDay, setTimeOfDay] = useState<number>(20); 
    const [isTimeCycleOn, setIsTimeCycleOn] = useState<boolean>(false); // Default off for stable aesthetic

    const [isMobileDevice, setIsMobileDevice] = useState(false);
    const [internalShowPaperDolls, setInternalShowPaperDolls] = useState<boolean>(false); 
    const [graphicsQuality, setGraphicsQuality] = useState<'HIGH' | 'MEDIUM' | 'LOW'>(() => detectPerformanceTier());

    // Load initial from storage
    useEffect(() => {
        try {
            const savedFreq = localStorage.getItem('ma_diao_master_freq');
            if (savedFreq) setMasterFrequency(savedFreq as any);
            
            const savedLang = localStorage.getItem('ma_diao_language');
            if (savedLang) setLanguage(savedLang as any);

            const savedOneClick = localStorage.getItem('ma_diao_oneclick');
            if (savedOneClick) setOneClickPlay(savedOneClick === 'true');

            const savedHistory = localStorage.getItem('ma_diao_show_history');
            if (savedHistory) setShowSuitHistory(savedHistory === 'true');
        } catch(e) {}
    }, []);

    // Time Cycle Loop
    useEffect(() => {
        let interval: number;
        if (isTimeCycleOn) {
            // 1 real second = 2 game minutes => 24h cycle in 12 minutes
            interval = window.setInterval(() => {
                setTimeOfDay(prev => (prev + 0.033) % 24);
            }, 1000);
        }
        return () => clearInterval(interval);
    }, [isTimeCycleOn]);

    // Persist helpers
    const setLanguagePersist = (l: SupportedLanguage) => { setLanguage(l); localStorage.setItem('ma_diao_language', l); };
    const setMasterFrequencyPersist = (f: 'LOW' | 'NORMAL' | 'HIGH') => { setMasterFrequency(f); localStorage.setItem('ma_diao_master_freq', f); };
    const setOneClickPersist = (b: boolean) => { setOneClickPlay(b); localStorage.setItem('ma_diao_oneclick', String(b)); };
    const setShowSuitHistoryPersist = (b: boolean) => { setShowSuitHistory(b); localStorage.setItem('ma_diao_show_history', String(b)); };

    useEffect(() => {
        document.body.classList.remove('graphics-low', 'graphics-medium', 'graphics-high');
        if (graphicsQuality === 'LOW') document.body.classList.add('graphics-low');
        else if (graphicsQuality === 'MEDIUM') document.body.classList.add('graphics-medium');
        else document.body.classList.add('graphics-high');
    }, [graphicsQuality]);

    useEffect(() => {
        const checkMobile = () => {
            const isMobileWidth = window.innerWidth < 1024;
            const isMobileUA = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
            setIsMobileDevice(isMobileWidth || isMobileUA);
            if (isMobileWidth || isMobileUA) {
               setInternalShowPaperDolls(false); 
            }
        };
        checkMobile();
        window.addEventListener('resize', checkMobile);
        return () => window.removeEventListener('resize', checkMobile);
    }, []);

    const value: GameSettings = {
        language, setLanguage: setLanguagePersist,
        difficulty, setDifficulty,
        oneClickPlay, setOneClickPlay: setOneClickPersist,
        isMuted, setIsMuted,
        isRiskAlertOn, setIsRiskAlertOn,
        showSuitHistory, setShowSuitHistory: setShowSuitHistoryPersist,
        graphicsQuality, setGraphicsQuality,
        githubAutoSync, setGithubAutoSync,
        showPaperDolls: internalShowPaperDolls, 
        setShowPaperDolls: setInternalShowPaperDolls,
        isMobileDevice,
        baseScore, setBaseScore,
        masterFrequency, setMasterFrequency: setMasterFrequencyPersist,
        ruleEngineVersion, setRuleEngineVersion,
        timeOfDay, setTimeOfDay,
        isTimeCycleOn, setIsTimeCycleOn
    };

    return React.createElement(
        GameSettingsContext.Provider,
        { value },
        children
    );
};

export const useGameSettings = (): GameSettings => {
    const context = useContext(GameSettingsContext);
    if (!context) {
        throw new Error("useGameSettings must be used within a GameSettingsProvider");
    }
    return context;
};
