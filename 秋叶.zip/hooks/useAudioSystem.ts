
import { useEffect, useCallback } from 'react';
import { audioManager } from '../services/audioManager';

type SoundType = 'WOOD' | 'STONE' | 'PAPER' | 'CHIME' | 'DRUM';

export const useAudioSystem = (isMuted: boolean) => {
    
    // Init audio subsystem once on mount
    useEffect(() => {
        audioManager.init();
    }, []);

    // Sync mute state
    useEffect(() => {
        audioManager.setMute(isMuted);
    }, [isMuted]);

    const playProceduralSFX = useCallback((type: SoundType) => {
        audioManager.playSFX(type);
    }, []);

    const playPcmAudio = useCallback((data: Uint8Array | string) => {
        audioManager.playPCM(data);
    }, []);

    const startBGM = useCallback(() => {
        audioManager.setMute(isMuted); // Re-trigger mute state check to start BGM if unmuted
    }, [isMuted]);

    return { playPcmAudio, playProceduralSFX, startBGM };
};
