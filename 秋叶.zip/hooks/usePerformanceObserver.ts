
import { useEffect, useRef, useState } from 'react';
import { useGameSettings } from './useGameSettings';
import { telemetry } from '../services/telemetryService';

interface PerformanceMetrics {
    fps: number;
    isDowngrading: boolean;
}

export const usePerformanceObserver = (): PerformanceMetrics => {
    const { graphicsQuality, setGraphicsQuality } = useGameSettings();
    const [fps, setFps] = useState(60);
    const [isDowngrading, setIsDowngrading] = useState(false);

    // Refs for animation loop
    const frameCount = useRef(0);
    const lastTime = useRef(performance.now());
    const lowFpsCounter = useRef(0); // Counter for consecutive low FPS seconds
    const processingRef = useRef(true);

    useEffect(() => {
        let animationFrameId: number;

        const loop = (time: number) => {
            if (!processingRef.current) return;

            frameCount.current++;
            const delta = time - lastTime.current;

            if (delta >= 1000) {
                const currentFps = Math.round((frameCount.current * 1000) / delta);
                setFps(currentFps);

                // --- SENTINEL LOGIC ---
                // Thresholds: High->Med if < 30fps, Med->Low if < 24fps
                // Must sustain low FPS for 3 consecutive seconds to trigger (avoid spikes)
                
                if (graphicsQuality === 'HIGH' && currentFps < 35) {
                    lowFpsCounter.current++;
                    if (lowFpsCounter.current >= 3) {
                        triggerDowngrade('MEDIUM', currentFps);
                    }
                } else if (graphicsQuality === 'MEDIUM' && currentFps < 24) {
                    lowFpsCounter.current++;
                    if (lowFpsCounter.current >= 4) {
                        triggerDowngrade('LOW', currentFps);
                    }
                } else {
                    // Reset counter if FPS recovers
                    lowFpsCounter.current = 0;
                }

                frameCount.current = 0;
                lastTime.current = time;
            }

            animationFrameId = requestAnimationFrame(loop);
        };

        const triggerDowngrade = (target: 'MEDIUM' | 'LOW', recordedFps: number) => {
            telemetry.log('WARN', 'PERFORMANCE', `Auto-downgrading quality to ${target}`, { fps: recordedFps });
            setIsDowngrading(true);
            setGraphicsQuality(target);
            lowFpsCounter.current = 0;
            
            // Visual toast duration
            setTimeout(() => setIsDowngrading(false), 4000);
        };

        animationFrameId = requestAnimationFrame(loop);

        return () => {
            processingRef.current = false;
            cancelAnimationFrame(animationFrameId);
        };
    }, [graphicsQuality, setGraphicsQuality]);

    return { fps, isDowngrading };
};
