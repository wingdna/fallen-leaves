
import { useCallback, useEffect, useRef } from 'react';
import { Player, PlayerType, GamePhase, Card, UserProfile, Suit, Difficulty, CardRank, TutorialScenario } from '../../types';
import { generateDeck, ID_90_WAN, ID_QIAN_WAN, ID_BAI_WAN, ID_BAN_WEN, ID_KONG_WEN } from '../../constants';
import { MOCK_PLAYERS } from '../../services/cloudService';
import { identifyTianShengPatterns, calculateKaiZhuAndQiaoMen, identifyPatterns as identifyPatternsService } from '../../services/scoringService';
import { evaluatePlayRisk } from '../../services/riskEngine';
import { evaluateHighCourseRisk } from '../../services/riskEngineV2_HighCourse';
import { sysEvents } from '../../services/eventBus'; 

// --- LOCAL UTILS ---
function shuffle<T>(array: T[]): T[] {
  const newArray = [...array];
  for (let i = newArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
  }
  return newArray;
}

const sortHand = (cards: Card[]): Card[] => {
    const getSuitWeight = (suit: Suit) => {
        switch (suit) {
            case Suit.CASH: return 4;
            case Suit.STRINGS: return 3;
            case Suit.COINS: return 2;
            case Suit.TEXTS: return 1;
            default: return 0;
        }
    };
    return [...cards].sort((a, b) => {
        const weightA = getSuitWeight(a.suit);
        const weightB = getSuitWeight(b.suit);
        if (weightA !== weightB) return weightB - weightA;
        return b.value - a.value;
    });
};

const HAND_REVEALING_PATTERNS = new Set(['吊百', '正本百', '顺风旗', '福禄寿喜', '佛赤脚']);
const ID_WAN_WAN = 'c_11'; 

// --- ASYNC HELPERS ---
const wait = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const useMaDiaoActions = (
    state: any, 
    timers: { safeTimeout: (fn: () => void, delay: number) => any, clearAllTimers: () => void },
    config: { playSound: any, ruleEngineVersion?: string, isRiskAlertOn: boolean, difficulty: Difficulty, language: string }
) => {
    
    const advanceTutorialStepRef = useRef<() => void>(() => {});
    const actionLock = useRef(false);

    // --- 1. START GAME ACTION ---
    const startGame = useCallback(async (userProfile?: UserProfile, customOpponents?: UserProfile[], existingPlayers?: Player[]) => {
        if (actionLock.current) return;
        actionLock.current = true;

        try {
            sysEvents.emit('PLAY_SOUND', { type: 'PAPER' });
            timers.clearAllTimers(); 
            
            // Reset State Phase
            state.resetRoundState();
            state.setPhase(GamePhase.SHUFFLING);

            // Artificial Shuffling Delay
            await wait(800);

            // Using RequestAnimationFrame to ensure UI updates before heavy logic
            await new Promise<void>(resolve => {
                requestAnimationFrame(() => {
                    try {
                        const fullDeck = generateDeck();
                        const newDeck = shuffle(fullDeck);
                        state.setDeck(newDeck);
                        
                        const hands = [ sortHand(newDeck.slice(0, 8)), sortHand(newDeck.slice(8, 16)), sortHand(newDeck.slice(16, 24)), sortHand(newDeck.slice(24, 32)) ];
                        const potCards = newDeck.slice(32, 39).map((c: Card) => ({ ...c, isPot: true })); 
                        const mianZhang = { ...newDeck[39], isPot: true };
                        
                        let newBankerId = 0;
                        if (existingPlayers && existingPlayers.length === 4) {
                            newBankerId = (existingPlayers.findIndex(p => p.isDealer) + 1) % 4;
                        } else {
                            newBankerId = Math.floor(Math.random() * 4);
                        }

                        let newPlayers: Player[] = [];
                        const STARTING_SCORE = 1000;

                        if (existingPlayers && existingPlayers.length === 4) {
                            newPlayers = existingPlayers.map((p, i) => ({ ...p, hand: hands[i], trickPile: [], capturedCards: [], isDealer: p.id === newBankerId, isBaiLaoRevealed: false, isSuspectedBaiLao: false }));
                        } else {
                            const availableProfiles = shuffle([...MOCK_PLAYERS]);
                            const findAndPop = (gaze: string) => { const idx = availableProfiles.findIndex(p => p.gazeDirection === gaze); if (idx !== -1) return availableProfiles.splice(idx, 1)[0]; return null; };
                            const rightBot = customOpponents?.[0] || findAndPop('LEFT') || availableProfiles.pop()!;
                            const topBot = customOpponents?.[1] || availableProfiles.pop()!;
                            const leftBot = customOpponents?.[2] || findAndPop('RIGHT') || availableProfiles.pop()!;

                            newPlayers = [
                                { id: 0, name: userProfile?.username || "You", type: PlayerType.HUMAN, hand: hands[0], trickPile: [], capturedCards: [], isDealer: false, position: 'Bottom', score: STARTING_SCORE, profile: userProfile },
                                { id: 1, name: rightBot.username, type: PlayerType.AI, hand: hands[1], trickPile: [], capturedCards: [], isDealer: false, position: 'Right', score: STARTING_SCORE, profile: rightBot as any },
                                { id: 2, name: topBot.username, type: PlayerType.AI, hand: hands[2], trickPile: [], capturedCards: [], isDealer: false, position: 'Top', score: STARTING_SCORE, profile: topBot as any },
                                { id: 3, name: leftBot.username, type: PlayerType.AI, hand: hands[3], trickPile: [], capturedCards: [], isDealer: false, position: 'Left', score: STARTING_SCORE, profile: leftBot as any }
                            ];
                            newPlayers.forEach(p => p.isDealer = p.id === newBankerId);
                        }
                        
                        // Tian Sheng Check
                        let tianShengWinnerId: number | null = null; let tianShengPatternName = '';
                        for (const p of newPlayers) {
                            const result = identifyTianShengPatterns(p.hand);
                            if (result.isTianSheng) {
                                tianShengWinnerId = p.id; tianShengPatternName = result.details[0]?.name || 'Tian Sheng';
                                p.capturedCards = [...p.hand]; p.hand = [];
                                for(let i=1; i<=8; i++) p.trickPile.push({ card: p.capturedCards[i-1], isFaceUp: true, round: i });
                                break;
                            }
                        }

                        state.setPlayers(newPlayers); state.playersRef.current = newPlayers; 
                        state.setPot(potCards); state.setMianZhangCard(mianZhang); state.setBankerId(newBankerId);
                        
                        if (mianZhang.rank === CardRank.QING && mianZhang.id !== ID_90_WAN) state.setRecordedCards([mianZhang]);
                        else state.setRecordedCards([]);

                        if (tianShengWinnerId !== null) {
                            state.setCurrentPlayerIndex(tianShengWinnerId); state.setPhase(GamePhase.KAI_CHONG); 
                            state.setActiveNotification({ id: `ntf_${Date.now()}`, playerId: tianShengWinnerId, text: tianShengPatternName, score: 100, type: 'CRITICAL' });
                            state.emitEvent('TIAN_SHENG', tianShengWinnerId); 
                            sysEvents.emit('PLAY_SOUND', { type: 'CHIME' });
                        } else {
                            const starterId = (newBankerId + (mianZhang.value - 1) % 4) % 4;
                            state.setCurrentPlayerIndex(starterId); 
                            state.setPhase(GamePhase.PLAYING); 
                            sysEvents.emit('PLAY_SOUND', { type: 'DRUM' });
                        }
                    } catch(e) {
                        console.error("Start Game Logic Error:", e);
                    } finally {
                        resolve();
                    }
                });
            });
        } catch (e) {
            console.error("Start Game Critical Failure:", e);
        } finally {
            actionLock.current = false;
        }
    }, [config, state, timers]);

    // --- 2. START TUTORIAL ACTION ---
    const startTutorial = useCallback(async (userProfile: UserProfile | undefined, scenario: TutorialScenario) => {
        if (actionLock.current) return;
        actionLock.current = true;

        try {
            timers.clearAllTimers();
            state.resetRoundState();
            
            const fullDeck = generateDeck();
            const findCard = (id: string) => fullDeck.find(c => c.id === id)!;
            
            const hands: Card[][] = [];
            hands[0] = sortHand(scenario.playerHandIds.map(findCard));
            hands[1] = sortHand(scenario.aiHandIds[1].map(findCard));
            hands[2] = sortHand(scenario.aiHandIds[2].map(findCard));
            hands[3] = sortHand(scenario.aiHandIds[3].map(findCard));
            
            const newBankerId = scenario.bankerId;
            const initialCapturedMap = new Map<number, Card[]>();
            if (scenario.initialCapturedCards) {
                scenario.initialCapturedCards.forEach((def: any) => {
                    const cards = def.cardIds.map(findCard).filter(Boolean);
                    initialCapturedMap.set(def.playerId, cards);
                });
            }

            const usedIds = new Set<string>();
            scenario.playerHandIds.forEach((id: string) => usedIds.add(id));
            Object.values(scenario.aiHandIds).flat().forEach((id: string) => usedIds.add(id));
            initialCapturedMap.forEach(cards => cards.forEach(c => usedIds.add(c.id)));
            
            const leftovers = fullDeck.filter(c => !usedIds.has(c.id));
            const potCards = leftovers.length >= 7 ? leftovers.slice(0, 7).map(c => ({ ...c, isPot: true })) : [];
            const mianZhang = leftovers.length >= 8 ? { ...leftovers[7], isPot: true } : null;

            const newPlayers: Player[] = [
                { id: 0, name: userProfile?.username || "You", type: PlayerType.HUMAN, hand: hands[0], trickPile: [], capturedCards: [], isDealer: false, position: 'Bottom' as const, score: 1000, profile: userProfile },
                { id: 1, name: "丰臣秀吉", type: PlayerType.AI, hand: hands[1], trickPile: [], capturedCards: [], isDealer: false, position: 'Right' as const, score: 1000, 
                  profile: { id: 'ai_toyotomi', username: '丰臣秀吉', gender: 'MALE' as any, age: 60, country: 'jp', is_looking_for_match: false, last_active: 0, friends: [], avatar_url: 'https://api.dicebear.com/9.x/miniavs/svg?seed=Hideyoshi&backgroundColor=b6e3f4' } },
                { id: 2, name: "万历皇帝", type: PlayerType.AI, hand: hands[2], trickPile: [], capturedCards: [], isDealer: false, position: 'Top' as const, score: 1000, 
                  profile: { id: 'ai_wanli', username: '万历皇帝', gender: 'MALE' as any, age: 40, country: 'cn', is_looking_for_match: false, last_active: 0, friends: [], avatar_url: 'https://api.dicebear.com/9.x/miniavs/svg?seed=Wanli&backgroundColor=ffd5dc' } },
                { id: 3, name: "李舜臣", type: PlayerType.AI, hand: hands[3], trickPile: [], capturedCards: [], isDealer: false, position: 'Left' as const, score: 1000, 
                  profile: { id: 'ai_yisun', username: '李舜臣', gender: 'MALE' as any, age: 50, country: 'kr', is_looking_for_match: false, last_active: 0, friends: [], avatar_url: 'https://api.dicebear.com/9.x/miniavs/svg?seed=YiSunSin&backgroundColor=c0aede' } }
            ].map(p => {
                const caps = initialCapturedMap.get(p.id) || [];
                const pile = caps.map(c => ({ card: c, isFaceUp: true, round: 0, isKaiChong: false }));
                return { ...p, capturedCards: caps, trickPile: pile };
            });

            newPlayers.forEach(p => p.isDealer = p.id === newBankerId);

            state.setPlayers(newPlayers);
            state.playersRef.current = newPlayers; 
            state.setPot(potCards);
            state.setMianZhangCard(mianZhang);
            state.setBankerId(newBankerId);
            state.setCurrentScenario(scenario);
            state.setTutorialStepIndex(0);
            
            const starterId = scenario.startingPlayerId !== undefined ? scenario.startingPlayerId : newBankerId;
            state.setCurrentPlayerIndex(starterId); 
            
            if (scenario.preconfiguredState?.openedSuits) {
                state.setOpenedSuits(scenario.preconfiguredState.openedSuits);
            } else {
                state.setOpenedSuits([]);
            }
            
            state.setPhase(GamePhase.TUTORIAL);
            sysEvents.emit('PLAY_SOUND', { type: 'DRUM' });
            
            state.trickCardsRef.current = [];
            state.setTableCards([]);
        } catch(e) {
            console.error("Start Tutorial Failed:", e);
        } finally {
            actionLock.current = false;
        }
    }, [config, state, timers]);

    // --- 3. RESOLVE TRICK ACTION ---
    const resolveTrick = useCallback(async (cards: { playerId: number, card: Card, isFaceDown: boolean }[]) => {
        if (!cards || cards.length === 0) return;
        
        try {
            const currentPlayers = state.playersRef.current;
            const leadSuit = cards[0].card.suit;
            let winnerId = cards[0].playerId; let maxVal = -1; let winningCardRef: Card | null = null;
            
            cards.forEach((tc: any) => { if (!tc.isFaceDown && tc.card.suit === leadSuit && tc.card.value > maxVal) { maxVal = tc.card.value; winnerId = tc.playerId; winningCardRef = tc.card; } });
            if (!winningCardRef) { winnerId = cards[0].playerId; winningCardRef = cards[0].card; }
            
            state.setTrickWinnerId(winnerId);
            
            if (winningCardRef.suit === Suit.CASH) {
                const winnerVal = winningCardRef.value; 
                const hasQian = cards.some((tc: any) => tc.card.id === ID_QIAN_WAN); 
                const hasBai = cards.some((tc: any) => tc.card.id === ID_BAI_WAN);
                state.setSpecialCaptures((prev: any) => { const next = { ...prev }; if (winnerVal === 11) { if (hasQian) next.wanCaughtQian = true; if (hasBai) next.wanCaughtBai = true; } else if (winnerVal === 10) { if (hasBai) next.qianCaughtBai = true; } return next; });
            }
            
            const isBigWin = winningCardRef.rank === CardRank.ZUN || winningCardRef.rank === CardRank.BAI;
            if (isBigWin) sysEvents.emit('PLAY_SOUND', { type: 'CHIME' });
            
            state.emitEvent('TRICK_WIN', winnerId, { isBig: isBigWin });

            await wait(1000);

            state.setTrickWinnerId(null); 
            state.setTableCards([]);
            state.trickCardsRef.current = []; 
            
            const updatedPlayers = currentPlayers.map((p: any) => {
                let newTrickPile = [...p.trickPile]; let newCapturedCards = [...p.capturedCards];
                if (p.id === winnerId && winningCardRef) { newTrickPile.push({ card: winningCardRef, isFaceUp: true, round: state.trickNumber }); newCapturedCards.push(winningCardRef); }
                return { ...p, trickPile: newTrickPile, capturedCards: newCapturedCards };
            });
            state.setPlayers(updatedPlayers);
            state.playersRef.current = updatedPlayers;
            
            // --- NOTIFICATIONS ---
            const winner = updatedPlayers.find((p: any) => p.id === winnerId);
            if (winner) {
                const pileA = winner.trickPile.filter((t: any) => !t.isKaiChong).map((t: any) => t.card);
                const pileCount = pileA.length;
                
                if (!state.patternCache.current[winnerId]) state.patternCache.current[winnerId] = new Set();
                const cache = state.patternCache.current[winnerId];

                if (pileCount === 2 && !cache.has('DIAO_ZHENG_BEN')) {
                    state.setActiveNotification({ id: `ntf_${Date.now()}`, playerId: winnerId, text: "正本", score: 0, type: 'PATTERN' });
                    cache.add('DIAO_ZHENG_BEN');
                } else if (pileCount === 3 && !cache.has('DIAO_DE_DIAO')) {
                    state.setActiveNotification({ id: `ntf_${Date.now()}`, playerId: winnerId, text: "得吊", score: 1, type: 'PATTERN' });
                    cache.add('DIAO_DE_DIAO');
                }

                const kzqm = calculateKaiZhuAndQiaoMen(pileA, winner, pileCount);
                kzqm.details.forEach(d => {
                    if (!cache.has(d.name)) {
                        if (state.trickNumber < 8 && HAND_REVEALING_PATTERNS.has(d.name)) return;
                        const isBanker = winnerId === state.bankerId;
                        state.setActiveNotification({ id: `ntf_${Date.now()}_${Math.random()}`, playerId: winnerId, text: d.name, score: d.score, type: isBanker ? 'CRITICAL' : 'PATTERN' });
                        sysEvents.emit('PLAY_SOUND', { type: 'CHIME' });
                        cache.add(d.name);
                    }
                });

                const detected = identifyPatternsService(pileA, winner); 
                detected.details.forEach(detail => { 
                    if (!cache.has(detail.name)) { 
                        if (state.trickNumber < 8 && HAND_REVEALING_PATTERNS.has(detail.name)) return;
                        state.setActiveNotification({ id: `ntf_${Date.now()}_${Math.random()}`, playerId: winnerId, text: detail.name, score: detail.score, type: 'CRITICAL' });
                        sysEvents.emit('PLAY_SOUND', { type: 'CHIME' }); 
                        cache.add(detail.name); 
                    } 
                });
                state.patternCache.current[winnerId] = cache;
            }
            
            if (state.trickNumber === 8) { 
                state.setPhase(GamePhase.KAI_CHONG); state.setKaiChongCardIndex(0); state.setCurrentPlayerIndex(winnerId); 
                sysEvents.emit('PLAY_SOUND', { type: 'DRUM' });
            } else { 
                state.setTrickNumber((prev: number) => prev + 1); 
                state.setCurrentPlayerIndex(winnerId); 
            }

            if (state.currentScenario && !state.currentScenario.steps[state.tutorialStepIndex]?.waitForClick && !state.currentScenario.steps[state.tutorialStepIndex]?.aiMoves) {
                if (state.trickNumber !== 8 && advanceTutorialStepRef.current) {
                    advanceTutorialStepRef.current(); 
                }
            }
        } catch (e) {
            console.error("Resolve Trick Failed:", e);
        }
    }, [state, config, timers]);

    // --- 4. EXECUTE PLAY ACTION ---
    const executePlayCard = useCallback(async (
        playerId: number, 
        cardId: string, 
        bypassRisk: boolean = false, 
        bypassTurnCheck: boolean = false
    ) => {
        if (actionLock.current && !bypassTurnCheck) return; 
        actionLock.current = true;

        try {
            const currentPlayers = state.playersRef.current;
            const player = currentPlayers.find((p: any) => p.id === playerId);
            
            if (!player) throw new Error("Player not found");
            if (!player.hand.some((c: any) => c.id === cardId)) throw new Error("Card not in hand");
            
            if (!bypassTurnCheck && state.players[state.currentPlayerIndex]?.id !== playerId) throw new Error("Not your turn");
            if (state.phase !== GamePhase.PLAYING && state.phase !== GamePhase.TUTORIAL) throw new Error("Wrong phase");
            if (state.isAutoPlayingBiZhang.current) throw new Error("BiZhang active");

            const card = player.hand.find((c: any) => c.id === cardId)!;
            
            if (state.phase === GamePhase.TUTORIAL && state.currentScenario && playerId === 0) {
                const step = state.currentScenario.steps[state.tutorialStepIndex];
                if (step.forcedCardId && step.forcedCardId !== cardId) throw new Error("Tutorial restricted move"); 
            }

            const currentTableCards = [...state.trickCardsRef.current]; 
            const tableCardsForRisk = currentTableCards.map((tc: any) => ({ card: tc.card, playerId: tc.playerId }));
            
            if (playerId === 0 && config.isRiskAlertOn && state.phase !== GamePhase.TUTORIAL) {
                let risk: any = null;
                if (config.ruleEngineVersion === 'V2_HIGH_COURSE') {
                    risk = evaluateHighCourseRisk(player, card, tableCardsForRisk, state.bankerId, currentPlayers, state.recordedCards, state.openedSuits, state.firstLeadInfo, state.trickNumber, state.mianZhangCard, state.bankerFirstLeadCard, state.faceUpPlayedCardIds, state.strategyModifier);
                } else {
                    risk = evaluatePlayRisk(player, card, tableCardsForRisk, state.bankerId, currentPlayers, state.recordedCards, state.openedSuits, state.firstLeadInfo, state.trickNumber, state.mianZhangCard, state.bankerFirstLeadCard);
                }
                if (risk && risk.riskLevel !== 'SAFE') { 
                    if (!bypassRisk) {
                        state.setPendingRisk({ cardId, assessment: risk }); 
                        sysEvents.emit('PLAY_SOUND', { type: 'WOOD' });
                        actionLock.current = false; 
                        return;
                    }
                }
            }
            
            sysEvents.emit('PLAY_SOUND', { type: 'STONE' });
            
            const leadSuit = currentTableCards.length > 0 ? currentTableCards[0].card.suit : null;
            let isFaceDown = leadSuit ? (card.suit !== leadSuit || card.value <= Math.max(...currentTableCards.filter((tc: any) => !tc.isFaceDown && tc.card.suit === leadSuit).map((tc: any) => tc.card.value), -1)) : false;
            
            if (state.trickNumber === 8 && (!player.capturedCards || player.capturedCards.length === 0)) isFaceDown = true;
            if (!isFaceDown) {
                state.setFaceUpPlayedCardIds((prev: any) => new Set(prev).add(card.id));
                state.setRecordedCards((prev: any) => [...prev, card]);
            }
            
            const isLeading = currentTableCards.length === 0;
            
            const isExplicitBai = card.id === ID_BAI_WAN && !isFaceDown;
            const isImplicitBai = isLeading && card.suit === Suit.CASH && !player.isBaiLaoRevealed && !player.isSuspectedBaiLao && !player.isDealer;

            if (isExplicitBai) {
                state.setActiveNotification({ id: `ntf_bai_${Date.now()}`, playerId, text: "百老现身", score: 0, type: 'CRITICAL' });
                sysEvents.emit('PLAY_SOUND', { type: 'CHIME' });
                state.emitEvent('BAI_LAO_REVEALED', playerId);
            } else if (isImplicitBai) {
                state.setActiveNotification({ id: `ntf_bao_${Date.now()}`, playerId, text: "报百", score: 0, type: 'PATTERN' });
                state.emitEvent('SUSPECTED_BAI_LAO', playerId);
            } else if (isLeading && !player.isDealer) {
                const suitNameMap: Record<Suit, string> = { [Suit.CASH]: "十字", [Suit.STRINGS]: "贯子", [Suit.COINS]: "索子", [Suit.TEXTS]: "文钱" };
                state.setActiveNotification({ id: `ntf_lead_${Date.now()}`, playerId, text: `开门: ${suitNameMap[card.suit]}`, score: 0, type: 'PATTERN' });
            }

            const updatedPlayers = currentPlayers.map((p: any) => { 
                if (p.id === playerId) { 
                    const newHand = p.hand.filter((c: any) => c.id !== cardId); 
                    return { 
                        ...p, 
                        hand: newHand, 
                        isBaiLaoRevealed: isExplicitBai || p.isBaiLaoRevealed,
                        isSuspectedBaiLao: isImplicitBai || p.isSuspectedBaiLao
                    }; 
                } 
                return p; 
            });
            
            state.setPlayers(updatedPlayers);
            state.playersRef.current = updatedPlayers;

            const newTrickItem = { playerId, card, isFaceDown };
            state.trickCardsRef.current.push(newTrickItem);
            state.setTableCards((prev: any) => [...prev, newTrickItem]); 
            
            if (currentTableCards.length === 0) { 
                state.setFirstLeadInfo({ card, playerId }); 
                if (playerId === state.bankerId) state.setBankerFirstLeadCard(card); 
                if (!state.openedSuits.some((s: any) => s.suit === card.suit)) state.setOpenedSuits((prev: any) => [...prev, { suit: card.suit, leaderId: playerId, isBanker: playerId === state.bankerId }]); 
            }
            
            state.setSelectedCardId(null);
            
            if (state.trickCardsRef.current.length === 4) { 
                const fullTrick = [...state.trickCardsRef.current];
                await wait(800);
                await resolveTrick(fullTrick);
            } else { 
                state.setCurrentPlayerIndex((state.currentPlayerIndex + 1) % 4); 
            }

            const isTrickComplete = state.trickCardsRef.current.length === 4;
            if (state.phase === GamePhase.TUTORIAL && playerId === 0 && !isTrickComplete) {
                if (advanceTutorialStepRef.current) advanceTutorialStepRef.current(); 
            }

        } catch (e) {
            console.error("ExecutePlayCard Failed:", e);
        } finally {
            actionLock.current = false;
        }

    }, [config, state, timers, resolveTrick]);

    // --- 5. TUTORIAL ADVANCE ACTION ---
    const advanceTutorialStep = useCallback(() => {
        if (!state.currentScenario) return;
        const nextIndex = state.tutorialStepIndex + 1;
        
        if (nextIndex >= state.currentScenario.steps.length) {
            state.setIsTutorialComplete(true);
            return;
        }

        state.setTutorialStepIndex(nextIndex);
        const step = state.currentScenario.steps[nextIndex];

        if (step.setPlayerHand || step.setAiHands) {
            const fullDeck = generateDeck(); 
            const findCard = (id: string) => fullDeck.find(c => c.id === id)!;
            const newPlayers = state.playersRef.current.map((p: Player) => {
                let newHand = p.hand;
                if (p.id === 0 && step.setPlayerHand) newHand = sortHand(step.setPlayerHand.map(findCard).filter(Boolean));
                if (step.setAiHands && step.setAiHands[p.id]) newHand = sortHand(step.setAiHands[p.id].map(findCard).filter(Boolean));
                return { ...p, hand: newHand };
            });
            state.setPlayers(newPlayers); state.playersRef.current = newPlayers;
            sysEvents.emit('PLAY_SOUND', { type: 'PAPER' });
        }

        if (step.clearCapturedCards) {
            const newPlayers = state.playersRef.current.map((p: Player) => ({
                ...p, capturedCards: [], trickPile: p.trickPile.filter((t: any) => t.round === state.trickNumber)
            }));
            state.setPlayers(newPlayers); state.playersRef.current = newPlayers;
        }

        if (step.aiMoves) {
            const currentTableCount = state.trickCardsRef.current.length;
            if (currentTableCount >= 4) {
                state.setTableCards([]); state.trickCardsRef.current = []; state.setTrickNumber((prev: number) => prev + 1);
            }
            
            const runAIMoves = async () => {
                await wait(500); 
                if (step.forcedCardId) state.setCurrentPlayerIndex(0);
                for (const move of step.aiMoves) {
                    await wait(1200); 
                    await executePlayCard(move.playerId, move.cardId, true, true);
                }
                if (!step.waitForClick && !step.forcedCardId) {
                    await wait(6000); 
                    advanceTutorialStepRef.current();
                }
            };
            runAIMoves();

        } else if (step.forcedCardId) {
            state.setCurrentPlayerIndex(0);
        }
    }, [state, config, timers, executePlayCard]);

    useEffect(() => {
        advanceTutorialStepRef.current = advanceTutorialStep;
    }, [advanceTutorialStep]);

    return { 
        startGame, 
        startTutorial, 
        resolveTrick, 
        executePlayCard, 
        advanceTutorialStep 
    };
};
