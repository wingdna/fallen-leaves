
import { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { Player, GamePhase, Card, ScoreResult, GameHistory, ViolationRecord, RiskAssessment, SpecialCaptureFlags, ScoreNotification, TutorialScenario, KaiChongDetail, Suit } from '../../types';
import { StrategyModifier } from '../../services/masterMindService';
import { loadGameStats } from '../../services/statsService';

export const useMaDiaoState = () => {
    // --- CORE GAME STATE ---
    const [deck, setDeck] = useState<Card[]>([]);
    const [players, setPlayers] = useState<Player[]>([]);
    // Logic ref for immediate access during rapid AI moves/timers to prevent stale closures
    const playersRef = useRef<Player[]>([]); 
    
    const [pot, setPot] = useState<Card[]>([]);
    const [tableCards, setTableCards] = useState<{ playerId: number; card: Card; isFaceDown: boolean }[]>([]);
    // Logic ref for synchronous truth of the table state
    const trickCardsRef = useRef<{ playerId: number; card: Card; isFaceDown: boolean }[]>([]);
    
    const [currentPlayerIndex, setCurrentPlayerIndex] = useState<number>(0);
    const [phase, setPhase] = useState<GamePhase>(GamePhase.DEALING);
    const [bankerId, setBankerId] = useState<number>(3);
    const [roundResults, setRoundResults] = useState<ScoreResult[]>([]);
    const [trickNumber, setTrickNumber] = useState<number>(1);
    const [gameMessage, setGameMessage] = useState<string>("");
    
    // --- TRACKING & HISTORY STATE ---
    const [recordedCards, setRecordedCards] = useState<Card[]>([]);
    const [faceUpPlayedCardIds, setFaceUpPlayedCardIds] = useState<Set<string>>(new Set());
    const [violationLog, setViolationLog] = useState<ViolationRecord[]>([]);
    const [openedSuits, setOpenedSuits] = useState<{suit: Suit, leaderId: number, isBanker: boolean}[]>([]);
    const [firstLeadInfo, setFirstLeadInfo] = useState< {card: Card, playerId: number} | null>(null);
    const [bankerFirstLeadCard, setBankerFirstLeadCard] = useState<Card | null>(null); 
    const [gameHistory, setGameHistory] = useState<GameHistory>(() => loadGameStats());
    const [specialCaptures, setSpecialCaptures] = useState<SpecialCaptureFlags>({ wanCaughtQian: false, wanCaughtBai: false, qianCaughtBai: false });
    const [trickWinnerId, setTrickWinnerId] = useState<number | null>(null);
    
    // --- KAI CHONG & SCORING STATE ---
    const [kaiChongCardIndex, setKaiChongCardIndex] = useState<number>(0);
    const [kaiChongHistory, setKaiChongHistory] = useState<KaiChongDetail[]>([]);
    const [mianZhangCard, setMianZhangCard] = useState<Card | null>(null);
    
    // --- UI & INTERACTION STATE ---
    const [selectedCardId, setSelectedCardId] = useState<string | null>(null);
    const [pendingRisk, setPendingRisk] = useState<{cardId: string, assessment: RiskAssessment} | null>(null);
    const [violationNotification, setViolationNotification] = useState<{title: string, message: string} | null>(null);
    const [activeNotification, setActiveNotification] = useState<ScoreNotification | null>(null);
    
    // --- INTERNAL REFS & FLAGS ---
    // Cache for already notified patterns to prevent spam
    const patternCache = useRef<Record<number, Set<string>>>({});
    const [lastGameEvent, setLastGameEvent] = useState<any>(null);
    const [strategyModifier, setStrategyModifier] = useState<StrategyModifier | undefined>(undefined);
    const isStartingRef = useRef(false);
    const isAutoPlayingBiZhang = useRef(false);

    // --- TUTORIAL STATE ---
    const [currentScenario, setCurrentScenario] = useState<TutorialScenario | null>(null);
    const [tutorialStepIndex, setTutorialStepIndex] = useState<number>(-1);
    const [isTutorialComplete, setIsTutorialComplete] = useState<boolean>(false); 

    // Sync Players Ref immediately on render
    useEffect(() => { playersRef.current = players; }, [players]);

    // Helper: Emit Event
    const emitEvent = useCallback((type: string, playerId?: number, context?: any) => {
        setLastGameEvent({ type, playerId, context, timestamp: Date.now() });
    }, []);

    // Helper: Reset Round
    const resetRoundState = useCallback(() => {
        setTableCards([]); 
        trickCardsRef.current = []; 
        setPot([]); setMianZhangCard(null); setRoundResults([]); setTrickNumber(1); 
        setRecordedCards([]); setFaceUpPlayedCardIds(new Set()); setOpenedSuits([]); 
        setViolationLog([]); setGameMessage(""); setKaiChongHistory([]); setKaiChongCardIndex(0); 
        setSpecialCaptures({ wanCaughtQian: false, wanCaughtBai: false, qianCaughtBai: false }); 
        setSelectedCardId(null); setPendingRisk(null); setViolationNotification(null); 
        setFirstLeadInfo(null); setBankerFirstLeadCard(null); setActiveNotification(null); 
        patternCache.current = { 0: new Set(), 1: new Set(), 2: new Set(), 3: new Set() };
        isAutoPlayingBiZhang.current = false;
        setStrategyModifier(undefined);
        setCurrentScenario(null); setTutorialStepIndex(-1); setIsTutorialComplete(false);
        // [FIX] Explicitly reset phase to DEALING (Home Screen) so "Return to Home" works
        setPhase(GamePhase.DEALING);
    }, []);

    // Bundle everything into a memoized object
    const stateBundle = useMemo(() => ({
        deck, setDeck,
        players, setPlayers, playersRef,
        pot, setPot,
        tableCards, setTableCards, trickCardsRef,
        currentPlayerIndex, setCurrentPlayerIndex,
        phase, setPhase,
        bankerId, setBankerId,
        roundResults, setRoundResults,
        trickNumber, setTrickNumber,
        gameMessage, setGameMessage,
        recordedCards, setRecordedCards,
        faceUpPlayedCardIds, setFaceUpPlayedCardIds,
        violationLog, setViolationLog,
        openedSuits, setOpenedSuits,
        firstLeadInfo, setFirstLeadInfo,
        bankerFirstLeadCard, setBankerFirstLeadCard,
        gameHistory, setGameHistory,
        specialCaptures, setSpecialCaptures,
        trickWinnerId, setTrickWinnerId,
        kaiChongCardIndex, setKaiChongCardIndex,
        kaiChongHistory, setKaiChongHistory,
        mianZhangCard, setMianZhangCard,
        selectedCardId, setSelectedCardId,
        pendingRisk, setPendingRisk,
        violationNotification, setViolationNotification,
        activeNotification, setActiveNotification,
        patternCache,
        lastGameEvent, emitEvent,
        strategyModifier, setStrategyModifier,
        isStartingRef, isAutoPlayingBiZhang,
        currentScenario, setCurrentScenario,
        tutorialStepIndex, setTutorialStepIndex,
        isTutorialComplete, setIsTutorialComplete,
        resetRoundState
    }), [
        deck, players, pot, tableCards, currentPlayerIndex, phase, bankerId, roundResults, trickNumber, gameMessage, 
        recordedCards, faceUpPlayedCardIds, violationLog, openedSuits, firstLeadInfo, bankerFirstLeadCard, gameHistory, 
        specialCaptures, trickWinnerId, kaiChongCardIndex, kaiChongHistory, mianZhangCard, selectedCardId, pendingRisk, 
        violationNotification, activeNotification, lastGameEvent, strategyModifier, currentScenario, tutorialStepIndex, 
        isTutorialComplete, emitEvent, resetRoundState
    ]);

    return stateBundle;
};
