
import { useEffect, useMemo, useRef } from 'react';
import { useTimerRegistry } from './utils/useTimerRegistry';
import { useMaDiaoState } from './game/useMaDiaoState';
import { useMaDiaoActions } from './game/useMaDiaoActions';
import { GamePhase, Difficulty, SupportedLanguage, PlayerType, Card } from '../types';
import { calculateRoundScores, findBestKaiChongMatch, checkDuoJinBiao } from '../services/scoringService';
import { consultTheMaster } from '../services/masterMindService';
import { saveGameStats } from '../services/statsService';
import { updateAILearning, getAIState } from '../services/aiLearningService';
import { sysEvents } from '../services/eventBus';

interface GameConfig {
    difficulty: Difficulty;
    isRiskAlertOn: boolean;
    language: SupportedLanguage;
    playSound: (type: 'WOOD' | 'STONE' | 'PAPER' | 'CHIME' | 'DRUM') => void; 
    baseScore?: number; 
    ruleEngineVersion?: 'V1_CLASSIC' | 'V2_HIGH_COURSE'; 
}

// Helper
const wait = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const useMaDiaoGame = (config: GameConfig) => {
    // 1. Core State Model
    const state = useMaDiaoState();
    
    // 2. Timer Infrastructure
    const timers = useTimerRegistry();

    // 3. Action Controller
    const actions = useMaDiaoActions(state, timers, config);

    // 4. Effects (Side Effects & Automations)

    // E1. Force tutorial advance on SCORING phase if stuck
    useEffect(() => {
        if (state.phase === GamePhase.SCORING && state.currentScenario) {
            const settlementStepIdx = state.currentScenario.steps.findIndex(s => s.id === 'step_4_settlement_wait');
            if (settlementStepIdx !== -1 && state.tutorialStepIndex < settlementStepIdx) {
                state.setTutorialStepIndex(settlementStepIdx);
            }
        }
    }, [state.phase, state.currentScenario, state.tutorialStepIndex, state.setTutorialStepIndex]);

    // E2. Master Mind Consultation (Async AI Strategy)
    useEffect(() => {
        if (config.ruleEngineVersion === 'V2_HIGH_COURSE' && state.phase === GamePhase.PLAYING && state.players[state.currentPlayerIndex]?.id === 0) {
            const human = state.players[0];
            consultTheMaster(human, state.trickNumber, state.openedSuits, state.bankerId, state.tableCards).then(mod => {
                state.setStrategyModifier(mod);
            });
        }
    }, [state.trickNumber, state.currentPlayerIndex, state.tableCards.length, state.phase, config.ruleEngineVersion, state.players, state.openedSuits, state.bankerId, state.tableCards, state.setStrategyModifier]);

    // E3. Table Watchdog (Auto-resolve stuck tricks)
    useEffect(() => {
        let timer: any;
        if (state.trickCardsRef.current.length === 4 && !state.trickWinnerId) {
            timer = setTimeout(() => {
                console.warn("Watchdog: Auto-resolving stuck trick.");
                actions.resolveTrick([...state.trickCardsRef.current]);
            }, 2500); 
        }
        return () => clearTimeout(timer);
    }, [state.tableCards, state.trickWinnerId, actions.resolveTrick, state.trickCardsRef]);

    // E4. Bi Zhang Automation (Trick 8 Phase Transition)
    useEffect(() => {
        if (state.trickNumber === 8 && (state.phase === GamePhase.PLAYING || state.phase === GamePhase.TUTORIAL) && state.tableCards.length === 0 && !state.isAutoPlayingBiZhang.current) {
            if (state.players.every(p => p.hand.length === 0)) return;
            state.isAutoPlayingBiZhang.current = true;
            const runBiZhang = async () => {
                let currentTable: any[] = []; 
                let tempPlayers = [...state.playersRef.current]; 
                const turnOrder = [0, 1, 2, 3].map(i => (state.currentPlayerIndex + i) % 4);
                for (const pid of turnOrder) {
                    const p = tempPlayers.find(pl => pl.id === pid)!; 
                    if (p.hand.length === 0) continue; 
                    const card = p.hand[0]; 
                    let isFaceDown = !p.capturedCards || p.capturedCards.length === 0;
                    if (currentTable.length > 0 && !isFaceDown) { 
                        const lead = currentTable[0].card.suit; 
                        isFaceDown = card.suit !== lead || card.value <= Math.max(...currentTable.filter(tc => !tc.isFaceDown && tc.card.suit === lead).map(tc => tc.card.value), -1); 
                    }
                    if (!isFaceDown) {
                        state.setFaceUpPlayedCardIds((prev: Set<string>) => new Set(prev).add(card.id));
                        state.setRecordedCards((prev: Card[]) => [...prev, card]);
                    }
                    const item = { playerId: pid, card, isFaceDown };
                    currentTable.push(item); 
                    tempPlayers = tempPlayers.map(pl => pl.id === pid ? { ...pl, hand: [] } : pl);
                    state.setPlayers(tempPlayers); state.playersRef.current = tempPlayers;
                    state.setTableCards([...currentTable]); state.trickCardsRef.current = [...currentTable];
                    sysEvents.emit('PLAY_SOUND', { type: 'PAPER' }); 
                    await wait(600);
                }
                actions.resolveTrick(currentTable);
            };
            runBiZhang();
        }
    }, [state.trickNumber, state.phase, state.players, state.currentPlayerIndex, state.tableCards.length, config, actions.resolveTrick, state.isAutoPlayingBiZhang, state.playersRef, state.setPlayers, state.setTableCards, state.trickCardsRef, state.setFaceUpPlayedCardIds, state.setRecordedCards]); 

    // E5. Kai Chong & Scoring Loop (Refactored for Linear Flow)
    // Uses a Ref to lock the loop to prevent re-entry if render happens
    const isProcessingKaiChong = useRef(false);

    useEffect(() => {
        if (state.phase === GamePhase.KAI_CHONG && !isProcessingKaiChong.current) {
            
            const runKaiChongStep = async () => {
                isProcessingKaiChong.current = true;

                if (state.kaiChongCardIndex < 7) { 
                    await wait(1000);
                    
                    const currentPotCard = state.pot[state.kaiChongCardIndex]; 
                    if (!currentPotCard) { 
                        state.setKaiChongCardIndex(prev => prev + 1); 
                        isProcessingKaiChong.current = false; 
                        return; 
                    }
                    
                    sysEvents.emit('PLAY_SOUND', { type: 'PAPER' });
                    
                    const possibleMatches: any[] = [];
                    state.players.forEach(p => { const match = findBestKaiChongMatch({ players: state.players, potCard: currentPotCard, lang: config.language, history: state.kaiChongHistory, currentAttempterId: p.id, specialCaptures: state.specialCaptures }); if (match) possibleMatches.push(match); });
                    possibleMatches.sort((a, b) => a.priorityScore !== b.priorityScore ? a.priorityScore - b.priorityScore : ((a.playerId - state.currentPlayerIndex + 4) % 4) - ((b.playerId - state.currentPlayerIndex + 4) % 4));
                    
                    const winningMatch = possibleMatches[0];
                    if (winningMatch) {
                        const duoJinInfo = checkDuoJinBiao(winningMatch.playerId, winningMatch.matchedCard, winningMatch.sourceCards[0], state.players);
                        if (duoJinInfo) { winningMatch.duoJin = duoJinInfo; state.setActiveNotification({ id: `ntf_dj_${Date.now()}`, playerId: winningMatch.playerId, text: "夺锦标!", score: duoJinInfo.scoreBase, type: 'CRITICAL' }); }
                        state.setKaiChongHistory(prev => [...prev, winningMatch]); state.emitEvent('KAI_CHONG_SUCCESS', winningMatch.playerId); state.setCurrentPlayerIndex(winningMatch.playerId); 
                        state.setActiveNotification({ id: `ntf_kc_${Date.now()}`, playerId: winningMatch.playerId, text: winningMatch.description, score: winningMatch.score, type: 'KAI_CHONG' });
                        sysEvents.emit('PLAY_SOUND', { type: 'CHIME' });
                        state.setPlayers(prev => prev.map(p => { if (p.id === winningMatch.playerId) { const dupIds = winningMatch.sourceCards.filter((sc: any) => sc.suit === winningMatch.matchedCard.suit && sc.value === winningMatch.matchedCard.value).map((sc: any) => sc.id); return { ...p, trickPile: p.trickPile.map((tc: any) => dupIds.includes(tc.card.id) ? { ...tc, hidden: true } : tc).concat([{ card: winningMatch.matchedCard, isFaceUp: true, round: 9, isKaiChong: true }]), capturedCards: [...p.capturedCards, winningMatch.matchedCard] }; } return p; }));
                    } else { 
                        state.emitEvent('KAI_CHONG_FAIL', state.currentPlayerIndex); 
                        state.setCurrentPlayerIndex((state.currentPlayerIndex + 1) % 4); 
                    }
                    state.setKaiChongCardIndex(prev => prev + 1);
                } else {
                    // End of Kai Chong -> Scoring
                    await wait(1000);
                    sysEvents.emit('PLAY_SOUND', { type: 'DRUM' });
                    
                    const scores = calculateRoundScores({ players: state.players, bankerId: state.bankerId, lang: config.language, kaiChongHistory: state.kaiChongHistory, violationLog: state.violationLog, baseScore: config.baseScore || 2 });
                    
                    await wait(1000);
                    
                    state.setTableCards([]); state.setPot([]); state.setMianZhangCard(null); state.setTrickWinnerId(null); state.setActiveNotification(null); 
                    state.setPhase(GamePhase.SCORING);
                    
                    const newHistory = { ...state.gameHistory, totalRounds: (state.gameHistory.totalRounds || 0) + 1 };
                    const bankerScore = scores.find(s => s.playerId === state.bankerId)?.totalRoundChange || 0;
                    newHistory.bankerWins += bankerScore > 0 ? 1 : 0; newHistory.peasantWins += bankerScore < 0 ? 1 : 0; newHistory.lastRoundWinnerType = bankerScore > 0 ? 'BANKER' : (bankerScore < 0 ? 'PEASANT' : 'DRAW');
                    const updatedPlayers = state.players.map(p => ({ ...p, score: p.score + (scores.find(s => s.playerId === p.id)?.totalRoundChange || 0) }));
                    state.setPlayers(updatedPlayers); state.emitEvent('ROUND_END');
                    
                    const newLearningStates = { ...(newHistory.aiLearningStates || {}) };
                    updatedPlayers.forEach(p => { if (p.type === PlayerType.AI) { const res = scores.find(s => s.playerId === p.id); if (res) newLearningStates[p.id] = updateAILearning(getAIState(p.id, state.gameHistory), res, p.id === state.bankerId, config.difficulty); } });
                    newHistory.aiLearningStates = newLearningStates; saveGameStats(newHistory); state.setGameHistory(newHistory); state.setRoundResults(scores); 
                    
                    if (state.currentScenario && state.currentScenario.id !== 'TUTORIAL_SETTLEMENT' && state.tutorialStepIndex < state.currentScenario.steps.length - 1) {
                        actions.advanceTutorialStep();
                    }
                }
                isProcessingKaiChong.current = false;
            };

            runKaiChongStep();
        }
    }, [state.phase, state.kaiChongCardIndex, state.pot, state.players, state.bankerId, config, state.gameHistory, state.kaiChongHistory, state.specialCaptures, state.violationLog, state.currentPlayerIndex, timers, actions.advanceTutorialStep, state.setKaiChongCardIndex, state.setKaiChongHistory, state.emitEvent, state.setCurrentPlayerIndex, state.setActiveNotification, state.setPlayers, state.setTableCards, state.setPot, state.setMianZhangCard, state.setTrickWinnerId, state.setPhase, state.setGameHistory, state.setRoundResults, state.currentScenario, state.tutorialStepIndex]);

    // Public API Surface
    return useMemo(() => ({ 
        state: { 
            players: state.players, deck: state.deck, pot: state.pot, tableCards: state.tableCards, currentPlayerIndex: state.currentPlayerIndex, phase: state.phase, bankerId: state.bankerId, roundResults: state.roundResults, trickNumber: state.trickNumber, gameMessage: state.gameMessage, recordedCards: state.recordedCards, faceUpPlayedCardIds: state.faceUpPlayedCardIds, violationLog: state.violationLog, openedSuits: state.openedSuits, firstLeadInfo: state.firstLeadInfo, gameHistory: state.gameHistory, trickWinnerId: state.trickWinnerId, kaiChongCardIndex: state.kaiChongCardIndex, kaiChongHistory: state.kaiChongHistory, mianZhangCard: state.mianZhangCard, selectedCardId: state.selectedCardId, pendingRisk: state.pendingRisk, violationNotification: state.violationNotification, lastGameEvent: state.lastGameEvent, bankerFirstLeadCard: state.bankerFirstLeadCard, activeNotification: state.activeNotification, currentPotCard: state.pot[state.kaiChongCardIndex] || null, strategyModifier: state.strategyModifier, currentScenario: state.currentScenario, tutorialStepIndex: state.tutorialStepIndex, isTutorialComplete: state.isTutorialComplete 
        }, 
        actions: { 
            startGame: actions.startGame, 
            startTutorial: actions.startTutorial, 
            startNextRound: () => actions.startGame(undefined, undefined, state.players), 
            exitToTitle: state.resetRoundState, 
            executePlayCard: (pid: number, cid: string, bypassRisk?: boolean) => actions.executePlayCard(pid, cid, bypassRisk), 
            setSelectedCardId: (id: string | null) => { if(id) sysEvents.emit('PLAY_SOUND', {type: 'WOOD'}); state.setSelectedCardId(id); }, 
            setPendingRisk: state.setPendingRisk, 
            setViolationNotification: state.setViolationNotification, 
            advanceTutorialStep: actions.advanceTutorialStep 
        } 
    }), [state, actions, config]);
};
