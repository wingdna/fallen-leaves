
import { useRef, useCallback, useEffect } from 'react';

export const useTimerRegistry = () => {
    // Registry to track all active timers
    const timerRegistry = useRef<Set<any>>(new Set());

    // Wrapper to create a timeout that automatically cleans itself up
    const safeTimeout = useCallback((fn: () => void, delay: number) => {
        const timerId = setTimeout(() => {
            timerRegistry.current.delete(timerId);
            fn();
        }, delay);
        timerRegistry.current.add(timerId);
        return timerId;
    }, []);

    // Force clear all pending timers (e.g. on unmount or game reset)
    const clearAllTimers = useCallback(() => {
        timerRegistry.current.forEach(clearTimeout);
        timerRegistry.current.clear();
    }, []);

    // Auto-cleanup on unmount
    useEffect(() => {
        return () => clearAllTimers();
    }, [clearAllTimers]);

    return { safeTimeout, clearAllTimers };
};
