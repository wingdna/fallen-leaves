
import { useState, useRef, useEffect, useCallback } from 'react';

export interface RecorderConfig {
    resolution: '720p' | '1080p' | '4k';
    fps: number;
    timeLimit: number; // minutes, 0 = unlimited
    stopAfterRounds: number; // 0 = unlimited
}

export const useSmartRecorder = () => {
    const [isRecording, setIsRecording] = useState(false);
    const [isPaused, setIsPaused] = useState(false);
    const [timer, setTimer] = useState(0);
    const [error, setError] = useState<string | null>(null);
    
    const [config, setConfig] = useState<RecorderConfig>({
        resolution: '1080p',
        fps: 60,
        timeLimit: 20, // Default 20 mins as requested by architect
        stopAfterRounds: 0
    });

    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const streamRef = useRef<MediaStream | null>(null);
    const chunksRef = useRef<Blob[]>([]);
    const timerRef = useRef<number | null>(null);

    // Track Rounds internally
    const roundsRecordedRef = useRef(0);

    const updateConfig = (updates: Partial<RecorderConfig>) => {
        setConfig(prev => ({ ...prev, ...updates }));
    };

    const getConstraints = () => {
        let width = 1920, height = 1080;
        if (config.resolution === '720p') { width = 1280; height = 720; }
        if (config.resolution === '4k') { width = 3840; height = 2160; }

        return {
            video: {
                width: { ideal: width },
                height: { ideal: height },
                frameRate: { ideal: config.fps },
                displaySurface: 'browser', 
            },
            audio: {
                autoGainControl: false,
                echoCancellation: false,
                noiseSuppression: false,
                sampleRate: 44100
            }
        };
    };

    const prepareStream = async (): Promise<boolean> => {
        setError(null);
        try {
            // @ts-ignore
            const stream = await navigator.mediaDevices.getDisplayMedia(getConstraints());
            stream.getVideoTracks()[0].onended = () => { stopRecording(); };
            streamRef.current = stream;
            return true;
        } catch (err: any) {
            console.error("Stream acquisition failed", err);
            setError(`无法启动录屏: ${err.message || '权限被拒绝'}`);
            return false;
        }
    };

    const startRecording = async () => {
        if (!streamRef.current) {
             const success = await prepareStream();
             if (!success) return;
        }
        
        const stream = streamRef.current!;
        try {
            const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9') ? 'video/webm;codecs=vp9' : 'video/webm';
            const recorder = new MediaRecorder(stream, { 
                mimeType,
                videoBitsPerSecond: config.resolution === '4k' ? 8000000 : 2500000 
            });

            recorder.ondataavailable = (e) => {
                if (e.data.size > 0) chunksRef.current.push(e.data);
            };

            recorder.onstop = saveRecording;
            recorder.start(1000); 
            
            mediaRecorderRef.current = recorder;
            setIsRecording(true);
            setIsPaused(false);
            chunksRef.current = [];
            setTimer(0);
            roundsRecordedRef.current = 0; // Reset round counter

            if (timerRef.current) clearInterval(timerRef.current);
            timerRef.current = window.setInterval(() => {
                setTimer(t => {
                    // Logic: If time limit is reached, STOP.
                    if (config.timeLimit > 0 && t >= config.timeLimit * 60) {
                        stopRecording();
                        return t;
                    }
                    return t + 1;
                });
            }, 1000);

        } catch (err: any) {
            setError("Failed to initialize recorder: " + err.message);
            setIsRecording(false);
        }
    };

    // External Trigger: Call this when a round ends
    const notifyRoundEnd = () => {
        if (!isRecording) return;
        roundsRecordedRef.current += 1;
        if (config.stopAfterRounds > 0 && roundsRecordedRef.current >= config.stopAfterRounds) {
            stopRecording();
        }
    };

    const pauseRecording = () => {
        if (mediaRecorderRef.current?.state === 'recording') {
            mediaRecorderRef.current.pause();
            setIsPaused(true);
            if (timerRef.current) clearInterval(timerRef.current);
        }
    };

    const resumeRecording = () => {
        if (mediaRecorderRef.current?.state === 'paused') {
            mediaRecorderRef.current.resume();
            setIsPaused(false);
            timerRef.current = window.setInterval(() => setTimer(t => t + 1), 1000);
        }
    };

    const stopRecording = () => {
        if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
            mediaRecorderRef.current.stop();
        }
        if (streamRef.current) {
            streamRef.current.getTracks().forEach(track => track.stop());
            streamRef.current = null;
        }
        if (timerRef.current) clearInterval(timerRef.current);
        
        setIsRecording(false);
        setIsPaused(false);
    };

    const saveRecording = () => {
        if (chunksRef.current.length === 0) return;
        const blob = new Blob(chunksRef.current, { type: 'video/webm' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        a.download = `madiao_match_${timestamp}.webm`;
        document.body.appendChild(a);
        a.click();
        setTimeout(() => { document.body.removeChild(a); window.URL.revokeObjectURL(url); }, 100);
    };

    useEffect(() => {
        return () => { if (streamRef.current || isRecording) stopRecording(); };
    }, []);

    return {
        isRecording, isPaused, timer, config,
        updateConfig, prepareStream, startRecording, stopRecording, pauseRecording, resumeRecording,
        notifyRoundEnd, // EXPORTED FOR GAME LOGIC
        error
    };
};
