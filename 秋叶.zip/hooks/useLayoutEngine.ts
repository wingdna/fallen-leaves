
import { useState, useEffect, useRef } from 'react';
import { LayoutStrategy, getLayoutStrategy } from '../services/layoutConfig';

// --- PARALLAX ENGINE (视差引擎) ---
const useParallax = (baseStrategy: LayoutStrategy) => {
    const [offset, setOffset] = useState({ x: 0, y: 0 });
    const requestRef = useRef<number | null>(null);
    const targetRef = useRef({ x: 0, y: 0 });
    const currentRef = useRef({ x: 0, y: 0 });

    useEffect(() => {
        const handleMouseMove = (e: MouseEvent) => {
            const { innerWidth, innerHeight } = window;
            
            // [视差区域限制 - Anti-Motion Sickness V2]
            // 设定触发阈值：仅屏幕上方 25% 区域（仅限窗户/顶部装饰）响应视差
            // 只要鼠标接近牌桌上边缘（约 30% 位置），就强制归零
            const ACTIVE_ZONE_THRESHOLD = 0.25;
            
            if (e.clientY < innerHeight * ACTIVE_ZONE_THRESHOLD) {
                // 活跃区：计算视差目标
                const x = (e.clientX / innerWidth) * 2 - 1;
                // 让 Y 轴的移动更敏感一点，因为区域很小
                const y = ((e.clientY / (innerHeight * ACTIVE_ZONE_THRESHOLD)) * 2 - 1) * 0.5; 
                targetRef.current = { x, y };
            } else {
                // 稳定区：平滑归位到中心
                // 当玩家在操作手牌或查看牌桌时，背景停止晃动
                targetRef.current = { x: 0, y: 0 };
            }
        };

        const handleOrientation = (e: DeviceOrientationEvent) => {
            // Beta: 前后倾斜 (-180 to 180), Gamma: 左右倾斜 (-90 to 90)
            if (e.beta !== null && e.gamma !== null) {
                // 限制角度范围并归一化，防止过度旋转
                const x = Math.min(Math.max(e.gamma, -45), 45) / 45;
                const y = Math.min(Math.max(e.beta - 45, -45), 45) / 45; 
                targetRef.current = { x, y };
            }
        };

        // 平滑插值循环 (LERP) - 制造“重量感”和“电影感”
        const update = () => {
            // 阻尼系数: 0.05 = 非常沉稳/平滑, 0.2 = 响应灵敏
            const factor = 0.05; 
            currentRef.current.x += (targetRef.current.x - currentRef.current.x) * factor;
            currentRef.current.y += (targetRef.current.y - currentRef.current.y) * factor;

            // 只有当变化显著时才更新状态，优化性能
            if (Math.abs(currentRef.current.x - offset.x) > 0.001 || Math.abs(currentRef.current.y - offset.y) > 0.001) {
                 setOffset({ x: currentRef.current.x, y: currentRef.current.y });
            }
            
            requestRef.current = requestAnimationFrame(update);
        };

        if (typeof window !== 'undefined') {
            // Desktop
            window.addEventListener('mousemove', handleMouseMove);
            // Mobile
            if (window.DeviceOrientationEvent) {
                window.addEventListener('deviceorientation', handleOrientation);
            }
            requestRef.current = requestAnimationFrame(update);
        }

        return () => {
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('deviceorientation', handleOrientation);
            if (requestRef.current) cancelAnimationFrame(requestRef.current);
        };
    }, []); // Empty dependency array ensures listeners bind once

    // 将视差数据应用到策略中
    const modifiedStrategy = { ...baseStrategy };
    
    // 强度配置
    const ROTATE_INTENSITY_X = 4; // 上下倾斜角度 (Pitch)
    const ROTATE_INTENSITY_Y = 6; // 左右旋转角度 (Yaw)
    const MOVE_INTENSITY = 25;    // 背景位移像素

    // [ARCHITECT FIX] Do NOT modify baseStrategy.camera directly.
    // Instead, export the deltas separately so Scene3D can choose where to apply them.
    // This allows the table to remain static while the background moves.
    
    (modifiedStrategy as any).parallax = {
        rotateX: -(offset.y * ROTATE_INTENSITY_X), // Negative because mouse up (negative Y) should look up (positive rotateX)
        rotateY: offset.x * ROTATE_INTENSITY_Y,
        translateX: offset.x * -MOVE_INTENSITY,
        translateY: offset.y * -MOVE_INTENSITY
    };

    return modifiedStrategy;
};

export const useLayoutEngine = (): LayoutStrategy & { parallax?: { rotateX: number, rotateY: number, translateX: number, translateY: number } } => {
    const getInitialStrategy = () => {
        const w = typeof window !== 'undefined' ? window.innerWidth : 1280;
        const h = typeof window !== 'undefined' ? window.innerHeight : 720;
        return getLayoutStrategy(w, h);
    };

    const [strategy, setStrategy] = useState<LayoutStrategy>(getInitialStrategy);

    useEffect(() => {
        const handleResize = () => {
            try {
                const newStrategy = getLayoutStrategy(window.innerWidth, window.innerHeight);
                // 仅当模式改变时才更新，避免频繁重绘
                setStrategy(prev => prev.mode !== newStrategy.mode ? newStrategy : prev);
            } catch (err) {
                console.error("Layout Engine Update Failed:", err);
            }
        };

        let timeoutId: any;
        const debouncedResize = () => {
            clearTimeout(timeoutId);
            timeoutId = setTimeout(handleResize, 150);
        };

        window.addEventListener('resize', debouncedResize);
        handleResize();

        return () => {
            window.removeEventListener('resize', debouncedResize);
            clearTimeout(timeoutId);
        };
    }, []);

    // 增强：应用视差效果
    const dynamicStrategy = useParallax(strategy);

    return dynamicStrategy;
};
