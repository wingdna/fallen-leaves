
import { useState, useEffect, useRef } from 'react';
import { Player, PlayerType, GamePhase, SupportedLanguage } from '../types';
import { getAIMove, generateSpeech, sendMessageToTutor } from '../services/geminiService'; 
import { LOCAL_VERNACULAR_MESSAGES } from '../services/maDiaoKnowledgeBase';
import { useGameSettings } from '../hooks/useGameSettings'; 

interface UseAIAgentProps {
    gameState: any; 
    gameActions: any;
    audioSystem: any;
    isMuted: boolean;
    language: SupportedLanguage;
}

export const useAIAgent = ({ gameState, gameActions, audioSystem, isMuted, language }: UseAIAgentProps) => {
    const [mentorMessage, setMentorMessage] = useState<string | null>(null);
    const [thinkingPlayers, setThinkingPlayers] = useState<Set<number>>(new Set()); // New State
    
    const processingRef = useRef(false);
    const lastSpeechTime = useRef<number>(0);
    const { masterFrequency } = useGameSettings(); 

    const { 
        players, currentPlayerIndex, phase, trickNumber, tableCards, 
        recordedCards, bankerId, difficulty, gameHistory, openedSuits, 
        firstLeadInfo, mianZhangCard, lastGameEvent, trickWinnerId
    } = gameState;

    // AI 决策执行 (现在大部分由本地师父算法秒回)
    useEffect(() => {
        const currentPlayer = players[currentPlayerIndex];
        const shouldMove = phase === GamePhase.PLAYING && trickNumber < 8 && currentPlayer?.type === PlayerType.AI && tableCards.length < 4 && !trickWinnerId && !processingRef.current;

        if (shouldMove) {
            processingRef.current = true;
            setThinkingPlayers(prev => new Set(prev).add(currentPlayer.id)); // Start Thinking UI

            // 极短的思考模拟延迟，提升拟真感
            const timer = setTimeout(async () => {
                try {
                    const move = await getAIMove(currentPlayer, tableCards.map((t: any) => ({card: t.card, playerId: t.playerId})), players, recordedCards, bankerId, difficulty, gameHistory, openedSuits, firstLeadInfo, trickNumber, mianZhangCard);
                    if (move) await gameActions.executePlayCard(currentPlayer.id, move.id); 
                } catch (e) { 
                    // 兜底：如果意外出错，打出第一张牌
                    if (currentPlayer.hand.length > 0) await gameActions.executePlayCard(currentPlayer.id, currentPlayer.hand[0].id);
                } finally { 
                    processingRef.current = false; 
                    setThinkingPlayers(prev => {
                        const next = new Set(prev);
                        next.delete(currentPlayer.id);
                        return next;
                    }); // End Thinking UI
                }
            }, 300 + Math.random() * 200); 
            return () => clearTimeout(timer);
        }
    }, [currentPlayerIndex, phase, tableCards.length, trickWinnerId, trickNumber]);

    // 导师教学逻辑：仅在发生显著违例或极低频率闲聊时触发
    useEffect(() => {
        if (!lastGameEvent) return;

        // 1. Bai Lao Revealed
        if (lastGameEvent.type === 'BAI_LAO_REVEALED') {
            const msgs = LOCAL_VERNACULAR_MESSAGES.BAI_LAO_REVEALED;
            const msg = msgs[Math.floor(Math.random() * msgs.length)];
            speakText(msg);
            return;
        }

        // 2. Suspected Bai Lao (Bao Bai)
        if (lastGameEvent.type === 'SUSPECTED_BAI_LAO') {
            const msgs = LOCAL_VERNACULAR_MESSAGES.SUSPECTED_BAI_LAO;
            const msg = msgs[Math.floor(Math.random() * msgs.length)];
            speakText(msg);
            return;
        }

        // 3. Violations
        if (lastGameEvent.type === 'VIOLATION' && lastGameEvent.playerId === 0) {
            const ruleId = lastGameEvent.context?.ruleId;
            let msg = "";

            if (ruleId === 'LOU_ZHUANG' || ruleId === 'LOU_ZHUANG_FAIL') {
                msg = LOCAL_VERNACULAR_MESSAGES.VIOLATION_LOU_ZHUANG[Math.floor(Math.random() * LOCAL_VERNACULAR_MESSAGES.VIOLATION_LOU_ZHUANG.length)];
            } else if (ruleId === 'JI_ZHUO') {
                msg = LOCAL_VERNACULAR_MESSAGES.VIOLATION_JI_ZHUO[Math.floor(Math.random() * LOCAL_VERNACULAR_MESSAGES.VIOLATION_JI_ZHUO.length)];
            } else if (ruleId === 'JIN_MEN_CI_XU') {
                msg = LOCAL_VERNACULAR_MESSAGES.VIOLATION_JIN_MEN[Math.floor(Math.random() * LOCAL_VERNACULAR_MESSAGES.VIOLATION_JIN_MEN.length)];
            }

            if (msg) speakText(msg);
            return;
        }

        // 4. Win Feedback
        if (masterFrequency === 'HIGH' || (masterFrequency === 'NORMAL' && Math.random() > 0.85)) {
            if (lastGameEvent?.type === 'TRICK_WIN' && lastGameEvent.playerId === 0) {
                speakText(LOCAL_VERNACULAR_MESSAGES.TRICK_WIN[Math.floor(Math.random() * 3)]);
            }
        }
    }, [lastGameEvent]);

    const speakText = async (message: string) => {
        if (!message || Date.now() - lastSpeechTime.current < 4000) return; // Reduced cooldown for critical events
        lastSpeechTime.current = Date.now();
        setMentorMessage(message);
        
        setTimeout(() => { setMentorMessage(null); }, 6000); 

        if (!isMuted) {
            try {
                const audioData = await generateSpeech(message, 'Charon');
                if (audioData) audioSystem.playPcmAudio(audioData);
            } catch (e) { }
        }
    }

    return { 
        aiChatMessages: { 99: mentorMessage },
        thinkingPlayers // Exported
    };
};
