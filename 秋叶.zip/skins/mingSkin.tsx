
// ... existing imports and assets ...
import React from 'react';
import { ISkin, CardStyleProps } from '../types/skin';
import { LeadingEffectType, Suit, CardColor } from '../types';
import { StoveLighting } from '../components/Visuals/TableEffects';

// ... (Keep PlantainShadow, BambooShadows, MingAtmosphere, getWoodTexture, MingCardBack, MingEffectOverlay, Chair unchanged) ...
// For brevity, I'm skipping the full re-definition of helper components but ensuring they are here for the final output.

// 1. DYNAMIC SHADOW ASSETS
const PlantainShadow = () => (
    <svg viewBox="0 0 100 100" className="absolute top-[-20%] right-[-20%] w-[140%] h-[140%] pointer-events-none opacity-40 mix-blend-multiply" style={{ transformOrigin: 'top right' }}>
        <defs><filter id="blurShadow" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur in="SourceGraphic" stdDeviation="8" /></filter></defs>
        <g className="animate-sway-heavy" style={{ transformOrigin: 'top right' }}><path d="M100,0 Q60,40 20,20 T0,80" stroke="none" fill="#0f0500" filter="url(#blurShadow)" opacity="0.6" /><path d="M90,-10 Q50,50 10,30 T-10,90" stroke="none" fill="#0f0500" filter="url(#blurShadow)" opacity="0.4" /></g>
    </svg>
);

const BambooShadows = () => (
    <div className="absolute inset-0 pointer-events-none opacity-30 mix-blend-multiply overflow-hidden">
        <div className="absolute inset-0 animate-sway-light origin-top-right" style={{ backgroundImage: `radial-gradient(ellipse at 80% 20%, #0a0300 0%, transparent 10%), radial-gradient(ellipse at 75% 25%, #0a0300 0%, transparent 8%), radial-gradient(ellipse at 85% 15%, #0a0300 0%, transparent 12%), linear-gradient(120deg, transparent 40%, rgba(10,3,0,0.3) 45%, transparent 50%)`, backgroundSize: '150% 150%', filter: 'blur(2px)' }}></div>
    </div>
);

const MingAtmosphere: React.FC<{ quality?: 'HIGH' | 'MEDIUM' | 'LOW' }> = React.memo(({ quality }) => {
    const isHigh = quality === 'HIGH';
    const isLow = quality === 'LOW';
    const bgGradient = 'radial-gradient(circle at 60% 40%, #4a2c20 0%, #2a120a 50%, #0d0402 100%)';
    if (isLow) {
        return ( <div className="absolute inset-0 pointer-events-none z-[-1] overflow-hidden bg-[#0d0402]"><div className="absolute inset-0" style={{ background: 'linear-gradient(to bottom right, #4a2c20, #0d0402)' }}></div><div className="absolute inset-0 bg-black/30"></div></div> );
    }
    return (
        <div className="absolute inset-0 pointer-events-none z-[-1] overflow-hidden bg-[#0d0402]">
            <div className="absolute inset-0" style={{ background: bgGradient }}></div>
            <div className="absolute top-[-20%] right-[-10%] w-[80%] h-[80%] bg-[#ffaa55] blur-[100px] opacity-20 mix-blend-screen animate-pulse-slow"></div>
            {isHigh && (
                <>
                    <div className="absolute inset-0 opacity-10 mix-blend-screen pointer-events-none" style={{ background: 'conic-gradient(from 45deg at 80% 0%, transparent 0%, rgba(255,200,150,0.3) 10%, transparent 20%, rgba(255,200,150,0.1) 30%, transparent 50%)', filter: 'blur(40px)', transform: 'scale(1.5)' }}></div>
                    <PlantainShadow /><BambooShadows />
                    <div className="absolute inset-0 opacity-20 mix-blend-overlay bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] animate-dust-float"></div>
                </>
            )}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_30%,rgba(10,5,2,0.6)_80%,rgba(0,0,0,0.9)_100%)] pointer-events-none"></div>
            <style>{` @keyframes swayHeavy { 0% { transform: rotate(0deg) translate(0,0); } 50% { transform: rotate(2deg) translate(10px, 5px); } 100% { transform: rotate(0deg) translate(0,0); } } @keyframes swayLight { 0% { transform: scale(1) translate(0,0); } 33% { transform: scale(1.02) translate(-5px, 2px); } 66% { transform: scale(0.98) translate(3px, -1px); } 100% { transform: scale(1) translate(0,0); } } .animate-sway-heavy { animation: swayHeavy 12s ease-in-out infinite; } .animate-sway-light { animation: swayLight 6s ease-in-out infinite; } `}</style>
        </div>
    );
});

const getWoodTexture = (quality?: string) => {
    if (quality === 'LOW') return 'linear-gradient(to bottom right, #3e1e12, #2b120a)';
    return `repeating-linear-gradient(115deg, rgba(0,0,0,0.1) 0px, rgba(0,0,0,0.05) 1px, transparent 2px, transparent 8px), radial-gradient(circle at 30% 40%, rgba(60,20,0,0.2) 0%, transparent 20%), radial-gradient(circle at 70% 70%, rgba(50,15,0,0.2) 0%, transparent 25%), radial-gradient(ellipse at 50% 50%, rgba(80,30,10,0.1) 0%, transparent 60%), linear-gradient(to bottom right, rgba(62,30,18,0.9), rgba(40,15,8,0.95))`;
};

const MingCardBack: React.FC<{ isSmall?: boolean }> = ({ isSmall }) => (
    <div className="absolute inset-0 w-full h-full rounded-[inherit] overflow-hidden bg-[#3e1e12] flex items-center justify-center shadow-inner border border-[#5c3a21]">
        <div className="absolute inset-0 bg-gradient-to-br from-[#5c3a21] to-[#2b120a]"></div>
        <div className="absolute inset-0 opacity-30" style={{ backgroundImage: 'repeating-linear-gradient(45deg, rgba(0,0,0,0.2) 0px, transparent 1px, transparent 5px)' }}></div>
        {!isSmall && (<div className="relative z-10 w-6 h-16 flex items-center justify-center border-y border-[#a1887f]/30"><span className="text-[#d7ccc8] font-serif font-bold text-lg writing-vertical-rl opacity-70 select-none shadow-[0_1px_1px_rgba(0,0,0,0.5)]">明</span></div>)}
    </div>
);

const MingEffectOverlay: React.FC<{ effect: LeadingEffectType }> = ({ effect }) => {
    if (!effect) return null;
    return (
        <div className="absolute inset-[-2px] rounded-[inherit] pointer-events-none z-[50] border-[1px] border-[#ffdb7a] shadow-[0_0_20px_#ffdb7a] opacity-60 animate-pulse mix-blend-screen"></div>
    );
};

const Chair: React.FC<{ position?: string }> = ({ position }) => {
    return (
        <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-2xl opacity-90">
            <path d="M20,100 L20,45 Q50,35 80,45 L80,100" fill="#2d150a" stroke="#1a0b05" strokeWidth="1" />
            <path d="M20,45 L20,20 Q50,10 80,20 L80,45" fill="none" stroke="#3e1e12" strokeWidth="3" />
            <line x1="25" y1="48" x2="75" y2="48" stroke="#5c3a21" strokeWidth="1" opacity="0.5" />
        </svg>
    );
};

export const MingSkin: ISkin = {
    id: 'ming_scholar',
    name: 'Ming Scholar (Hainan Huanghuali)',
    description: 'Aged Huanghuali in dappled sunset light. Poetic & Secluded.',

    layout: {
        backgroundClass: "bg-[#0d0402]", 
        atmosphereComponent: MingAtmosphere,
        EnvironmentalShadows: () => null, 
        tableSurfaceClass: "rounded-[8px] shadow-[0_40px_120px_black] border-none overflow-hidden",
        tableBaseColor: '#3e1e12', 
        tableTexture: getWoodTexture('HIGH'), 
        tableTextureSize: '100% 100%',
        tableReflectivity: true,
        tableBorderClass: "bg-[#2b120a] border-t border-[#5c3a21]/30" 
    },

    card: {
        getContainerClass: (props: CardStyleProps) => {
            let sizeClass = 'w-16 h-24 md:w-20 md:h-32';
            if (props.isSmall) sizeClass = props.isRotated ? 'w-14 h-10' : 'w-10 h-14';
            else if (props.isTrick) sizeClass = props.isRotated ? 'w-24 h-14 md:w-32 md:h-20' : 'w-14 h-24 md:w-20 md:h-32';
            else if (props.isHand) sizeClass = props.isRotated ? 'w-20 h-12 md:w-24 md:h-16' : 'w-14 h-24 md:w-20 md:h-32'; 
            
            let bgClass = props.isInverted 
                ? 'bg-[#2b120a] text-[#e6c278] ring-1 ring-[#5c3a21]' 
                : 'bg-[#f0ece2] text-[#1a1a1a]'; 
            
            if (props.isFaceDown) bgClass = 'bg-[#3e1e12]';
            if (props.isDisabled) bgClass = 'bg-[#1a1a1a] opacity-40 grayscale';
            
            let hoverClass = 'transition-transform duration-300 ease-out';
            if (!props.isFaceDown && !props.isHand && !props.isDisabled) { 
                hoverClass += ' hover:-translate-y-2 hover:shadow-[0_15px_30px_rgba(0,0,0,0.6)] cursor-pointer hover:brightness-105'; 
            }
            
            let transformClass = ''; 
            if (props.isSelected) {
                const lift = props.isHand ? '' : '-translate-y-6';
                transformClass = `${lift} scale-105 z-[100] shadow-[0_20px_50px_rgba(0,0,0,0.6)] ring-2 ring-[#ffdb7a]/80`;
            } else if (props.isSuggested) {
                // [NEW] Tutorial Highlight Style for Ming Skin
                transformClass = '-translate-y-5 z-40 ring-4 ring-[#ffdb7a] shadow-[0_0_20px_rgba(255,219,122,0.6)] brightness-110';
            }
            
            return `relative flex flex-col group rounded-[3px] ${sizeClass} ${bgClass} ${hoverClass} ${transformClass}`;
        },
        getMainColorClass: (color, isInverted) => {
            if (isInverted) return 'text-[#ffdb7a] font-serif tracking-widest drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]'; 
            if (color === CardColor.RED) return 'text-[#a52a2a] font-bold font-serif opacity-90 mix-blend-multiply'; 
            if (color === CardColor.GREEN) return 'text-[#2e5c3e] font-bold font-serif opacity-95 mix-blend-multiply'; 
            return 'text-[#1a1a1a] font-bold font-serif opacity-90 mix-blend-multiply'; 
        },
        getPokerColorClass: (suit, isInverted) => {
            if (isInverted) return 'text-[#ffdb7a]';
            const isRedSuit = suit === Suit.STRINGS || suit === Suit.TEXTS;
            return isRedSuit ? 'text-[#a52a2a]' : 'text-[#1a1a1a]';
        },
        getBorderClass: (props) => {
            if (props.isFaceDown) return 'border border-[#2b120a]';
            if (props.isWinner) return 'border-[2px] border-[#ffdb7a] shadow-[0_0_15px_rgba(255,219,122,0.5)]';
            if (props.isSelected) return 'border-none'; 
            if (props.isSuggested) return 'border border-[#ffdb7a]'; // Gold hint
            return 'border-[0.5px] border-[#a1887f]/20'; 
        },
        getShadowClass: (props) => {
            if (props.isFaceDown) return 'shadow-[0_2px_8px_rgba(0,0,0,0.8)]'; 
            return 'shadow-[0_2px_6px_rgba(0,0,0,0.2)]'; 
        },
        BackComponent: MingCardBack,
        EffectOverlay: MingEffectOverlay
    },

    hud: {
        avatarContainerClass: (isMyTurn, isBanker, isBaiLao) => `
            relative w-16 h-16 md:w-20 md:h-20 rounded-full flex items-center justify-center 
            transition-all duration-500 overflow-hidden bg-[#2b120a]
            ${isMyTurn 
                ? 'border-[2px] border-[#ffdb7a] shadow-[0_0_30px_rgba(255,219,122,0.3)] scale-110 z-50' 
                : (isBanker 
                    ? 'border-[2px] border-[#8c1c0b] opacity-100 shadow-[0_0_15px_rgba(140,28,11,0.3)]'
                    : (isBaiLao ? 'border-[2px] border-[#047857] opacity-100 shadow-[0_0_15px_rgba(4,120,87,0.3)]' : 'border border-[#5c3a21] opacity-80 grayscale-[0.3]')
                  )
            }
        `,
        buttonClass: (disabled) => `
            relative min-w-[140px] h-12 rounded-[2px] flex items-center justify-center transition-all duration-300 font-serif tracking-[0.25em] font-bold text-sm shadow-lg
            ${!disabled 
                ? 'bg-[#3e1e12] text-[#d7ccc8] border border-[#5c3a21] hover:bg-[#4e2617] hover:border-[#ffdb7a] hover:text-[#fff] shadow-[0_4px_10px_rgba(0,0,0,0.5)]' 
                : 'bg-[#1a0b05] text-[#444] border border-[#2b120a] cursor-not-allowed'}
        `,
        modalOverlayClass: "fixed inset-0 z-[300] flex items-center justify-center bg-[#0d0402]/95 backdrop-blur-sm p-4 animate-fade-in font-serif",
        modalContentClass: "bg-[#1a0b05] border border-[#3e1e12] p-6 w-full max-w-4xl rounded-[4px] shadow-[0_0_150px_black] relative overflow-hidden text-[#d7ccc8] bg-[url('https://www.transparenttextures.com/patterns/wood-pattern.png')]"
    },

    lighting: {
        StoveLighting: StoveLighting,
        TableBorderFlow: () => null 
    },

    character: { 
        bodyFront: ({ quality }) => <div className="w-full h-full bg-black/60 blur-xl rounded-[50%] transform scale-y-60 translate-y-4"></div>, 
        bodySideLeft: ({ quality }) => <div className="w-full h-full bg-black/60 blur-xl rounded-[50%] transform scale-y-60 translate-y-4"></div>,
        bodySideRight: ({ quality }) => <div className="w-full h-full bg-black/60 blur-xl rounded-[50%] transform scale-y-60 translate-y-4"></div>,
        headOutline: '',
        chairComponent: Chair
    }
};
