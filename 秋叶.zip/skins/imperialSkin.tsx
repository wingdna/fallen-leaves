
import React, { useMemo } from 'react';
import { ISkin, CardStyleProps } from '../types/skin';
import { LeadingEffectType, Suit, CardColor } from '../types';
import { TableBorderFlow, StoveLighting } from '../components/Visuals/TableEffects';

// 1. 大漆洒金纹理 (Da Qi Sa Jin)
const SA_JIN_TEXTURE_HIGH = `
    radial-gradient(circle, rgba(255,223,0,0.6) 1px, transparent 1.5px),
    radial-gradient(circle, rgba(197,160,89,0.3) 0.5px, transparent 1px),
    radial-gradient(circle at 50% 50%, #2a1c1a 0%, #180805 60%, #000000 100%)
`;

const JapaneseTeaSet = ({ quality, timeOfDay }: { quality?: string, timeOfDay: number }) => {
    if (quality === 'LOW') return null;
    const embers = useMemo(() => Array.from({ length: 5 }).map((_, i) => ({ id: i, left: 40 + Math.random() * 20, delay: Math.random() * 2, duration: 2 + Math.random() * 1.5 })), []);
    
    // Day logic: Reduce glow intensity
    const isDay = timeOfDay > 6 && timeOfDay < 17;
    const glowOpacity = isDay ? 0.3 : 1.0;

    return (
        <div className="absolute bottom-[-5%] right-[-8%] w-[420px] h-[420px] z-50 pointer-events-none origin-bottom-right transform scale-100">
            <div className="absolute bottom-[-20%] right-[-20%] w-[150%] h-[100%] rounded-full z-[-1] animate-fire-breathe-slow mix-blend-screen pointer-events-none" style={{ background: 'radial-gradient(circle at 70% 80%, rgba(255,140,50,0.35) 0%, rgba(255,80,20,0.15) 40%, rgba(100,40,10,0.05) 70%, transparent 100%)', filter: 'blur(60px)', opacity: glowOpacity }}></div>
            <div className="absolute top-[-80%] left-[-20%] w-[200%] h-[200%] z-[60] pointer-events-none mix-blend-plus-lighter" style={{ filter: 'blur(8px)' }}>
                 <style>{` @keyframes steamFlow { 0% { transform: translateY(0) scale(0.8) rotate(0deg); opacity: 0; filter: blur(5px); } 20% { opacity: 0.6; filter: blur(8px); } 50% { opacity: 0.4; transform: translateY(-120px) scale(1.5) rotate(10deg); } 100% { transform: translateY(-250px) scale(2.5) rotate(20deg); opacity: 0; filter: blur(15px); } } .steam-particle { background: radial-gradient(circle, rgba(255,200,150,0.6) 0%, rgba(255,255,255,0.2) 40%, transparent 70%); } `}</style>
                 {[...Array(3)].map((_, i) => ( <div key={i} className="absolute bottom-[45%] left-[28%] w-24 h-40 steam-particle rounded-full animate-steam-rise-slow" style={{ animation: `steamFlow ${4 + i}s infinite linear`, animationDelay: `${i * 1.5}s`, transformOrigin: 'bottom center', opacity: glowOpacity }}></div> ))}
            </div>
            <svg viewBox="0 0 200 200" className="w-full h-full overflow-visible drop-shadow-[0_50px_100px_rgba(0,0,0,0.8)]">
                <defs>
                    <filter id="clayRough"><feTurbulence type="fractalNoise" baseFrequency="0.6" numOctaves="4" result="noise" /><feDiffuseLighting in="noise" lightingColor="#ffaa88" surfaceScale="2"><feDistantLight azimuth="45" elevation="30" /></feDiffuseLighting><feComposite operator="in" in2="SourceGraphic" /><feBlend mode="multiply" in2="SourceGraphic" /></filter>
                    <filter id="castIron"><feTurbulence type="fractalNoise" baseFrequency="1.5" numOctaves="3" result="noise" /><feColorMatrix type="matrix" values="0.3 0 0 0 0  0 0.3 0 0 0  0 0 0.3 0 0  0 0 0 1 0" /><feComposite operator="in" in2="SourceGraphic" /></filter>
                    <linearGradient id="fireGlowBottom" x1="0%" y1="100%" x2="0%" y2="0%"><stop offset="0%" stopColor="#ff5722" stopOpacity="0.9" /><stop offset="20%" stopColor="#ff9800" stopOpacity="0.6" /><stop offset="50%" stopColor="#333" stopOpacity="0" /></linearGradient>
                    <radialGradient id="charcoalCore" cx="50%" cy="50%" r="50%"><stop offset="0%" stopColor="#fff" /><stop offset="30%" stopColor="#ffcc00" /><stop offset="70%" stopColor="#ff4500" /><stop offset="100%" stopColor="#3e1e12" /></radialGradient>
                </defs>
                <g className="mix-blend-screen" style={{ opacity: glowOpacity }}>{embers.map(e => (<circle key={e.id} cx={e.left} cy="90" r={0.8 + Math.random()} fill="#ffd700" opacity="0"><animate attributeName="cy" from="90" to="20" dur={`${e.duration}s`} begin={`${e.delay}s`} repeatCount="indefinite" /><animate attributeName="opacity" values="0;1;0" dur={`${e.duration}s`} begin={`${e.delay}s`} repeatCount="indefinite" /><animate attributeName="cx" values={`${e.left};${e.left + 10};${e.left - 5}`} dur={`${e.duration}s`} begin={`${e.delay}s`} repeatCount="indefinite" /></circle>))}</g>
                <g transform="translate(50, 110)"><path d="M10,0 L90,0 L85,80 L15,80 Z" fill="#7c2a18" stroke="#3e1e12" strokeWidth="1" filter={quality === 'HIGH' ? "url(#clayRough)" : undefined} /><ellipse cx="50" cy="0" rx="40" ry="8" fill="url(#charcoalCore)" className="animate-pulse-fire-heavy" style={{ opacity: glowOpacity }} /><rect x="35" y="50" width="30" height="20" fill="#2a0e08" rx="2" stroke="#4e2618" /><circle cx="50" cy="60" r="5" fill="#ff9800" filter="blur(3px)" className="animate-pulse-fire-fast" style={{ opacity: glowOpacity }} /></g>
                <g transform="translate(100, 105) scale(0.8)"><path d="M-35,-40 Q-45,-120 0,-125 Q45,-120 35,-40" fill="none" stroke="#1a1a1a" strokeWidth="6" strokeLinecap="round" /><path d="M-45,-10 Q-70,-30 -75,-60 L-65,-65 Q-55,-35 -40,-20 Z" fill="#222" /><circle cx="0" cy="0" r="55" fill="#222" filter={quality === 'HIGH' ? "url(#castIron)" : undefined} /><path d="M-45,30 Q0,55 45,30 L40,45 Q0,70 -40,45 Z" fill="url(#fireGlowBottom)" style={{ mixBlendMode: 'screen', opacity: glowOpacity }} className="animate-pulse-fire-heavy" /><circle cx="0" cy="0" r="55" fill="url(#fireGlowBottom)" opacity={0.4 * glowOpacity} style={{ mixBlendMode: 'overlay' }} className="animate-pulse-fire-heavy" /><ellipse cx="0" cy="-45" rx="28" ry="10" fill="#333" stroke="#111" strokeWidth="2" /><circle cx="0" cy="-52" r="8" fill="#5c4033" stroke="#222" /><path d="M-45,10 Q0,55 45,10" fill="none" stroke="rgba(255,200,100,0.1)" strokeWidth="4" filter="blur(2px)" /></g>
            </svg>
        </div>
    );
};

const ImperialCat = ({ quality }: { quality?: string }) => {
    if (quality === 'LOW') return null;
    return (
        <div className="absolute bottom-[20%] right-[6%] z-[35] w-40 h-32 pointer-events-none origin-bottom transform scale-110 drop-shadow-[0_20px_30px_rgba(0,0,0,0.9)]">
            <div className="absolute bottom-[5%] left-[10%] w-[80%] h-[20%] bg-black/80 blur-[8px] rounded-[50%] transform scale-y-50"></div>
            <svg viewBox="0 0 300 200" className="w-full h-full overflow-visible">
                <defs>
                    <radialGradient id="catOrange" cx="40%" cy="30%" r="80%"><stop offset="0%" stopColor="#f6ad55" /> <stop offset="50%" stopColor="#c05621" /> <stop offset="100%" stopColor="#7b341e" /> </radialGradient>
                    <linearGradient id="fireRimLight" x1="100%" y1="50%" x2="0%" y2="50%"><stop offset="0%" stopColor="#ff7b00" stopOpacity="0.6" /><stop offset="20%" stopColor="#ffaa00" stopOpacity="0.2" /><stop offset="100%" stopColor="transparent" /></linearGradient>
                    {quality === 'HIGH' && (<filter id="fluffyFur"><feTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves="4" result="noise" /><feDisplacementMap in="SourceGraphic" in2="noise" scale="4" /><feGaussianBlur stdDeviation="0.5" /></filter>)}
                </defs>
                <g className="animate-breathe-sleep origin-bottom">
                    <path d="M60,160 Q50,90 110,60 Q190,30 250,70 Q290,110 280,170 Q230,200 160,195 Q90,190 60,160 Z" fill="url(#catOrange)" filter={quality === 'HIGH' ? "url(#fluffyFur)" : undefined} />
                    <g opacity="0.6" style={{ mixBlendMode: 'multiply' }} filter="blur(1px)"><path d="M120,60 Q130,90 120,110" stroke="#7b341e" strokeWidth="6" fill="none" /><path d="M150,55 Q160,85 150,105" stroke="#7b341e" strokeWidth="6" fill="none" /><path d="M180,55 Q190,85 180,105" stroke="#7b341e" strokeWidth="6" fill="none" /></g>
                    <path d="M250,70 Q290,110 280,170 Q260,180 250,170" fill="none" stroke="url(#fireRimLight)" strokeWidth="12" strokeLinecap="round" filter="blur(4px)" style={{ mixBlendMode: 'screen' }} />
                    <path d="M280,160 Q300,180 260,195" fill="none" stroke="url(#catOrange)" strokeWidth="22" strokeLinecap="round" filter={quality === 'HIGH' ? "url(#fluffyFur)" : undefined} className="animate-tail-sway origin-left" />
                    <path d="M70,100 L60,70 L90,85" fill="#f6ad55" /><path d="M110,80 L130,50 L140,80" fill="#f6ad55" />
                </g>
            </svg>
            <style>{` @keyframes breatheCatRealistic { 0%, 100% { transform: scaleY(1); } 50% { transform: scaleY(1.03); } } .animate-breathe-sleep { animation: breatheCatRealistic 4s ease-in-out infinite; } @keyframes tailSway { 0%, 100% { transform: rotate(0deg); } 50% { transform: rotate(5deg); } } .animate-tail-sway { animation: tailSway 8s ease-in-out infinite; } `}</style>
        </div>
    );
};

// [UPDATED] Wax Plum (Winter Sweet) - Dimmer, Smaller, More Ethereal
const WinterSweetBranch = () => (
    <div className="absolute top-0 left-0 w-full h-full pointer-events-none z-25 overflow-visible">
        {/* Scale reduced from 1.0 to 0.85, Opacity reduced for 'fade' look */}
        <div className="absolute top-[-5%] left-[-5%] w-[60vw] h-[50vh] origin-top-left animate-branch-sway opacity-85 transform scale-90" style={{ animationDelay: '-5s', animationDuration: '30s' }}>
            <svg viewBox="0 0 800 600" className="w-full h-full drop-shadow-[5px_10px_20px_rgba(0,0,0,0.6)]">
                <defs>
                    <linearGradient id="waxPetalGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                        {/* Dimmer colors: Parchment/Old Silk instead of bright neon yellow */}
                        <stop offset="0%" stopColor="#f3e5ab" stopOpacity="0.9" /> {/* Vanilla */}
                        <stop offset="60%" stopColor="#e6c288" stopOpacity="0.85" /> {/* Lathe Gold */}
                        <stop offset="100%" stopColor="#c5a059" stopOpacity="0.7" /> {/* Bronze */}
                    </linearGradient>
                    <radialGradient id="waxCenterGrad" cx="50%" cy="50%" r="50%">
                        <stop offset="0%" stopColor="#cc5500" /> {/* Burnt Orange */}
                        <stop offset="100%" stopColor="#5c1a1a" /> {/* Deep Red */}
                    </radialGradient>
                    <filter id="waxGlow">
                        <feGaussianBlur stdDeviation="1.0" result="blur" />
                        <feComposite in="SourceGraphic" in2="blur" operator="over" />
                    </filter>
                </defs>
                
                {/* Thin, Iron-wire Branches (Tie Xian Miao) - Thinner strokes */}
                <g stroke="#120a05" strokeLinecap="round" fill="none">
                    {/* Main Branch */}
                    <path d="M0,50 Q150,150 250,120 T550,280" strokeWidth="4" />
                    {/* Sub Branches */}
                    <path d="M250,120 Q300,80 350,50" strokeWidth="3" />
                    <path d="M400,200 Q450,250 420,320" strokeWidth="2" />
                    <path d="M150,100 Q180,180 160,240" strokeWidth="2" />
                </g>

                {/* Exaggerated Wax Plum Flowers (Reduced Size: r~45 -> r~35) */}
                <WaxPlumNode x={250} y={120} r={35} />
                <WaxPlumNode x={350} y={50} r={28} />
                <WaxPlumNode x={550} y={280} r={38} />
                <WaxPlumNode x={420} y={320} r={30} />
                <WaxPlumNode x={160} y={240} r={28} />
                <WaxPlumNode x={480} y={230} r={18} /> {/* Bud */}
            </svg>
        </div>
    </div>
);

const WaxPlumNode = ({ x, y, r }: { x: number, y: number, r: number }) => (
    <g transform={`translate(${x}, ${y})`} filter="url(#waxGlow)">
        {/* Outer Petals (Translucent Wax) */}
        {[0, 60, 120, 180, 240, 300].map((angle) => (
            <path 
                key={angle} 
                d={`M0,0 Q${r},-${r*0.6} ${r*1.2},0 T0,${r*0.6} Z`} 
                fill="url(#waxPetalGrad)" 
                transform={`rotate(${angle})`} 
                opacity="0.85"
            />
        ))}
        {/* Inner Center */}
        <circle cx="0" cy="0" r={r*0.25} fill="url(#waxCenterGrad)" />
        <circle cx="0" cy="0" r={r*0.1} fill="#3d0e0e" />
    </g>
);

// [NEW] Snowy Bamboo Cluster - Matches the sway of the plum
const SnowyBambooCluster = () => (
    <div className="absolute top-0 right-0 w-full h-full pointer-events-none z-20 overflow-visible">
        {/* Positioned Right, swaying with slight delay */}
        <div className="absolute top-[-5%] right-[-10%] w-[50vw] h-[60vh] origin-top-right animate-bamboo-sway-slow" style={{ animationDelay: '-8s', animationDuration: '12s' }}>
            <svg viewBox="0 0 600 800" className="w-full h-full drop-shadow-[10px_20px_30px_rgba(0,0,0,0.7)]">
                <defs>
                    <linearGradient id="bambooStem" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#0f1a0f" />
                        <stop offset="50%" stopColor="#1a2e1a" />
                        <stop offset="100%" stopColor="#050a05" />
                    </linearGradient>
                    <linearGradient id="bambooLeaf" x1="0%" y1="0%" x2="0%" y2="100%">
                        <stop offset="0%" stopColor="#2d4a2d" />
                        <stop offset="100%" stopColor="#142614" />
                    </linearGradient>
                    <filter id="snowCap">
                        <feTurbulence type="fractalNoise" baseFrequency="0.1" numOctaves="2" result="noise" />
                        <feDisplacementMap in="SourceGraphic" in2="noise" scale="2" />
                        <feGaussianBlur stdDeviation="0.5" />
                    </filter>
                </defs>

                {/* Stems */}
                <g stroke="url(#bambooStem)" strokeLinecap="round" fill="none">
                    <path d="M500,0 Q480,200 520,400" strokeWidth="12" />
                    <path d="M400,-50 Q380,150 420,350" strokeWidth="8" />
                    {/* Nodes */}
                    <path d="M490,150 L510,148" stroke="#000" strokeWidth="2" opacity="0.5" />
                    <path d="M390,100 L410,98" stroke="#000" strokeWidth="2" opacity="0.5" />
                </g>

                {/* Leaves & Snow */}
                <BambooLeafGroup x={520} y={400} rotate={10} scale={1.2} />
                <BambooLeafGroup x={480} y={250} rotate={-15} scale={1.0} />
                <BambooLeafGroup x={420} y={350} rotate={5} scale={0.9} />
                <BambooLeafGroup x={400} y={150} rotate={-20} scale={0.8} />
                <BambooLeafGroup x={550} y={500} rotate={30} scale={1.1} />
            </svg>
        </div>
    </div>
);

const BambooLeafGroup = ({ x, y, rotate, scale }: { x: number, y: number, rotate: number, scale: number }) => (
    <g transform={`translate(${x}, ${y}) rotate(${rotate}) scale(${scale})`}>
        {/* Leaf 1 */}
        <g transform="rotate(0)">
            <path d="M0,0 Q15,5 40,0 Q15,-5 0,0" fill="url(#bambooLeaf)" />
            {/* Snow Cap */}
            <path d="M5,-2 Q20,-6 35,-1 Q20,-3 5,-2" fill="#fff" opacity="0.85" filter="url(#snowCap)" />
        </g>
        {/* Leaf 2 */}
        <g transform="rotate(45)">
            <path d="M0,0 Q15,5 35,0 Q15,-5 0,0" fill="url(#bambooLeaf)" />
            <path d="M8,-2 Q20,-5 30,-1 Q20,-3 8,-2" fill="#fff" opacity="0.8" filter="url(#snowCap)" />
        </g>
        {/* Leaf 3 */}
        <g transform="rotate(-30)">
            <path d="M0,0 Q15,5 30,0 Q15,-5 0,0" fill="url(#bambooLeaf)" />
            <path d="M5,-2 Q15,-5 25,-1" fill="none" stroke="#fff" strokeWidth="2" opacity="0.6" filter="url(#snowCap)" />
        </g>
    </g>
);

const GooseFeatherSnow = ({ quality }: { quality?: string }) => {
    if (quality === 'LOW') return null;
    const count = quality === 'HIGH' ? 8 : 4;
    return (
        <div className="absolute inset-0 pointer-events-none z-[5] overflow-hidden">
            {[...Array(count)].map((_, i) => (
                <div key={i} className="absolute rounded-full bg-white blur-[1px] animate-snow-goose" style={{ left: `${Math.random() * 120 - 10}%`, top: `-10%`, width: `${Math.random() * 8 + 6}px`, height: `${Math.random() * 8 + 6}px`, opacity: Math.random() * 0.4 + 0.3, animationDuration: `${30 + Math.random() * 60}s`, animationDelay: `-${Math.random() * 60}s` }} />
            ))}
        </div>
    );
};

const OutdoorSceneryProjection = ({ quality, timeOfDay }: { quality?: string, timeOfDay: number }) => {
    // Determine Time Colors
    // 0-5 Night, 6-8 Sunrise, 9-16 Day, 17-19 Sunset, 20-24 Night
    let bgStyle: React.CSSProperties = { background: '#05080a' };
    
    if (timeOfDay >= 6 && timeOfDay < 9) { // Sunrise
        bgStyle = { background: 'linear-gradient(145deg, #1a2333 0%, #d97706 70%, #9a3412 100%)' };
    } else if (timeOfDay >= 9 && timeOfDay < 17) { // Day
        bgStyle = { background: 'linear-gradient(145deg, #3b82f6 0%, #60a5fa 60%, #93c5fd 100%)' };
    } else if (timeOfDay >= 17 && timeOfDay < 20) { // Sunset
        bgStyle = { background: 'linear-gradient(145deg, #4c1d95 0%, #c2410c 60%, #f97316 100%)' };
    } else { // Night
        bgStyle = { background: 'linear-gradient(145deg, #05080a 0%, #121821 40%, #1a0805 100%)' };
    }

    const isNight = timeOfDay < 6 || timeOfDay >= 19;

    return (
        <div className="absolute inset-0 z-0 overflow-hidden">
            <div className="absolute inset-0 transition-colors duration-[5000ms]" style={bgStyle}>
                 {isNight && (
                     <>
                        <div className="absolute top-[-40%] left-[-30%] w-[120%] h-[120%] bg-[radial-gradient(circle_at_center,#aaddff_0%,transparent_60%)] opacity-30 blur-[100px] mix-blend-screen"></div>
                        <div className="absolute bottom-[-30%] right-[-30%] w-[100%] h-[100%] bg-[radial-gradient(circle_at_center,#ff8800_0%,rgba(255,100,0,0.2)_50%,transparent_80%)] opacity-40 blur-[120px] mix-blend-screen animate-pulse-slow"></div>
                     </>
                 )}
                 {!isNight && (
                     <div className="absolute top-0 right-0 w-[50%] h-[50%] bg-[radial-gradient(circle_at_center,#ffeb3b_0%,transparent_70%)] opacity-40 blur-[80px] mix-blend-screen"></div>
                 )}
            </div>
            
            <SnowyBambooCluster />
            <WinterSweetBranch />
            
            {quality === 'HIGH' && (
                <div className="absolute inset-0 pointer-events-none">
                    {[...Array(6)].map((_, i) => (<div key={i} className="absolute rounded-full bg-[#020202] blur-[12px] animate-snow-shadow" style={{ left: `${Math.random() * 120 - 10}%`, width: `${Math.random() * 40 + 20}px`, height: `${Math.random() * 30 + 20}px`, animationDuration: `${12 + Math.random() * 8}s`, animationDelay: `-${Math.random() * 10}s`, opacity: 0.5 }} />))}
                </div>
            )}
            <GooseFeatherSnow quality={quality} />
        </div>
    );
};

const TableSnowflakes = ({ quality }: { quality?: string }) => {
    if (quality === 'LOW') return null;
    const count = quality === 'HIGH' ? 8 : 3;
    return (
        <div className="absolute inset-0 pointer-events-none z-[40] overflow-hidden">
            {Array.from({ length: count }).map((_, i) => (
                <div key={i} className="absolute bg-white/20 rounded-full opacity-0 animate-snow-lifecycle-windy" style={{ left: `${Math.random() * 100}%`, top: `-${Math.random() * 20}%`, width: `${Math.random() * 2 + 1}px`, height: `${Math.random() * 2 + 1}px`, animationDelay: `${Math.random() * 5}s`, animationDuration: `${8 + Math.random() * 5}s` }}></div>
            ))}
        </div>
    );
};

const TeaRoomAtmosphere: React.FC<{ quality?: 'HIGH' | 'MEDIUM' | 'LOW', timeOfDay: number }> = React.memo(({ quality, timeOfDay }) => {
    const isNight = timeOfDay < 6 || timeOfDay >= 18;
    
    // Dynamic Window Light Intensity
    let windowOpacity = 0.08;
    let windowColor = 'rgba(240, 230, 220, 0.08)';
    
    if (timeOfDay >= 9 && timeOfDay <= 15) { // Bright Day
        windowOpacity = 0.2;
        windowColor = 'rgba(255, 250, 240, 0.2)';
    }

    if (quality === 'LOW') {
        return ( <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden bg-[#080402]"><div className="absolute inset-0" style={{ background: 'linear-gradient(to bottom right, #4a2c20, #0d0402)' }}></div><div className="absolute inset-0 bg-black/30"></div></div> );
    }
    
    return (
        <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden bg-[#080402]"> 
            <div className="absolute inset-0 perspective-[800px] overflow-hidden">
                <div className="absolute top-[40%] left-[-50%] right-[-50%] h-[120%] origin-top transform rotateX(55deg) bg-[#1a100a] shadow-[inset_0_50px_200px_black]">
                    <div className="absolute inset-0 opacity-30" style={{ backgroundImage: `repeating-linear-gradient(105deg, rgba(0,0,0,0.5) 0px, rgba(0,0,0,0.5) 2px, transparent 2px, transparent 240px)`, backgroundColor: '#2c1e15', backgroundBlendMode: 'multiply' }}></div>
                    {isNight && (
                        <div className="absolute bottom-[5%] right-[5%] w-[100%] h-[80%] origin-bottom-right animate-pulse-fire-heavy" style={{ background: 'radial-gradient(ellipse at bottom right, rgba(255, 80, 20, 0.4) 0%, rgba(200, 100, 50, 0.1) 40%, transparent 80%)', filter: 'blur(50px)', mixBlendMode: 'screen' }}></div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-transparent via-black/60 to-black/95 pointer-events-none"></div>
                </div>
            </div>
            <div className="absolute top-0 left-0 right-0 h-[40%] z-10 flex items-end">
                <div className="h-full w-[25%] bg-[#0f0805] relative border-r-[12px] border-[#0a0503] box-border shadow-[inset_-20px_0_50px_black]">
                    <div className="absolute inset-0 opacity-10 mix-blend-multiply bg-[url('https://www.transparenttextures.com/patterns/wood-pattern.png')]"></div>
                </div>
                <div className="relative h-full w-[75%] bg-[#050201] border-r-[20px] border-[#050201] box-border shadow-[inset_0_0_80px_black] overflow-hidden">
                    <OutdoorSceneryProjection quality={quality} timeOfDay={timeOfDay} />
                    <div className="absolute inset-0 z-10 transition-colors duration-[5000ms]" style={{ backgroundColor: windowColor, backdropFilter: 'blur(6px) contrast(1.15) brightness(1.1)', mixBlendMode: 'hard-light' }}>
                        {quality === 'HIGH' && (<div className="absolute inset-0 opacity-30 mix-blend-multiply" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`, filter: 'contrast(1.5)' }}></div>)}
                        <div className="absolute inset-0 opacity-40 mix-blend-overlay bg-[url('https://www.transparenttextures.com/patterns/rice-paper.png')]"></div>
                        <div className="absolute inset-0 bg-[radial-gradient(circle,transparent_40%,rgba(0,0,0,0.6)_100%)]"></div>
                    </div>
                    <div className="absolute inset-0 z-20 pointer-events-none">
                         <div className="absolute top-0 left-0 right-0 h-[5%] bg-[#120a06] shadow-[0_5px_20px_black] border-b border-[#2a1810]/30"></div>
                         <div className="absolute top-[30%] w-full h-[4px] bg-[#0a0503] shadow-sm"></div>
                         <div className="absolute top-[55%] w-full h-[4px] bg-[#0a0503] shadow-sm"></div>
                         <div className="absolute top-[5%] bottom-[20%] left-0 right-0 flex justify-evenly px-[15%]">{[...Array(2)].map((_, i) => ( <div key={i} className="w-[4px] h-full bg-[#0a0503] shadow-sm"></div> ))}</div>
                         <div className="absolute bottom-0 left-0 right-0 h-[20%] bg-[#0d0705] shadow-[0_-5px_20px_black]">
                             <div className="absolute inset-0 opacity-20 mix-blend-overlay bg-[url('https://www.transparenttextures.com/patterns/wood-pattern.png')]"></div>
                             <div className="absolute top-0 left-0 right-0 h-[1px] bg-[#3e2b22] opacity-30"></div>
                         </div>
                    </div>
                </div>
            </div>
            <ImperialCat quality={quality} /> 
            <JapaneseTeaSet quality={quality} timeOfDay={timeOfDay} />
            <TableSnowflakes quality={quality} />
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_60%_40%,transparent_30%,rgba(0,0,0,0.6)_80%,rgba(0,0,0,0.95)_100%)] pointer-events-none z-[60]"></div>
            <style>{` @keyframes steamRiseSlow { 0% { transform: translateY(0) scale(1) rotate(-10deg); opacity: 0; } 20% { opacity: 0.5; } 100% { transform: translateY(-150px) scale(3) rotate(5deg); opacity: 0; } } .animate-steam-rise-slow { animation: steamRiseSlow 6s infinite linear; } @keyframes steamDrift { 0% { transform: translate(0, 0) scale(1); opacity: 0; } 40% { opacity: 0.3; } 100% { transform: translate(40px, -60px) scale(2); opacity: 0; } } .animate-steam-drift { animation: steamDrift 8s infinite ease-out; } @keyframes breatheCatRealistic { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.015); } } .animate-breathe-cat-realistic { animation: breatheCatRealistic 5s ease-in-out infinite; } @keyframes bambooSwaySlow { 0%, 100% { transform: rotate(6deg); } 50% { transform: rotate(8deg); } 100% { transform: rotate(6deg); } } .animate-bamboo-sway-slow { animation: bambooSwaySlow 12s ease-in-out infinite; } @keyframes swayShadow { 0% { transform: rotate(0deg) scale(1); } 50% { transform: rotate(2deg) scale(1.05); } 100% { transform: rotate(0deg) scale(1); } } .animate-sway-shadow { animation: swayShadow 8s ease-in-out infinite; } @keyframes snowLifecycleWindy { 0% { transform: translateY(-20px) translateX(0) rotate(0deg) scale(1); opacity: 0; } 10% { opacity: 0.6; } 70% { transform: translateY(70vh) translateX(-150px) rotate(180deg) scale(1); opacity: 0.4; } 100% { transform: translateY(72vh) translateX(-190px) rotate(220deg) scale(3); opacity: 0; } } .animate-snow-lifecycle-windy { animation: snowLifecycleWindy linear infinite; } @keyframes snowShadowFall { 0% { transform: translateY(-20%) translateX(0) rotate(0deg); opacity: 0; } 20% { opacity: 0.5; } 80% { opacity: 0.5; } 100% { transform: translateY(120%) translateX(30px) rotate(45deg); opacity: 0; } } .animate-snow-shadow { animation: snowShadowFall linear infinite; } @keyframes pulseFireHeavy { 0%, 100% { opacity: 0.85; transform: scale(1); filter: brightness(1); } 50% { opacity: 1; transform: scale(1.05); filter: brightness(1.2); } } .animate-pulse-fire-heavy { animation: pulseFireHeavy 4s ease-in-out infinite; } @keyframes pulseFireFast { 0% { opacity: 0.6; } 50% { opacity: 1; } 100% { opacity: 0.6; } } .animate-pulse-fire-fast { animation: pulseFireFast 0.5s ease-in-out infinite; } @keyframes fireBreatheSlow { 0% { opacity: 0.8; transform: scale(1); } 50% { opacity: 1; transform: scale(1.02); } 100% { opacity: 0.8; transform: scale(1); } } .animate-fire-breathe-slow { animation: fireBreatheSlow 5s ease-in-out infinite; } @keyframes snowGoose { 0% { transform: translateY(0) translateX(0) rotate(0deg); opacity: 0; } 10% { opacity: 0.8; } 90% { opacity: 0.6; } 100% { transform: translateY(120vh) translateX(-50px) rotate(360deg); opacity: 0; } } .animate-snow-goose { animation: snowGoose linear infinite; } @keyframes branchSway { 0%, 100% { transform: rotate(0deg) scale(1); } 50% { transform: rotate(2deg) scale(1.005); } } .animate-branch-sway { animation: branchSway 25s ease-in-out infinite; }`}</style>
        </div>
    );
});

const UrushiCardBack: React.FC<{ isSmall?: boolean }> = ({ isSmall }) => (
    <div className="absolute inset-0 w-full h-full rounded-[inherit] overflow-hidden bg-[#0f0a08] flex items-center justify-center border border-[#5c3a21] shadow-inner group">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,#2a1d15_0%,#000000_100%)]"></div>
        <div className="absolute inset-0 opacity-50" style={{ backgroundImage: `radial-gradient(circle, #ffd700 0.5px, transparent 1px)`, backgroundSize: '24px 24px' }}></div>
        <div className={`relative ${isSmall ? 'scale-50' : 'scale-75'} opacity-90 transition-transform duration-1000`}>
             <svg viewBox="0 0 200 200" className="w-24 h-24 drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
                <defs><linearGradient id="goldLuster" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stopColor="#b8860b" /><stop offset="50%" stopColor="#ffd700" /><stop offset="100%" stopColor="#b8860b" /></linearGradient></defs>
                <circle cx="100" cy="100" r="90" fill="none" stroke="url(#goldLuster)" strokeWidth="2" /><circle cx="100" cy="100" r="80" fill="none" stroke="url(#goldLuster)" strokeWidth="1" strokeDasharray="4 4" />
                <path d="M100,20 Q160,20 160,100 T100,180 T40,100 T100,20" fill="none" stroke="url(#goldLuster)" strokeWidth="3" strokeLinecap="round" /><path d="M100,40 Q140,40 140,100 T100,160 T60,100 T100,40" fill="none" stroke="url(#goldLuster)" strokeWidth="1.5" opacity="0.7" /><circle cx="100" cy="100" r="12" fill="url(#goldLuster)" />
             </svg>
        </div>
        <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-[1500ms] pointer-events-none"></div>
    </div>
);

const GoldDustOverlay: React.FC<{ effect: LeadingEffectType }> = ({ effect }) => {
    if (!effect) return null;
    return (
        <div className="absolute inset-[-10px] z-50 pointer-events-none flex items-center justify-center">
            <div className="w-[120%] h-[120%] rounded-full opacity-60 animate-pulse bg-[radial-gradient(circle,#ffd700_0%,transparent_70%)]" style={{ mixBlendMode: 'screen' }}></div>
        </div>
    );
};

export const ImperialSkin: ISkin = {
    id: 'imperial',
    name: '御制·听雪楼', 
    description: '寒夜茶室，黑漆描金，奢华深邃。',
    layout: {
        backgroundClass: `bg-[#0a0504]`, 
        atmosphereComponent: TeaRoomAtmosphere,
        
        // --- 牌桌：大漆洒金 (Black Lacquer with Scattered Gold) ---
        tableSurfaceClass: `rounded-[8px] shadow-[0_50px_120px_black] border-none overflow-hidden`,
        tableBaseColor: '#000000', 
        
        tableTexture: SA_JIN_TEXTURE_HIGH, 
        tableTextureSize: '110px 110px, 23px 23px, 100% 100%', 
        tableBorderClass: "bg-[#2a1b15] border-t border-[#3e2b22]",
        tableReflectivity: true 
    },
    card: {
        getContainerClass: (props: CardStyleProps) => {
            let sizeClass = 'w-12 h-18 md:w-24 md:h-36';
            if (props.isSmall) sizeClass = 'w-8 h-12';
            else if (props.isTrick) sizeClass = 'w-14 h-21 md:w-24 md:h-36'; 
            else if (props.isHand) sizeClass = 'w-14 h-21 md:w-24 md:h-36'; 
            
            let visualClass = '';
            if (props.isInverted) {
                // [VISUAL UPDATE] Unified Black Gold Style
                visualClass = 'bg-[#0f0a08] text-[#d4af37] border border-[#5c3a21] shadow-lg ring-1 ring-[#ffd700]/30';
            } else if (props.isFaceDown) {
                visualClass = 'bg-[#2b120a]';
            } else {
                visualClass = 'bg-[#fdfbf7] text-[#1a1a1a] shadow-[0_2px_10px_rgba(0,0,0,0.3)] border-[0.5px] border-[#a89f91]/30';
            }
            
            let hoverClass = 'transition-all duration-500 cubic-bezier(0.34, 1.56, 0.64, 1)'; 
            if (props.isHand && !props.isDisabled) {
                // [VISUAL FIX] Removed hover:-translate-y-6 hover:rotate-1 to keep cards fixed at initial position unless selected
                hoverClass += ' cursor-pointer'; 
            }
            
            let transformClass = '';
            if (props.isSelected) {
                const lift = props.isHand ? '' : '-translate-y-8';
                transformClass = `${lift} scale-110 z-50 drop-shadow-[0_20px_30px_rgba(0,0,0,0.5)]`; 
            } else if (props.isSuggested) {
                // [NEW] Tutorial Highlight Style
                // Gentle bounce + Golden Ring
                transformClass = '-translate-y-6 z-40 ring-4 ring-[#ffdb7a]/80 shadow-[0_0_20px_rgba(255,219,122,0.6)] animate-pulse-slow';
            }
            
            return `relative flex flex-col group items-center justify-center rounded-[2px] ${sizeClass} ${visualClass} ${hoverClass} ${transformClass}`;
        },
        getMainColorClass: (color, isInverted) => {
            if (isInverted) return 'text-[#d4af37] font-serif font-black drop-shadow-[0_1px_2px_black]';
            if (color === CardColor.RED) return 'text-[#8c1c0b] font-black font-calligraphy opacity-95 mix-blend-multiply'; 
            if (color === CardColor.GREEN) return 'text-[#105f42] font-black font-calligraphy opacity-95 mix-blend-multiply'; 
            return 'text-[#0f0500] font-black font-calligraphy opacity-90 mix-blend-multiply'; 
        },
        getPokerColorClass: (suit, isInverted) => {
            if (isInverted) return 'text-[#d4af37]';
            const isRedSuit = suit === Suit.STRINGS || suit === Suit.TEXTS;
            return isRedSuit ? 'text-[#8c1c0b] opacity-80' : 'text-[#2b120a] opacity-80'; 
        },
        getBorderClass: (props) => {
            if (props.isWinner) return 'border-[2px] border-[#d4af37] shadow-[0_0_20px_#d4af37]';
            if (props.isFaceDown) return 'border border-[#3e2b22]';
            if (props.isSuggested) return 'border border-[#ffdb7a]'; // Gold Border for suggestions
            return 'border-[0.5px] border-[#a89f91]/20';
        },
        getShadowClass: (props) => props.isFaceDown ? 'shadow-lg' : 'shadow-md',
        BackComponent: UrushiCardBack, 
        EffectOverlay: (props) => {
            return <GoldDustOverlay effect={props.effect} />;
        }
    },
    hud: {
        avatarContainerClass: (isMyTurn, isBanker, isBaiLao) => {
            let border = isMyTurn ? 'border-[#d4af37]' : (isBanker ? 'border-[#8c1c0b]' : (isBaiLao ? 'border-[#064e3b]' : 'border-[#3e2b22]'));
            let glow = isMyTurn ? 'shadow-[0_0_40px_rgba(212,175,55,0.6)] scale-110 z-50' : 'opacity-90 grayscale-[0.2]';
            return `w-14 h-14 md:w-20 md:h-20 rounded-full border-[3px] transition-all duration-700 bg-[#0a0504] overflow-hidden ${border} ${glow}`;
        },
        buttonClass: (disabled) => `
            min-w-[160px] h-12 rounded-[2px] font-serif tracking-[0.4em] text-sm font-black transition-all duration-500
            ${!disabled 
                ? 'bg-[#1a0f0a] text-[#d4af37] border border-[#5c3a21] hover:bg-[#2a1510] hover:border-[#ffd700] hover:shadow-[0_0_20px_rgba(212,175,55,0.3)]' 
                : 'bg-[#0f0a08] text-[#444] border border-[#222] cursor-not-allowed'}
        `,
        modalOverlayClass: "fixed inset-0 z-[300] flex items-center justify-center bg-[#050202]/95 backdrop-blur-md p-4 animate-fade-in",
        modalContentClass: "bg-[#0a0605] border border-[#3e2b22] p-8 w-full max-w-5xl rounded-[2px] text-[#a0a0a0] font-serif shadow-[0_0_100px_black] relative overflow-hidden"
    },
    lighting: { StoveLighting: StoveLighting, TableBorderFlow: TableBorderFlow },
    character: { 
        bodyFront: () => <div className="w-full h-full bg-black/60 blur-xl rounded-[50%] translate-y-12 scale-90"></div>, 
        bodySideLeft: () => null, 
        bodySideRight: () => null, 
        headOutline: '', 
        chairComponent: () => null 
    }
};
