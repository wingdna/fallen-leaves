
import React from 'react';
import { ISkin, CardStyleProps } from '../types/skin';
import { LeadingEffectType, Suit, CardColor } from '../types';

const INK_SMOKE = "radial-gradient(circle, rgba(255,255,255,0.03) 1px, transparent 1px)";

const TaoistAtmosphere: React.FC = () => {
    return (
        <div className="absolute inset-0 pointer-events-none z-[-1] overflow-hidden bg-[#eef2f3]">
            {/* High Key Lighting: Mist and Void */}
            <div className="absolute inset-0 bg-gradient-to-b from-[#f5f7fa] via-[#c3cfe2] to-[#cfd9df]"></div>
            
            {/* Drifting Ink Clouds */}
            <div className="absolute top-[-30%] left-[-20%] w-[150%] h-[150%] bg-[radial-gradient(circle,rgba(0,0,0,0.05)_0%,transparent_60%)] blur-[100px] animate-sway-slow"></div>
            
            {/* Subtle Texture */}
            <div className="absolute inset-0 opacity-30 mix-blend-multiply" 
                 style={{ 
                     backgroundImage: `url("https://www.transparenttextures.com/patterns/rice-paper.png")`, 
                     backgroundSize: '300px 300px' 
                 }}>
            </div>
        </div>
    );
};

const TaoistCardBack: React.FC<{ isSmall?: boolean }> = ({ isSmall }) => (
    <div className="absolute inset-0 w-full h-full rounded-[inherit] overflow-hidden bg-[#111] flex items-center justify-center border border-[#333]">
        <div className="absolute inset-0 bg-gradient-to-br from-[#1a1a1a] to-[#000]"></div>
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: INK_SMOKE, backgroundSize: '20px 20px' }}></div>
        
        {/* Abstract Tai Chi / Calligraphy Stroke */}
        <div className={`relative ${isSmall ? 'scale-50' : 'scale-75'} opacity-60 mix-blend-screen`}>
            <svg viewBox="0 0 100 100" className="w-16 h-16 animate-[spin_30s_linear_infinite]">
                <path d="M50,10 A40,40 0 1,0 50,90 A40,40 0 1,0 50,10 M50,10 A20,20 0 0,1 50,50 A20,20 0 0,0 50,90" fill="none" stroke="white" strokeWidth="2" strokeOpacity="0.5" />
            </svg>
        </div>
    </div>
);

const TaoistEffectOverlay: React.FC<{ effect: LeadingEffectType }> = ({ effect }) => {
    if (!effect) return null;
    return (
        <div className="absolute inset-[-10px] pointer-events-none z-[10] flex items-center justify-center">
            <div className="w-[120%] h-[120%] rounded-full blur-xl bg-black/10 animate-pulse transform scale-90"></div>
        </div>
    );
};

export const TaoistSkin: ISkin = {
    id: 'taoist_mystery',
    name: 'Taoist Void (Ink Stone)',
    description: 'A giant inkstone table, floating rice paper cards, Zen minimalism.',

    layout: {
        backgroundClass: "bg-[#cfd9df]",
        atmosphereComponent: TaoistAtmosphere,
        EnvironmentalShadows: () => null,
        
        // --- THE TABLE: GIANT INK STONE (SHE YAN) ---
        tableSurfaceClass: "shadow-[0_30px_100px_rgba(0,0,0,0.6)] border-none rounded-[2px] overflow-hidden",
        
        tableBaseColor: '#1c1c1c',
        
        tableTexture: `
            /* Gold Specks (Jin Xing) inherent in She Inkstone */
            radial-gradient(circle, rgba(255,215,0,0.15) 0.5px, transparent 0.6px),
            
            /* Wet Ink Look */
            linear-gradient(135deg, rgba(255,255,255,0.05) 0%, transparent 40%, rgba(0,0,0,0.8) 100%)
        `,
        tableTextureSize: '30px 30px',
        
        tableReflectivity: true, // Needs high reflectivity for wet ink look
        
        tableBorderClass: "bg-[#0f0f0f]"
    },

    card: {
        getContainerClass: (props: CardStyleProps) => {
            let sizeClass = 'w-16 h-24 md:w-20 md:h-32';
            if (props.isSmall) sizeClass = props.isRotated ? 'w-14 h-10' : 'w-10 h-14';
            else if (props.isTrick) sizeClass = props.isRotated ? 'w-24 h-16 md:w-28 md:h-20' : 'w-16 h-24 md:w-20 md:h-28';
            else if (props.isHand) sizeClass = props.isRotated ? 'w-20 h-12 md:w-24 md:h-16' : 'w-14 h-22 md:w-20 md:h-32';
            
            // RAW RICE PAPER (Xuan Zhi)
            let bgClass = props.isInverted ? 'bg-[#111] text-[#ccc] border border-[#333]' : 'bg-[#fdfbf7] text-[#111]';
            if (props.isFaceDown) bgClass = 'bg-[#111]';
            if (props.isDisabled) bgClass = 'bg-[#999] opacity-40 grayscale';
            
            // Shadow should be soft and diffuse, like paper floating on water
            let hoverClass = 'transition-all duration-500 ease-out';
            if (!props.isFaceDown && !props.isHand && !props.isDisabled) { 
                hoverClass += ' hover:-translate-y-3 hover:shadow-2xl cursor-pointer hover:scale-105'; 
            }
            
            let transformClass = ''; 
            if (props.isSelected) {
                const lift = props.isHand ? '' : '-translate-y-4';
                transformClass = `${lift} z-[100] scale-105 shadow-[0_20px_40px_rgba(0,0,0,0.2)]`;
            } else if (props.isSuggested) {
                // [NEW] Tutorial Highlight Style for Taoist Skin
                transformClass = '-translate-y-4 z-40 shadow-[0_0_30px_rgba(0,0,0,0.3)] animate-pulse border border-[#333]';
            }
            
            return `relative flex flex-col group rounded-[1px] ${sizeClass} ${bgClass} ${hoverClass} ${transformClass}`;
        },
        getMainColorClass: (color, isInverted) => {
            if (isInverted) return 'text-[#ccc] font-calligraphy tracking-widest'; 
            // Deep Cinnabar Red
            if (color === CardColor.RED) return 'text-[#9e1a1a] font-bold font-calligraphy opacity-90'; 
            // Deep Ink Black
            return 'text-[#0a0a0a] font-bold font-calligraphy opacity-95'; 
        },
        getPokerColorClass: (suit, isInverted) => {
            if (isInverted) return 'text-[#ccc]';
            const isRedSuit = suit === Suit.STRINGS || suit === Suit.TEXTS;
            return isRedSuit ? 'text-[#9e1a1a]' : 'text-[#0a0a0a]';
        },
        getBorderClass: (props) => {
            if (props.isFaceDown) return 'border border-[#333]';
            if (props.isWinner) return 'border-[2px] border-[#111]'; 
            if (props.isSelected) return 'border-[1px] border-[#555]';
            // Subtle torn edge effect simulated by low opacity border
            return 'border-[0.5px] border-[#000]/10';
        },
        getShadowClass: (props) => {
            if (props.isFaceDown) return 'shadow-[0_10px_30px_rgba(0,0,0,0.8)]';
            return 'shadow-[0_5px_15px_rgba(0,0,0,0.15)]';
        },
        BackComponent: TaoistCardBack,
        EffectOverlay: TaoistEffectOverlay
    },

    hud: {
        avatarContainerClass: (isMyTurn, isBanker, isBaiLao) => `
            relative w-20 h-20 md:w-24 md:h-24 rounded-full flex items-center justify-center 
            transition-all duration-1000 border-2
            ${isMyTurn 
                ? 'bg-white border-black shadow-[0_0_60px_rgba(255,255,255,0.6)] scale-105 z-50' 
                : (isBanker
                    ? 'bg-[#ddd] border-[#9e1a1a] opacity-100'
                    : (isBaiLao ? 'bg-[#ddd] border-[#2e5c3e] opacity-100' : 'bg-[#ccc] border-gray-500 opacity-60 grayscale')
                  )
            }
        `,
        buttonClass: (disabled) => `
            relative min-w-[140px] h-14 flex items-center justify-center transition-all duration-500 font-calligraphy tracking-[0.3em] rounded-sm text-sm font-bold shadow-lg
            ${!disabled 
                ? 'bg-[#1c1c1c] text-white border border-[#333] hover:bg-[#333] hover:shadow-[0_10px_30px_rgba(0,0,0,0.5)]' 
                : 'bg-[#b0bec5] text-[#546e7a] cursor-not-allowed'}
        `,
        modalOverlayClass: "fixed inset-0 z-[300] flex items-center justify-center bg-[#f0f4f8]/95 backdrop-blur-md p-4 animate-fade-in font-serif",
        modalContentClass: "bg-[#fdfbf7] border border-[#ccc] p-8 w-full max-w-5xl rounded-[2px] shadow-2xl relative overflow-hidden text-[#111]"
    },

    lighting: {
        StoveLighting: () => null,
        TableBorderFlow: () => null
    },

    character: {
        bodyFront: () => <div className="w-full h-full bg-black/20 blur-xl rounded-full transform scale-y-75"></div>,
        bodySideLeft: () => <div className="w-full h-full bg-black/20 blur-xl rounded-full transform scale-y-75"></div>,
        bodySideRight: () => <div className="w-full h-full bg-black/20 blur-xl rounded-full transform scale-y-75"></div>,
        headOutline: '',
        chairComponent: () => null
    }
};
