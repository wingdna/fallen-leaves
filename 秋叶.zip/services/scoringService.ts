
// @ARCHITECT_LOCK: SCORING KERNEL
import { Card, Suit, CardColor, CardRank, PatternDetail, ScoreResult, Player, KaiChongDetail, ViolationRecord, SupportedLanguage, SpecialCaptureFlags, TrickCard, DuoJinInfo } from '../types';
import { ID_WAN_WAN, ID_QIAN_WAN, ID_BAI_WAN, ID_20_WAN, ID_90_WAN, ID_1_GUAN, ID_1_SUO, ID_9_WEN, ID_5_GUAN, ID_6_GUAN, ID_8_GUAN, ID_KONG_WEN, ID_BAN_WEN, ID_1_WEN, ID_9_GUAN, ID_9_SUO } from '../constants';
import { evaluateKaiChong } from './kaiChongRules'; 

// --- HELPERS ---
const isRed = (card: Card) => card.color === CardColor.RED;
const isGreen = (card: Card) => card.color === CardColor.GREEN;
const isQu = (card: Card) => [ID_20_WAN, ID_1_GUAN, ID_1_SUO, ID_9_WEN].includes(card.id);
const isJin = (card: Card) => isRed(card) || isQu(card);
const isQing = (card: Card) => !isJin(card);

// Rank Helpers
const isZun = (c: Card) => c.rank === CardRank.ZUN;
const isJian = (c: Card) => c.rank === CardRank.JIAN;
const isJi = (c: Card) => c.rank === CardRank.JI;

const ID_50_WAN = 'c_4';
const ID_ZHI_HUA = ID_1_WEN; 

const ZUN_IDS = [ID_WAN_WAN, ID_9_GUAN, ID_9_SUO, ID_KONG_WEN];
const JIAN_IDS = [ID_QIAN_WAN, ID_8_GUAN, 'k_8', ID_BAN_WEN];
const QU_IDS = [ID_20_WAN, ID_1_GUAN, ID_1_SUO, ID_9_WEN];
const BAI_WAN_ID = ID_BAI_WAN;

type JinType = 'S' | 'J' | 'B' | 'Q';

const getJinType = (card: Card): JinType | null => {
    if (card.id === ID_BAI_WAN) return 'B';
    if (ZUN_IDS.includes(card.id)) return 'S';
    if (JIAN_IDS.includes(card.id)) return 'J';
    if (QU_IDS.includes(card.id)) return 'Q';
    return null;
};

export const identifyTianShengPatterns = (hand: Card[]): { details: PatternDetail[], score: number, isTianSheng: boolean } => {
    if (hand.length !== 8) return { details: [], score: 0, isTianSheng: false }; 

    const details: PatternDetail[] = [];
    let score = 0;

    const redCards = hand.filter(isRed);
    const redCount = redCards.length;
    const jinCount = hand.filter(isJin).length;
    
    const zunCount = hand.filter(isZun).length;
    const jianCount = hand.filter(isJian).length;
    const jiCount = hand.filter(isJi).length;
    
    const hasWan = hand.some(c => c.id === ID_WAN_WAN);
    const hasQian = hand.some(c => c.id === ID_QIAN_WAN);
    const hasBai = hand.some(c => c.id === ID_BAI_WAN);
    const has20Wan = hand.some(c => c.id === ID_20_WAN);

    const hasThreeFlags = hasWan && hasQian && hasBai;

    if (zunCount === 4 && jiCount === 4) { details.push({ name: '天地交泰', score: 60, cards: hand, category: 'SE_YANG' }); score += 60; }
    if (zunCount === 4 && jianCount === 4) { details.push({ name: '天人合一', score: 60, cards: hand, category: 'SE_YANG' }); score += 60; }
    if (jianCount === 4 && jiCount === 4) { details.push({ name: '人杰地灵', score: 50, cards: hand, category: 'SE_YANG' }); score += 50; }
    if (redCount === 7 && has20Wan) { details.push({ name: '七红醉杨妃', score: 50, cards: hand, category: 'SE_YANG' }); score += 50; }

    const bigThreeCount = [hasWan, hasQian, hasBai].filter(Boolean).length;
    if (bigThreeCount >= 2) {
        const requiredOtherSix = ['s_9', 's_8', 'k_9', 'k_8', 't_11', 't_10'];
        const hasAllSix = requiredOtherSix.every(id => hand.some(c => c.id === id));
        if (hasAllSix) { details.push({ name: '拗鸳鸯', score: 40, cards: hand, category: 'SE_YANG' }); score += 40; }
    }

    if (jinCount === 8) {
        const counts = { [Suit.CASH]: 0, [Suit.STRINGS]: 0, [Suit.COINS]: 0, [Suit.TEXTS]: 0 };
        hand.forEach(c => counts[c.suit]++);
        if (Object.values(counts).every(c => c === 2)) { details.push({ name: '锦鸳鸯', score: 40, cards: hand, category: 'SE_YANG' }); score += 40; }
    }

    if (jianCount === 4 && hasBai && zunCount === 0) { details.push({ name: '凤凰雏', score: 32, cards: hand, category: 'SE_YANG' }); score += 32; }
    if (jinCount === 8) { details.push({ name: '片片锦', score: 30, cards: hand, category: 'SE_YANG' }); score += 30; }

    const baMeIds = [ID_WAN_WAN, ID_QIAN_WAN, ID_BAI_WAN, ID_1_GUAN, ID_1_SUO, ID_1_WEN, ID_BAN_WEN, ID_KONG_WEN];
    if (hand.every(c => baMeIds.includes(c.id))) { details.push({ name: '八么', score: 20, cards: hand, category: 'SE_YANG' }); score += 20; }

    if (zunCount === 4 && hasBai && jianCount === 0) { details.push({ name: '麒麟种', score: 16, cards: hand, category: 'SE_YANG' }); score += 16; }
    if (jiCount === 4 && hasBai && zunCount === 0) { details.push({ name: '雪中炭', score: 5, cards: hand, category: 'SE_YANG' }); score += 5; }

    if (redCount >= 6) { details.push({ name: '六红', score: 6, cards: redCards, category: 'SE_YANG' }); score += 6; }
    if (redCount >= 7) { details.push({ name: '七红', score: 7, cards: redCards, category: 'SE_YANG' }); score += 7; }
    if (redCount === 8) { details.push({ name: '八红', score: 8, cards: redCards, category: 'SE_YANG' }); score += 8; }

    if (hasThreeFlags) {
        if (redCount >= 6) { details.push({ name: '六红顺风旗', score: 6, cards: redCards, category: 'SE_YANG' }); score += 6; }
        if (redCount >= 7) { details.push({ name: '七红顺风旗', score: 7, cards: redCards, category: 'SE_YANG' }); score += 7; }
        if (redCount === 8) { details.push({ name: '八红顺风旗', score: 8, cards: redCards, category: 'SE_YANG' }); score += 8; }
    }

    const suits = [Suit.CASH, Suit.STRINGS, Suit.COINS, Suit.TEXTS];
    for (const suit of suits) {
        const suitCards = hand.filter(c => c.suit === suit).sort((a,b) => b.value - a.value); 
        const count = suitCards.length;
        if (count >= 7) { details.push({ name: '七同', score: 7, cards: suitCards, category: 'SE_YANG' }); score += 7; }
        if (count === 8) { details.push({ name: '八同', score: 8, cards: suitCards, category: 'SE_YANG' }); score += 8; }

        const isRun = (cards: Card[]) => {
            for (let i = 0; i < cards.length - 1; i++) { if (cards[i].value - cards[i+1].value !== 1) return false; }
            return true;
        };

        if (count === 8) {
            if (isRun(suitCards)) { details.push({ name: '八顺', score: 20, cards: suitCards, category: 'SE_YANG' }); score += 20; details.push({ name: '七顺', score: 10, cards: suitCards, category: 'SE_YANG' }); score += 10; } 
            else if (isRun(suitCards.slice(0, 7)) || isRun(suitCards.slice(1, 8))) { details.push({ name: '七顺', score: 10, cards: suitCards, category: 'SE_YANG' }); score += 10; }
        } else if (count === 7) {
            if (isRun(suitCards)) { details.push({ name: '七顺', score: 10, cards: suitCards, category: 'SE_YANG' }); score += 10; }
        }
    }

    const qingCount = hand.filter(isQing).length;
    if (qingCount === 8) {
        const maxVal = Math.max(...hand.map(c => c.value));
        if (maxVal < 6) { details.push({ name: '八小', score: 8, cards: hand, category: 'SE_YANG' }); score += 8; }
    }
    
    const isBig = hand.every(c => c.rank === CardRank.ZUN || c.rank === CardRank.JIAN || c.rank === CardRank.BAI || c.value >= 7);
    if (isBig) { details.push({ name: '八大', score: 8, cards: hand, category: 'SE_YANG' }); score += 8; }

    return { details, score, isTianSheng: score > 0 };
};

const identifyFourSuitPatterns = (cards: Card[]): PatternDetail | null => {
    const jinCards = cards.filter(c => isJin(c));
    const bySuit: Record<Suit, Card[]> = { [Suit.CASH]: [], [Suit.STRINGS]: [], [Suit.COINS]: [], [Suit.TEXTS]: [] };
    jinCards.forEach(c => bySuit[c.suit].push(c));
    
    if (bySuit[Suit.CASH].length === 0 || bySuit[Suit.STRINGS].length === 0 || bySuit[Suit.COINS].length === 0 || bySuit[Suit.TEXTS].length === 0) return null;

    let bestScore = -1;
    let bestDetail: PatternDetail | null = null;

    for (const c1 of bySuit[Suit.CASH]) {
        for (const c2 of bySuit[Suit.STRINGS]) {
            for (const c3 of bySuit[Suit.COINS]) {
                for (const c4 of bySuit[Suit.TEXTS]) {
                    const combo = [c1, c2, c3, c4];
                    const types = combo.map(getJinType);
                    const counts = { S: 0, J: 0, B: 0, Q: 0 };
                    types.forEach(t => { if(t) counts[t]++ });
                    
                    const has20Wan = combo.some(c => c.id === ID_20_WAN);
                    let baseScore = 0; let name = '';
                    const { S, J, B, Q } = counts;

                    if (B===1 && Q===3) { name = '百鲫鱼背'; baseScore = 100; }
                    else if (J===1 && Q===3) { name = '肩鲫鱼背'; baseScore = 80; }
                    else if (S===1 && Q===3) { name = '赏鲫鱼背'; baseScore = 60; }
                    else if (B===1 && J===1 && Q===2) { name = '百肩四极'; baseScore = 48; }
                    else if (J===2 && Q===2) { name = '肩天地分'; baseScore = 32; }
                    else if (B===1 && S===1 && Q===2) { name = '百赏四极'; baseScore = 32; }
                    else if (S===1 && J===1 && Q===2) { name = '小天地分'; baseScore = 28; }
                    else if (S===2 && Q===2) { name = '天地分'; baseScore = 24; }
                    else if (B===1 && J===2 && Q===1) { name = '百极四肩'; baseScore = 24; }
                    else if (B===1 && J===3) { name = '花比肩'; baseScore = 20; }
                    else if (J===3 && Q===1) { name = '巧四肩'; baseScore = 20; }
                    else if (B===1 && S===2 && Q===1) { name = '百极四赏'; baseScore = 16; }
                    else if (B===1 && J===2 && S===1) { name = '百长肩'; baseScore = 16; }
                    else if (J===2 && S===1 && Q===1) { name = '极长肩'; baseScore = 16; }
                    else if (B===1 && J===1 && S===1 && Q===1) { name = '节节高'; baseScore = 16; }
                    else if (J===4) { name = '千均柱'; baseScore = 16; }
                    else if (B===1 && J===1 && S===2) { name = '百短肩'; baseScore = 14; }
                    else if (J===1 && S===2 && Q===1) { name = '极短肩'; baseScore = 14; }
                    else if (J===3 && S===1) { name = '长肩'; baseScore = 14; }
                    else if (B===1 && S===3) { name = '花肚兜'; baseScore = 12; }
                    else if (S===3 && Q===1) { name = '巧四赏'; baseScore = 12; }
                    else if (J===2 && S===2) { name = '对肩'; baseScore = 12; }
                    else if (J===1 && S===3) { name = '短肩'; baseScore = 10; }
                    else if (S===4) { name = '皇会图'; baseScore = 8; }

                    if (baseScore > 0) {
                        let bonus = has20Wan ? 5 : 0;
                        const comboIds = new Set(combo.map(c => c.id));
                        const surplus = jinCards.filter(c => !comboIds.has(c.id));
                        surplus.forEach(c => { const t = getJinType(c); if (t === 'B') bonus += 4; else if (t === 'Q') bonus += 3; else if (t === 'J') bonus += 2; else if (t === 'S') bonus += 1; });
                        const total = baseScore + bonus;
                        if (total > bestScore) { bestScore = total; bestDetail = { name: `${name} (含溢出)`, score: total, cards: combo, category: 'SE_YANG' }; }
                    }
                }
            }
        }
    }
    return bestDetail;
};

const checkSequence = (pile: Card[], idsA: string[], idsB: string[], allowRedBetween: boolean): boolean => {
    const idxA = pile.findIndex(c => idsA.includes(c.id));
    if (idxA === -1) return false;
    for (let i = idxA + 1; i < pile.length; i++) {
        const c = pile[i];
        if (idsB.includes(c.id)) return true; 
        if (allowRedBetween) { if (isQing(c)) return false; } else { return false; }
    }
    return false;
};

const checkConsecutivePair = (pile: Card[], id1: string, id2: string): boolean => {
    for (let i = 0; i < pile.length - 1; i++) {
        const c1 = pile[i]; const c2 = pile[i+1];
        if ((c1.id === id1 && c2.id === id2) || (c1.id === id2 && c2.id === id1)) return true;
    }
    return false;
};

const getSequenceCards = (pile: Card[], idsA: string[], idsB: string[]): Card[] => {
    const idxA = pile.findIndex(c => idsA.includes(c.id));
    if (idxA === -1) return [];
    const startCard = pile[idxA]; let endCard: Card | null = null;
    for (let i = idxA + 1; i < pile.length; i++) {
        const c = pile[i];
        if (idsB.includes(c.id)) { endCard = c; break; }
    }
    return endCard ? [startCard, endCard] : [];
};

const getConsecutivePairCards = (pile: Card[], id1: string, id2: string): Card[] => {
    for (let i = 0; i < pile.length - 1; i++) {
        const c1 = pile[i]; const c2 = pile[i+1];
        if ((c1.id === id1 && c2.id === id2) || (c1.id === id2 && c2.id === id1)) return [c1, c2];
    }
    return [];
};

const identifyQiaoDouPatterns = (player: Player): PatternDetail[] => {
    const details: PatternDetail[] = [];
    const mainTricks = player.trickPile.filter(t => t.round <= 8 && !t.isKaiChong).sort((a,b) => a.round - b.round);
    const pile = mainTricks.map(t => t.card);
    const count = pile.length;
    if (count === 0) return [];
    
    const isZhengBen = count >= 2;
    const card1 = pile[0];
    const cardLast = count >= 2 ? pile[count - 1] : null;

    const tableCardsA = mainTricks.map(t => t.card);
    const fullDeck = [...player.hand, ...tableCardsA];
    
    const holdsWan = fullDeck.some(c => c.id === ID_WAN_WAN);
    const holdsQian = fullDeck.some(c => c.id === ID_QIAN_WAN);
    const holdsBai = fullDeck.some(c => c.id === ID_BAI_WAN);
    
    if (holdsWan && holdsQian && holdsBai) {
        const playedBig3 = pile.filter(c => [ID_WAN_WAN, ID_QIAN_WAN, ID_BAI_WAN].includes(c.id));
        if (playedBig3.length > 0) {
            let score = 1 + playedBig3.length; 
            if (playedBig3.length === 3) { const cashQing = pile.filter(c => c.suit === Suit.CASH && isQing(c)).length; score += cashQing; }
            details.push({ name: '顺风旗', score, cards: playedBig3, category: 'SE_YANG' });
        }
    }

    const jiCountTotal = fullDeck.filter(isJi).length;
    if (jiCountTotal === 4) {
        const jiPlayed = pile.filter(isJi);
        if (jiPlayed.length > 0) { const score = 1 + (jiPlayed.length * 2); details.push({ name: '福禄寿喜', score, cards: jiPlayed, category: 'SE_YANG' }); }
    }

    if (count >= 2 && card1 && cardLast && isQu(card1) && isQu(cardLast)) {
        let score = 100;
        if ([card1.id, cardLast.id].includes(ID_9_WEN)) score += 20;
        if ([card1.id, cardLast.id].includes(ID_20_WAN)) score += 40;
        details.push({ name: '内圣外王', score, cards: [card1, cardLast], category: 'SE_YANG' });
    }

    if (isZhengBen && isQu(card1) && card1.id !== ID_20_WAN) details.push({ name: '天然趣', score: 20, cards: [card1], category: 'SE_YANG' });
    if (isZhengBen && card1.id === ID_20_WAN) details.push({ name: '女帝登基', score: 30, cards: [card1], category: 'SE_YANG' });
    const firstTrick = player.trickPile.find(t => t.round === 1);
    if (isZhengBen && firstTrick && isJi(firstTrick.card)) details.push({ name: '真命天子', score: 10, cards: [firstTrick.card], category: 'SE_YANG' });

    if (count >= 2) {
        const top2Ids = [pile[0].id, pile[1].id];
        if (top2Ids.includes(ID_BAI_WAN) && top2Ids.includes(ID_20_WAN)) details.push({ name: '龙门跃', score: 60, cards: [pile[0], pile[1]], category: 'SE_YANG' });
        else if (top2Ids.includes(ID_BAI_WAN)) { const other = pile[0].id === ID_BAI_WAN ? pile[1] : pile[0]; if (isQu(other) && other.id !== ID_20_WAN) details.push({ name: '佛顶珠', score: 20, cards: [pile[0], pile[1]], category: 'SE_YANG' }); }
    }

    if (checkSequence(pile, [ID_BAI_WAN], [ID_20_WAN], false)) details.push({ name: '散花天女', score: 5, cards: getSequenceCards(pile, [ID_BAI_WAN], [ID_20_WAN]), category: 'SE_YANG' });
    if (checkSequence(pile, [ID_20_WAN], [ID_BAI_WAN], false)) details.push({ name: '天女散花', score: 10, cards: getSequenceCards(pile, [ID_20_WAN], [ID_BAI_WAN]), category: 'SE_YANG' });
    if (checkSequence(pile, [ID_BAI_WAN], QU_IDS, true)) details.push({ name: '百后趣', score: 3, cards: getSequenceCards(pile, [ID_BAI_WAN], QU_IDS), category: 'SE_YANG' });
    if (checkSequence(pile, QU_IDS, [ID_BAI_WAN], true)) details.push({ name: '趣后百', score: 5, cards: getSequenceCards(pile, QU_IDS, [ID_BAI_WAN]), category: 'SE_YANG' });

    const quIndices = pile.map((c, i) => isQu(c) ? i : -1).filter(i => i !== -1);
    if (quIndices.length >= 2) {
        let validPair = false; let pairCards: Card[] = [];
        for (let i = 0; i < quIndices.length - 1; i++) {
            const start = quIndices[i]; const end = quIndices[i+1]; let gapOk = true;
            for (let k = start + 1; k < end; k++) { if (isQing(pile[k])) { gapOk = false; break; } }
            if (gapOk) { validPair = true; pairCards = [pile[start], pile[end]]; break; }
        }
        if (validPair) details.push({ name: '蝶双飞', score: 4, cards: pairCards, category: 'SE_YANG' });
    }

    const quOnTable = pile.filter(isQu);
    if (quOnTable.length >= 3) details.push({ name: '三叠趣', score: 30, cards: quOnTable, category: 'SE_YANG' });

    const quCount = pile.filter(isQu).length;
    const hasBai = pile.some(c => c.id === ID_BAI_WAN);
    if (quCount >= 2 && hasBai) {
        const firstBaiIdx = pile.findIndex(c => c.id === ID_BAI_WAN);
        const quBefore = pile.filter((c, i) => i < firstBaiIdx && isQu(c));
        const quAfter = pile.filter((c, i) => i > firstBaiIdx && isQu(c));
        if (quBefore.length >= 2) details.push({ name: '双枪将', score: 20, cards: [...quBefore, pile[firstBaiIdx]], category: 'SE_YANG' });
        if (quAfter.length >= 2) details.push({ name: '双尾蝎', score: 12, cards: [pile[firstBaiIdx], ...quAfter], category: 'SE_YANG' });
        if (quBefore.length >= 1 && quAfter.length >= 1) details.push({ name: '过桥龙', score: 20, cards: [quBefore[0], pile[firstBaiIdx], quAfter[0]], category: 'SE_YANG' });
    }

    if (checkSequence(pile, [ID_1_GUAN, ID_1_SUO], QU_IDS, false)) details.push({ name: '捉极献极', score: 3, cards: getSequenceCards(pile, [ID_1_GUAN, ID_1_SUO], QU_IDS), category: 'SE_YANG' });
    if (checkSequence(pile, [ID_1_GUAN, ID_1_SUO], [ID_BAI_WAN], false)) details.push({ name: '一枝花', score: 5, cards: getSequenceCards(pile, [ID_1_GUAN, ID_1_SUO], [ID_BAI_WAN]), category: 'SE_YANG' });

    const suits = [Suit.CASH, Suit.STRINGS, Suit.COINS, Suit.TEXTS];
    for (const suit of suits) {
        const suited = pile.filter(c => c.suit === suit);
        const sCount = suited.filter(c => c.rank === CardRank.ZUN).length;
        const jCount = suited.filter(c => c.rank === CardRank.JIAN).length;
        const qCount = suited.filter(c => isQu(c)).length;

        if (sCount >= 2 && qCount >= 2) details.push({ name: '公孙对座', score: 16, cards: suited, category: 'SE_YANG' });
        if (jCount >= 2 && qCount >= 2) details.push({ name: '父子同登', score: 24, cards: suited, category: 'SE_YANG' });
        if (sCount >= 2 && jCount >= 2 && qCount >= 2) details.push({ name: '三代荣封', score: 32, cards: suited, category: 'SE_YANG' });
        if (checkSequence(suited, QU_IDS, ZUN_IDS, true)) details.push({ name: '倒卷帘', score: 5, cards: getSequenceCards(suited, QU_IDS, ZUN_IDS), category: 'SE_YANG' });
        if (checkSequence(suited, ZUN_IDS, QU_IDS, false)) details.push({ name: '公领孙', score: 3, cards: getSequenceCards(suited, ZUN_IDS, QU_IDS), category: 'SE_YANG' });
        
        const firstShangIdx = suited.findIndex(c => c.rank === CardRank.ZUN);
        if (firstShangIdx > -1) {
            const hasQuBefore = suited.slice(0, firstShangIdx).find(isQu);
            const hasQuAfter = suited.slice(firstShangIdx + 1).find(isQu);
            if (hasQuBefore && hasQuAfter) details.push({ name: '卷帘飞', score: 10, cards: [hasQuBefore, suited[firstShangIdx], hasQuAfter], category: 'SE_YANG' });
        }
    }

    if (checkSequence(pile, [ID_20_WAN], [ID_WAN_WAN], true)) details.push({ name: '美人卷帘', score: 10, cards: getSequenceCards(pile, [ID_20_WAN], [ID_WAN_WAN]), category: 'SE_YANG' });

    if (checkConsecutivePair(pile, ID_1_WEN, ID_20_WAN)) details.push({ name: '镜中人', score: 8, cards: getConsecutivePairCards(pile, ID_1_WEN, ID_20_WAN), category: 'SE_YANG' });
    if (checkConsecutivePair(pile, ID_20_WAN, ID_50_WAN)) details.push({ name: '小参禅', score: 10, cards: getConsecutivePairCards(pile, ID_20_WAN, ID_50_WAN), category: 'SE_YANG' });
    if (checkConsecutivePair(pile, ID_20_WAN, ID_QIAN_WAN)) details.push({ name: '美女参禅', score: 10, cards: getConsecutivePairCards(pile, ID_20_WAN, ID_QIAN_WAN), category: 'SE_YANG' });
    if (checkConsecutivePair(pile, ID_KONG_WEN, ID_20_WAN)) details.push({ name: '夫妻团圆', score: 6, cards: getConsecutivePairCards(pile, ID_KONG_WEN, ID_20_WAN), category: 'SE_YANG' });
    if (checkConsecutivePair(pile, ID_50_WAN, ID_QIAN_WAN)) details.push({ name: '二佛谈经', score: 6, cards: getConsecutivePairCards(pile, ID_50_WAN, ID_QIAN_WAN), category: 'SE_YANG' });
    if (checkConsecutivePair(pile, ID_90_WAN, ID_20_WAN)) details.push({ name: '天仙送子', score: 20, cards: getConsecutivePairCards(pile, ID_90_WAN, ID_20_WAN), category: 'SE_YANG' });
    if (checkConsecutivePair(pile, ID_ZHI_HUA, ID_50_WAN)) details.push({ name: '借花献佛', score: 4, cards: getConsecutivePairCards(pile, ID_ZHI_HUA, ID_50_WAN), category: 'SE_YANG' });

    if (count === 6) details.push({ name: '六桌吊', score: 3, cards: pile, category: 'SE_YANG' });
    if (count === 7) details.push({ name: '七桌吊', score: 2, cards: pile, category: 'SE_YANG' });
    if (count === 8) details.push({ name: '八桌吊', score: 4, cards: pile, category: 'SE_YANG' });

    return details;
};

export const identifyPatterns = (capturedCardsA: Card[], player: Player): { details: PatternDetail[], score: number } => {
    const details: PatternDetail[] = [];
    let score = 0;

    const fourSuitPattern = identifyFourSuitPatterns(capturedCardsA);
    if (fourSuitPattern) { details.push(fourSuitPattern); score += fourSuitPattern.score; }

    const qiaoDou = identifyQiaoDouPatterns(player);
    if (qiaoDou.length > 0) { details.push(...qiaoDou); score += qiaoDou.reduce((acc, curr) => acc + curr.score, 0); }

    return { details, score };
};

const checkJueZang = (kcMatches: KaiChongDetail[], uCards: Card[]): boolean => {
    const allMatches = kcMatches.flatMap(m => [m.matchedCard, ...m.sourceCards]);
    const hasWan = allMatches.some(c => c.id === ID_WAN_WAN);
    const hasQian = allMatches.some(c => c.id === ID_QIAN_WAN);
    const hasBai = allMatches.some(c => c.id === ID_BAI_WAN);

    if (!hasWan || !hasQian || !hasBai) return false;

    const big3Ids = new Set([ID_WAN_WAN, ID_QIAN_WAN, ID_BAI_WAN]);
    const indices: number[] = [];
    kcMatches.forEach((m, idx) => { const involvesBig3 = [m.matchedCard, ...m.sourceCards].some(c => big3Ids.has(c.id)); if (involvesBig3) indices.push(idx); });

    if (indices.length < 1) return false; 
    const firstIdx = Math.min(...indices); const lastIdx = Math.max(...indices);
    for (let i = firstIdx + 1; i < lastIdx; i++) { const m = kcMatches[i]; if (isQing(m.matchedCard)) return false; }
    return true;
};

export const identifyKaiChongSeYang = (player: Player, kcHistory: KaiChongDetail[]): { details: PatternDetail[], score: number } => {
    const details: PatternDetail[] = [];
    let score = 0;
    
    const A = player.trickPile.filter(t => !t.isKaiChong).map(t => t.card);
    const U_set = player.capturedCards; 
    const uIds = new Set(U_set.map(c => c.id));
    
    const redCards = U_set.filter(isRed);
    const redCount = redCards.length;
    const has90inA = A.some(c => c.id === ID_90_WAN);
    const has20inA = A.some(c => c.id === ID_20_WAN);
    const has90 = uIds.has(ID_90_WAN); 
    const has20 = uIds.has(ID_20_WAN); 
    const hasBai = uIds.has(ID_BAI_WAN);

    if (redCount >= 9 && has90) {
        const effectiveRedCount = redCount + (has90 ? 1 : 0);
        if (effectiveRedCount >= 10) {
            if (has20) { details.push({ name: '十红醉杨妃', score: 100, cards: [...redCards], category: 'KC_SE_YANG' }); score += 100; } 
            else { details.push({ name: '十红聚会', score: 60, cards: [...redCards], category: 'KC_SE_YANG' }); score += 60; }
        }
    }

    if (U_set.length === 9 && U_set.every(isRed)) { details.push({ name: '满堂红', score: 50, cards: U_set, category: 'KC_SE_YANG' }); score += 50; }

    if (score === 0) { 
        if (redCount === 9 && has20) { details.push({ name: '九红醉杨妃', score: 30, cards: redCards, category: 'KC_SE_YANG' }); score += 30; } 
        else if (redCount === 8 && has20) { details.push({ name: '八红醉杨妃', score: 24, cards: redCards, category: 'KC_SE_YANG' }); score += 24; }
    }

    const myMatches = kcHistory.filter(k => k.playerId === player.id);
    const isSequenceValid = checkJueZang(myMatches, U_set); 
    
    if (isSequenceValid) {
        const c90 = A.find(c => c.id === ID_90_WAN);
        const c20 = A.find(c => c.id === ID_20_WAN);
        if (has90inA && has20inA) { const cards = [c90, c20].filter(Boolean) as Card[]; details.push({ name: '双掘藏', score: 200, cards, category: 'KC_SE_YANG' }); score += 200; } 
        else if (has90inA) { details.push({ name: '金掘藏', score: 100, cards: c90 ? [c90] : [], category: 'KC_SE_YANG' }); score += 100; } 
        else if (has20inA) { details.push({ name: '银掘藏', score: 60, cards: c20 ? [c20] : [], category: 'KC_SE_YANG' }); score += 60; }
    }

    if (myMatches.length === 7) { const matchedPotCards = myMatches.map(m => m.matchedCard); details.push({ name: '一冲七', score: 13, cards: matchedPotCards, category: 'KC_SE_YANG' }); score += 13; }

    if (has90inA && hasBai) {
        const patternA = identifyFourSuitPatterns(A);
        const patternU = identifyFourSuitPatterns(U_set);
        if (patternU && (!patternA || patternU.name !== patternA.name)) { details.push({ name: '印花', score: 30, cards: patternU.cards, category: 'KC_SE_YANG' }); score += 30; }
    }

    return { details, score };
};

export const checkDuoJinBiao = (activePlayerId: number, potCard: Card, sourceCard: Card, allPlayers: Player[]): DuoJinInfo | null => {
    if (!isJin(potCard)) return null;
    const victims = allPlayers.filter(p => {
        if (p.id === activePlayerId) return false;
        const tablePile = p.trickPile.filter(t => t.round <= 8 && !t.isKaiChong).map(t => t.card);
        const shangCount = tablePile.filter(c => c.rank === CardRank.ZUN).length;
        return shangCount >= 3;
    });
    if (victims.length === 0) return null;
    let type: DuoJinInfo['type'] = 'NORMAL'; let scoreBase = 3;
    if (potCard.suit === Suit.CASH) { if (sourceCard.id === ID_20_WAN) { type = 'NU_JIANG'; scoreBase = 10; } else { type = 'CASH'; scoreBase = 5; } }
    const victimId = victims[0].id;
    return { isDuoJin: true, victimId, type, scoreBase };
};

// [FIX] Export interface here to resolve circular dependency or reference errors
export interface KaiZhuQiaoMenResult {
    kaiZhuRaw: number;
    qiaoMenRaw: number;
    details: PatternDetail[];
}

export const calculateKaiZhuAndQiaoMen = (capturedCardsA: Card[], player: Player, trickCount: number): KaiZhuQiaoMenResult => {
    let kz = 0; let qm = 0; const details: PatternDetail[] = [];
    const isZhengBen = trickCount >= 2;
    const caps = capturedCardsA || []; const capIds = new Set(caps.map(c => c.id));
    const hasBaiWan = capIds.has(ID_BAI_WAN); const has20Wan = capIds.has(ID_20_WAN); const hasQu = caps.some(c => ['s_1','k_1','t_1'].includes(c.id)); 
    const holdsBaiWan = player.hand.some(c => c.id === ID_BAI_WAN);

    if (isZhengBen) {
        if (hasQu) { kz += 1; const quCards = caps.filter(c => ['s_1','k_1','t_1'].includes(c.id)); details.push({ name: '趣', score: 1, cards: quCards, category: 'KAI_ZHU' }); }
        if (has20Wan) { kz += 2; const c20 = caps.find(c => c.id === ID_20_WAN); details.push({ name: '美人趣', score: 2, cards: c20 ? [c20] : [], category: 'KAI_ZHU' }); }
    }

    if (hasBaiWan) {
        const cBai = caps.find(c => c.id === ID_BAI_WAN);
        if (!isZhengBen) { kz -= 5; qm -= 5; details.push({ name: '佛赤脚', score: -5, cards: cBai ? [cBai] : [], category: 'KAI_ZHU' }); } 
        else {
            const has5G = capIds.has(ID_5_GUAN); const has6G = capIds.has(ID_6_GUAN); const has8G = capIds.has(ID_8_GUAN); const has90 = capIds.has(ID_90_WAN);
            const isBaiTu = has5G && has6G && has8G; const tuCards = caps.filter(c => [ID_5_GUAN, ID_6_GUAN, ID_8_GUAN].includes(c.id)); const c90 = caps.find(c => c.id === ID_90_WAN);
            if (isBaiTu && has90) { kz += 12; qm += 4; const allCards = cBai ? [cBai, ...tuCards] : [...tuCards]; if (c90) allCards.push(c90); details.push({ name: '全突大活', score: 12, cards: allCards, category: 'KAI_ZHU' }); } 
            else if (isBaiTu) { kz += 6; qm += 2; const allCards = cBai ? [cBai, ...tuCards] : [...tuCards]; details.push({ name: '大活百突', score: 6, cards: allCards, category: 'KAI_ZHU' }); } 
            else { kz += 3; qm += 1; details.push({ name: '大活百', score: 3, cards: cBai ? [cBai] : [], category: 'KAI_ZHU' }); }
        }
    } else if (holdsBaiWan) {
        if (isZhengBen) { kz += 2; details.push({ name: '正本百', score: 2, cards: [], category: 'KAI_ZHU' }); } 
        else { kz += 1; details.push({ name: '吊百', score: 1, cards: [], category: 'KAI_ZHU' }); }
    }
    return { kaiZhuRaw: kz, qiaoMenRaw: qm, details };
};

export const findBestKaiChongMatch = ({ players, potCard, lang, history, currentAttempterId, specialCaptures }: any): KaiChongDetail | null => {
    const player = players.find((p: Player) => p.id === currentAttempterId);
    if (!player) return null;
    const result = evaluateKaiChong(player, potCard, history, specialCaptures);
    if (result) {
        return {
            playerId: currentAttempterId,
            matchedCard: potCard,
            sourceCards: result.validCards,
            score: result.score,
            matchType: result.matchType,
            priorityScore: result.priority,
            description: result.description
        };
    }
    return null;
};

export const calculateRoundScores = ({ players, bankerId, lang, kaiChongHistory, violationLog, baseScore = 2 }: any): ScoreResult[] => {
    const playerTrickCounts = players.map((p: Player) => ({ id: p.id, count: p.trickPile.filter((t: any) => !t.isKaiChong).length }));
    const countsDesc = [...playerTrickCounts].map(x => x.count).sort((a, b) => b - a);
    const isSpecial3320 = countsDesc[0] === 3 && countsDesc[1] === 3 && countsDesc[2] === 2 && countsDesc[3] === 0;
    const getDiaoValue = (count: number) => { if (count < 2) return -1; if (count === 2) return 0; if (isSpecial3320 && count === 3) return 0.5; return 1; };

    const intermediateResults: ScoreResult[] = players.map((player: Player) => {
        const trickCardsA = player.trickPile.filter((t: any) => !t.isKaiChong);
        const capturedCardsA = trickCardsA.map((t: any) => t.card);
        const trickCountA = trickCardsA.length;
        const tianShengCheckHand = player.trickPile.filter((t: any) => t.round <= 8).map((t: any) => t.card);
        const tianShengResult = identifyTianShengPatterns(tianShengCheckHand);
        const isTianSheng = tianShengResult.isTianSheng;
        const myKcMatches = kaiChongHistory.filter((k: any) => k.playerId === player.id);
        let kcMatchScore = 0; const kcDetails: KaiChongDetail[] = [];
        myKcMatches.forEach((match: any) => { kcMatchScore += match.score; kcDetails.push(match); });
        
        const patternsU = identifyKaiChongSeYang(player, kaiChongHistory);
        const playerViolations = violationLog.filter((v: any) => v.playerId === player.id);

        if (isTianSheng) {
            return {
                playerId: player.id, trickCount: 0, diaoRawValue: 0, diaoPointChange: 0, kaiZhuPointChange: 0, qiaoMenPointChange: 0,
                seYangPointChange: tianShengResult.score + patternsU.score, kaiChongPointChange: kcMatchScore,
                patterns: [...tianShengResult.details.map(d => d.name), ...patternsU.details.map(d => d.name)],
                patternDetails: [...tianShengResult.details, ...patternsU.details], // [FIX] Guaranteed Array
                kaiChongDetails: kcDetails, cardsWonCount: player.capturedCards.length, visibleTrickCards: capturedCardsA, scoringCards: [],
                allCapturedCards: player.capturedCards, violations: [], diaoSettled: 0, kaiZhuSettled: 0, qiaoMenSettled: 0, seYangSettled: 0, kaiChongSettled: 0, totalRoundChange: 0, penaltyAdjustment: 0
            };
        } else {
            const diaoRaw = getDiaoValue(trickCountA);
            const kzqm = calculateKaiZhuAndQiaoMen(capturedCardsA, player, trickCountA);
            const patternsA = identifyPatterns(capturedCardsA, player);
            return {
                playerId: player.id, trickCount: trickCountA, diaoRawValue: diaoRaw, diaoPointChange: diaoRaw, 
                kaiZhuPointChange: kzqm.kaiZhuRaw, qiaoMenPointChange: kzqm.qiaoMenRaw,
                seYangPointChange: patternsA.score + patternsU.score, kaiChongPointChange: kcMatchScore,
                patterns: [...patternsA.details.map(d => d.name), ...patternsU.details.map(d => d.name)],
                patternDetails: [...kzqm.details, ...patternsA.details, ...patternsU.details], // [FIX] Guaranteed Array
                kaiChongDetails: kcDetails, cardsWonCount: player.capturedCards.length, visibleTrickCards: capturedCardsA, scoringCards: [], 
                allCapturedCards: player.capturedCards, violations: playerViolations, diaoSettled: 0, kaiZhuSettled: 0, qiaoMenSettled: 0, seYangSettled: 0, kaiChongSettled: 0, totalRoundChange: 0, penaltyAdjustment: 0 
            };
        }
    });

    const finalResults: ScoreResult[] = intermediateResults.map(r => ({ ...r }));
    const bankerRes = finalResults.find(r => r.playerId === bankerId);
    const bankerDiaoVal = bankerRes?.diaoPointChange || 0;
    const bankerKaiZhuVal = bankerRes?.kaiZhuPointChange || 0;
    const bankerKaiChongVal = bankerRes?.kaiChongPointChange || 0;

    finalResults.forEach(r => {
        if (r.playerId !== bankerId) {
            r.diaoSettled = (r.diaoPointChange - bankerDiaoVal) * baseScore;
            r.kaiZhuSettled = (r.kaiZhuPointChange - bankerKaiZhuVal) * baseScore;
            r.kaiChongSettled = (r.kaiChongPointChange - bankerKaiChongVal) * baseScore;
        }
    });

    if (bankerRes) {
        const peasants = finalResults.filter(r => r.playerId !== bankerId);
        bankerRes.diaoSettled = -1 * peasants.reduce((sum, p) => sum + (p.diaoSettled || 0), 0);
        bankerRes.kaiZhuSettled = -1 * peasants.reduce((sum, p) => sum + (p.kaiZhuSettled || 0), 0);
        bankerRes.kaiChongSettled = -1 * peasants.reduce((sum, p) => sum + (p.kaiChongSettled || 0), 0);
    }

    if (bankerRes) bankerRes.qiaoMenSettled = 0;
    const peasants = finalResults.filter(r => r.playerId !== bankerId);
    peasants.forEach(p => {
        let net = 0;
        peasants.forEach(opponent => { if (p.playerId !== opponent.playerId) { net += (p.qiaoMenPointChange - opponent.qiaoMenPointChange) * baseScore; } });
        p.qiaoMenSettled = net;
    });

    const totalSeYangRaw = finalResults.reduce((sum, r) => sum + r.seYangPointChange, 0);
    const xiangLuJiaoNet: Record<number, number> = { 0:0, 1:0, 2:0, 3:0 };
    const winner5 = playerTrickCounts.find((p: any) => p.count === 5);
    const losers1 = playerTrickCounts.filter((p: any) => p.count === 1);
    
    if (winner5 && losers1.length === 3) {
        let bonusPerHead = 5; 
        const winPlayer = players.find((p: Player) => p.id === winner5.id)!;
        const winCards = winPlayer.trickPile.filter((t: any) => !t.isKaiChong).map((t: any) => t.card);
        const losePlayers = losers1.map((l: any) => players.find((p: Player) => p.id === l.id)!);
        const winAllRed = winCards.every(isRed); const winNoRed = winCards.every(c => !isRed(c));
        const allTableCards = players.flatMap((p: Player) => p.trickPile.filter((t: any) => !t.isKaiChong).map((t: any) => t.card));
        const globalAllRed = allTableCards.every(isRed); const globalNoRed = allTableCards.every(c => !isRed(c));

        if (globalAllRed) bonusPerHead += 8; else if (globalNoRed) bonusPerHead += 8; 
        else {
            const losersNoRed = losePlayers.every((p: Player) => p.trickPile.filter((t: any) => !t.isKaiChong).every((t: any) => !isRed(t.card)));
            const losersAllJian = losePlayers.every((p: Player) => p.trickPile.filter((t: any) => !t.isKaiChong).every((t: any) => t.card.rank === CardRank.JIAN));
            const losersAllShang = losePlayers.every((p: Player) => p.trickPile.filter((t: any) => !t.isKaiChong).every((t: any) => t.card.rank === CardRank.ZUN));
            const losersAllRed = losePlayers.every((p: Player) => p.trickPile.filter((t: any) => !t.isKaiChong).every((t: any) => isRed(t.card)));
            if (winAllRed && losersNoRed) bonusPerHead += 5; else if (winNoRed) { if (losersAllJian) bonusPerHead += 20; else if (losersAllShang) bonusPerHead += 20; else if (losersAllRed) bonusPerHead += 10; }
        }
        const totalBonus = bonusPerHead * 3;
        xiangLuJiaoNet[winner5.id] += totalBonus; losers1.forEach((l: any) => xiangLuJiaoNet[l.id] -= bonusPerHead);
        const winRes = finalResults.find(r => r.playerId === winner5.id);
        if (winRes) { winRes.patternDetails = [...winRes.patternDetails, { name: '香炉脚', score: totalBonus, cards: winCards, category: 'SE_YANG' }]; winRes.patterns.push('香炉脚'); }
        losers1.forEach((l: any) => { const lRes = finalResults.find(r => r.playerId === l.id); if (lRes) { const lCards = players.find((p: Player) => p.id === l.id)?.trickPile.filter((t: any) => !t.isKaiChong).map((t: any) => t.card) || []; lRes.patternDetails = [...lRes.patternDetails, { name: '被香炉', score: -bonusPerHead, cards: lCards, category: 'SE_YANG' }]; } });
    }

    const duoJinNetAdjustments: Record<number, number> = { 0:0, 1:0, 2:0, 3:0 };
    kaiChongHistory.forEach((match: any) => {
        if (match.duoJin && match.duoJin.isDuoJin) {
            const winnerId = match.playerId; const victimId = match.duoJin.victimId; const rawScore = match.duoJin.scoreBase; const cashValue = rawScore * baseScore;
            duoJinNetAdjustments[winnerId] += (4 * cashValue); duoJinNetAdjustments[victimId] -= (2 * cashValue);
            players.forEach((p: Player) => { if (p.id !== winnerId && p.id !== victimId) { duoJinNetAdjustments[p.id] -= (1 * cashValue); } });
            const winnerRes = finalResults.find(r => r.playerId === winnerId);
            if (winnerRes) { const title = match.duoJin.type === 'NU_JIANG' ? '女将夺锦标' : '夺锦标'; const displayScore = rawScore * 4; winnerRes.patternDetails = [...winnerRes.patternDetails, { name: title, score: displayScore, cards: [match.matchedCard, ...match.sourceCards], category: 'DUO_JIN' }]; winnerRes.patterns.push(title); }
            const victimRes = finalResults.find(r => r.playerId === victimId);
            if (victimRes) { const victimCards = players.find((p: Player) => p.id === victimId)?.trickPile.filter((t: any) => !t.isKaiChong).map((t: any) => t.card) || []; victimRes.patternDetails = [...victimRes.patternDetails, { name: '铁门闩', score: -(rawScore * 2), cards: victimCards, category: 'DUO_JIN' }]; }
        }
    });

    finalResults.forEach(r => {
        const standardPart = (4 * r.seYangPointChange - totalSeYangRaw) * baseScore;
        const duoJinPart = duoJinNetAdjustments[r.playerId] || 0;
        const xiangLuPart = xiangLuJiaoNet[r.playerId] || 0; 
        r.seYangSettled = standardPart + duoJinPart + (xiangLuPart * baseScore); 
    });

    finalResults.forEach(r => { r.totalRoundChange = (r.diaoSettled || 0) + (r.kaiZhuSettled || 0) + (r.qiaoMenSettled || 0) + (r.seYangSettled || 0) + (r.kaiChongSettled || 0); });

    const penaltyViolator = intermediateResults.find(r => r.violations.some(v => v.riskLevel === 'PENALTY'));
    if (penaltyViolator && penaltyViolator.playerId !== bankerId) {
        if (bankerRes && bankerRes.totalRoundChange < 0) {
            const bankerLoss = bankerRes.totalRoundChange; 
            bankerRes.totalRoundChange = 0; 
            bankerRes.penaltyAdjustment = Math.abs(bankerLoss); 
            const violatorRes = finalResults.find(r => r.playerId === penaltyViolator.playerId);
            if (violatorRes) { violatorRes.totalRoundChange += bankerLoss; violatorRes.penaltyReason = "包赔 (Grand Penalty)"; violatorRes.penaltyPayerId = penaltyViolator.playerId; violatorRes.penaltyAdjustment = bankerLoss; }
        }
    }

    return finalResults;
};
