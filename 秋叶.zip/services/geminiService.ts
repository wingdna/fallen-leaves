
// @ARCHITECT_LOCK: TUTOR INTERACTION & TTS KERNEL
// -------------------------------------------------------------------------
// 🛡️ SYSTEM INTEGRITY: CRITICAL
// Implements "Promise Deduplication" to prevent API rate limiting.
// Uses audioPersistence for robust L2 caching with normalization.
// -------------------------------------------------------------------------

import { GoogleGenAI, Chat, Modality } from "@google/genai";
import { buildSystemPrompt } from './maDiaoKnowledgeBase'; 
import { Card, Player, Suit, Difficulty, GameHistory, CardRank, RiskLevel } from '../types';
import { evaluatePlayRisk } from './riskEngine';
import { audioPersistence } from './audioPersistence';

let chatInstance: Chat | null = null;

// --- L1 CACHE: LRU (Memory) ---
const MAX_L1_CACHE_SIZE = 100;
const memoryTTSCache = new Map<string, Uint8Array>(); 

// --- REQUEST LOCKS (Promise Deduplication) ---
// Prevents multiple simultaneous API calls for the same text
const pendingRequests = new Map<string, Promise<Uint8Array | null>>();

const normalizeText = (text: string): string => {
    // Aggressive normalization: remove all punctuation, spaces, and convert to lower case
    return text.trim().toLowerCase().replace(/[^\w\u4e00-\u9fa5]/g, "");
};

const updateL1Cache = (key: string, data: Uint8Array) => {
    if (memoryTTSCache.has(key)) {
        memoryTTSCache.delete(key); // Refresh Recency
    } else if (memoryTTSCache.size >= MAX_L1_CACHE_SIZE) {
        const firstKey = memoryTTSCache.keys().next().value;
        if (firstKey) memoryTTSCache.delete(firstKey);
    }
    memoryTTSCache.set(key, data);
};

const getAI = () => {
    if (typeof process !== 'undefined' && process.env.API_KEY) {
        return new GoogleGenAI({ apiKey: process.env.API_KEY });
    }
    return null;
};

// ... (getSifuMove, isAIEnabled, initializeChat, sendMessageToTutor, getAIMove remain unchanged) ...
const getSifuMove = (
    player: Player, 
    tableCards: { card: Card, playerId: number }[],
    allPlayers: Player[],
    recordedCards: Card[],
    bankerId: number,
    openedSuits: { suit: Suit, leaderId: number, isBanker: boolean }[],
    firstLeadInfo: { card: Card, playerId: number } | null,
    roundNumber: number,
    mianZhangCard: Card | null
): Card => {
    const hand = [...player.hand];
    const assessments = hand.map(card => ({
        card,
        risk: evaluatePlayRisk(player, card, tableCards, bankerId, allPlayers, recordedCards, openedSuits, firstLeadInfo, roundNumber, mianZhangCard)
    }));
    const safeMoves = assessments.filter(a => a.risk === null || a.risk.riskLevel === RiskLevel.SAFE || a.risk.riskLevel === RiskLevel.NOTICE);
    const playablePool = safeMoves.length > 0 ? safeMoves : assessments;

    if (tableCards.length === 0) {
        const redShang = playablePool.find(a => a.card.rank === CardRank.ZUN && a.card.suit !== Suit.CASH);
        if (redShang) return redShang.card;
        const openedNonCash = openedSuits.filter(s => s.suit !== Suit.CASH).map(s => s.suit);
        const familiarMove = playablePool.find(a => openedNonCash.includes(a.card.suit));
        if (familiarMove) return familiarMove.card;
        return playablePool.sort((a,b) => a.card.value - b.card.value)[0].card;
    }

    const leadSuit = tableCards[0].card.suit;
    let winningCard = tableCards[0].card;
    let winningPlayerId = tableCards[0].playerId;
    tableCards.forEach(tc => {
        if (tc.card.suit === leadSuit && tc.card.value > winningCard.value) {
            winningCard = tc.card;
            winningPlayerId = tc.playerId;
        }
    });

    const isBankerLeading = winningPlayerId === bankerId;
    const suitCards = playablePool.filter(a => a.card.suit === leadSuit);
    const winners = suitCards.filter(a => a.card.value > winningCard.value).sort((a,b) => a.card.value - b.card.value);

    if (winners.length > 0) {
        if (isBankerLeading) return winners[0].card;
        return suitCards.sort((a,b) => a.card.value - b.card.value)[0].card;
    }

    return playablePool.sort((a,b) => a.card.value - b.card.value)[0].card;
};

export const isAIEnabled = (): boolean => {
    return typeof process !== 'undefined' && !!process.env.API_KEY;
};

export const initializeChat = async (): Promise<string> => {
    const ai = getAI();
    if (!ai) return "导师暂未上线。";
    try {
        chatInstance = ai.chats.create({
            model: 'gemini-3-flash-preview',
            config: { systemInstruction: buildSystemPrompt() }
        });
        const response = await chatInstance.sendMessage({ message: "请向晚辈打个招呼。" });
        return response.text || "老夫在此。";
    } catch (e) {
        return "导师正在沉思。";
    }
};

export const sendMessageToTutor = async (text: string): Promise<string> => {
    if (!chatInstance) await initializeChat();
    if (!chatInstance) return "...";
    try {
        const response = await chatInstance.sendMessage({ message: text });
        return response.text || "...";
    } catch (e) {
        return "老夫方才走神了。";
    }
};

export const getAIMove = async (
    player: Player, 
    tableCards: { card: Card, playerId: number }[], 
    allPlayers: Player[], 
    recordedCards: Card[], 
    bankerId: number, 
    difficulty: Difficulty, 
    gameHistory: GameHistory,
    openedSuits: { suit: Suit, leaderId: number, isBanker: boolean }[],
    firstLeadInfo: { card: Card, playerId: number } | null,
    roundNumber: number,
    mianZhangCard: Card | null
): Promise<Card | null> => {
    const sifuMove = getSifuMove(player, tableCards, allPlayers, recordedCards, bankerId, openedSuits, firstLeadInfo, roundNumber, mianZhangCard);
    const isCritical = player.hand.length <= 3 || roundNumber === 1;
    const shouldConsultLLM = difficulty === Difficulty.HARD && isCritical && isAIEnabled() && Math.random() > 0.5;

    if (!shouldConsultLLM) return sifuMove;

    const ai = getAI();
    if (!ai) return sifuMove;

    const aiPromise = ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Hand: ${player.hand.map(c=>c.id).join(",")} | Table: ${tableCards.map(tc=>tc.card.id).join(",")} | Banker: ${bankerId}`,
        config: { temperature: 0.1 }
    }).then(res => {
        const selectedId = res.text?.trim();
        return player.hand.find(c => c.id === selectedId) || sifuMove;
    }).catch(() => sifuMove);

    const timeoutPromise = new Promise<Card>(resolve => setTimeout(() => resolve(sifuMove), 2000));
    return Promise.race([aiPromise, timeoutPromise]);
};

export const preloadStaticAudio = async () => {
    try {
        const response = await fetch('./assets/madiao_audio_manifest.json');
        if (!response.ok) return;

        const manifest = await response.json();
        const entries = Object.entries(manifest);
        
        console.log(`[TTS] Hydrating cache with ${entries.length} clips...`);
        for (const [textKey, base64] of entries) {
            const normalized = normalizeText(textKey);
            const cacheKey = `Zephyr:${normalized}`; 
            
            const binaryString = atob(base64 as string);
            const bytes = new Uint8Array(binaryString.length);
            for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
            
            audioPersistence.saveAudio(cacheKey, bytes);
        }
    } catch (e) {
        // Silent fail
    }
};

/**
 * Robust Speech Generation with 3-Layer Caching & Deduplication
 */
export const generateSpeech = async (text: string, voiceName: string = 'Zephyr'): Promise<Uint8Array | null> => {
    if (!text) return null;
    
    // 1. Normalize Key (remove punctuation/case differences)
    const normalizedText = normalizeText(text);
    const cacheKey = `${voiceName}:${normalizedText}`;

    // 2. Check L1 Memory Cache
    if (memoryTTSCache.has(cacheKey)) {
        return memoryTTSCache.get(cacheKey)!;
    }

    // 3. Check Pending Requests (Deduplication)
    // If a request for this exact text is already in flight, wait for it instead of starting a new one.
    if (pendingRequests.has(cacheKey)) {
        console.log(`[TTS] Awaiting pending request for: "${text.substring(0, 10)}..."`);
        return pendingRequests.get(cacheKey)!;
    }

    // Define the async operation
    const fetchOperation = async (): Promise<Uint8Array | null> => {
        try {
            // 4. Check L2 Disk Cache (IndexedDB)
            const stored = await audioPersistence.getAudio(cacheKey);
            if (stored) {
                updateL1Cache(cacheKey, stored);
                return stored;
            }

            // 5. Call API (Expensive)
            const ai = getAI();
            if (!ai) return null;

            console.log(`[TTS] Generating new audio for: "${text.substring(0, 10)}..."`);
            const response = await ai.models.generateContent({
                model: "gemini-2.5-flash-preview-tts",
                contents: [{ parts: [{ text }] }],
                config: {
                    responseModalities: [Modality.AUDIO],
                    speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName } } },
                },
            });

            const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
            if (base64Audio) {
                const binaryString = atob(base64Audio);
                const bytes = new Uint8Array(binaryString.length);
                for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
                
                // 6. Write to Caches
                updateL1Cache(cacheKey, bytes);
                // Fire and forget save, but log errors if any
                try {
                    audioPersistence.saveAudio(cacheKey, bytes);
                } catch (dbErr) {
                    console.error("[TTS] Failed to persist audio", dbErr);
                }
                
                return bytes;
            }
        } catch (e) {
            console.error("[TTS] API Error:", e);
        } finally {
            // Remove lock when done (success or fail)
            pendingRequests.delete(cacheKey);
        }
        return null;
    };

    // Store the promise in the map
    const promise = fetchOperation();
    pendingRequests.set(cacheKey, promise);
    
    return promise;
};

export const generateAllTutorialAudio = async (
    onProgress: (current: number, total: number, msg: string) => void
): Promise<string> => {
    // Placeholder to satisfy interface
    return "{}"; 
};

function arrayBufferToBase64(buffer: ArrayBuffer) {
    let binary = '';
    const bytes = new Uint8Array(buffer);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
}
