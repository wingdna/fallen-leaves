// @ARCHITECT_LOCK: AUDIO PERSISTENCE LAYER
// -------------------------------------------------------------------------
// 🛡️ SECURITY LEVEL: HIGH
// Handles robust caching of TTS binary data.
// Uses IndexedDB with a write-queue pattern to non-blocking UI.
// -------------------------------------------------------------------------

const DB_NAME = 'MaDiao_TTS_Vault_V2';
const STORE_NAME = 'speech_clips';
const DB_VERSION = 1;

export interface TTSCacheEntry {
    key: string;
    data: ArrayBuffer;
    timestamp: number;
}

class AudioPersistenceService {
    private dbPromise: Promise<IDBDatabase> | null = null;
    private writeQueue: Map<string, ArrayBuffer> = new Map();
    private isWriting = false;

    constructor() {
        this.initDB();
    }

    private initDB(): Promise<IDBDatabase> {
        if (this.dbPromise) return this.dbPromise;

        this.dbPromise = new Promise((resolve, reject) => {
            if (typeof window === 'undefined' || !window.indexedDB) {
                reject(new Error("IndexedDB not supported"));
                return;
            }
            const request = indexedDB.open(DB_NAME, DB_VERSION);
            request.onupgradeneeded = (e) => {
                const db = (e.target as IDBOpenDBRequest).result;
                if (!db.objectStoreNames.contains(STORE_NAME)) {
                    db.createObjectStore(STORE_NAME, { keyPath: 'key' });
                }
            };
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => {
                this.dbPromise = null;
                reject(request.error);
            };
        });
        return this.dbPromise;
    }

    public async getAudio(key: string): Promise<Uint8Array | null> {
        // 1. Check Write Queue (Memory L1) - Fast path for recently generated
        if (this.writeQueue.has(key)) {
            // console.debug(`[AudioPersistence] L1 Hit: ${key}`);
            return new Uint8Array(this.writeQueue.get(key)!);
        }

        // 2. Check IndexedDB (Disk L2)
        try {
            const db = await this.initDB();
            return new Promise((resolve) => {
                const tx = db.transaction(STORE_NAME, 'readonly');
                const store = tx.objectStore(STORE_NAME);
                const req = store.get(key);
                req.onsuccess = () => {
                    if (req.result) {
                        // console.debug(`[AudioPersistence] L2 Hit: ${key}`);
                        resolve(new Uint8Array(req.result.data));
                    } else {
                        // console.debug(`[AudioPersistence] Miss: ${key}`);
                        resolve(null);
                    }
                };
                req.onerror = () => resolve(null);
            });
        } catch (e) {
            console.warn("[AudioPersistence] Read Error:", e);
            return null;
        }
    }

    public saveAudio(key: string, data: Uint8Array): void {
        // Clone buffer to prevent detached buffer issues
        // Cast to ArrayBuffer to fix TS error: Argument of type 'ArrayBuffer | SharedArrayBuffer' is not assignable...
        const buffer = data.buffer.slice(0) as ArrayBuffer;
        this.writeQueue.set(key, buffer);
        this.processQueue();
    }

    private async processQueue() {
        if (this.isWriting || this.writeQueue.size === 0) return;
        this.isWriting = true;

        try {
            const db = await this.initDB();
            const tx = db.transaction(STORE_NAME, 'readwrite');
            const store = tx.objectStore(STORE_NAME);

            // Snapshot current batch to prevent data loss if new items arrive or tx fails
            const batch = new Map(this.writeQueue);
            
            for (const [key, data] of batch.entries()) {
                const entry: TTSCacheEntry = {
                    key,
                    data,
                    timestamp: Date.now()
                };
                store.put(entry);
            }

            tx.oncomplete = () => {
                // Only remove items that were successfully written
                for (const key of batch.keys()) {
                    this.writeQueue.delete(key);
                }
                this.isWriting = false;
                if (this.writeQueue.size > 0) this.processQueue(); // Drain remaining
            };
            
            tx.onerror = (e) => {
                console.error("[AudioPersistence] Transaction Failed", e);
                // Do NOT clear queue, retry later will pick them up
                this.isWriting = false;
            };
        } catch (e) {
            this.isWriting = false;
            console.error("[AudioPersistence] Queue Error:", e);
        }
    }

    // --- NEW: MANAGEMENT METHODS FOR ADMIN UI ---

    public async getAllKeys(): Promise<string[]> {
        const db = await this.initDB();
        return new Promise((resolve) => {
            const tx = db.transaction(STORE_NAME, 'readonly');
            const store = tx.objectStore(STORE_NAME);
            const req = store.getAllKeys();
            req.onsuccess = () => resolve(req.result as string[]);
            req.onerror = () => resolve([]);
        });
    }

    public async getAllEntries(): Promise<TTSCacheEntry[]> {
        const db = await this.initDB();
        return new Promise((resolve) => {
            const tx = db.transaction(STORE_NAME, 'readonly');
            const store = tx.objectStore(STORE_NAME);
            const req = store.getAll();
            req.onsuccess = () => resolve(req.result as TTSCacheEntry[]);
            req.onerror = () => resolve([]);
        });
    }

    public async deleteKey(key: string): Promise<boolean> {
        const db = await this.initDB();
        return new Promise((resolve) => {
            const tx = db.transaction(STORE_NAME, 'readwrite');
            const store = tx.objectStore(STORE_NAME);
            const req = store.delete(key);
            req.onsuccess = () => resolve(true);
            req.onerror = () => resolve(false);
        });
    }

    public async clearStore(): Promise<boolean> {
        const db = await this.initDB();
        return new Promise((resolve) => {
            const tx = db.transaction(STORE_NAME, 'readwrite');
            const store = tx.objectStore(STORE_NAME);
            const req = store.clear();
            req.onsuccess = () => resolve(true);
            req.onerror = () => resolve(false);
        });
    }
    
    public async importBatch(entries: TTSCacheEntry[]): Promise<number> {
        const db = await this.initDB();
        return new Promise((resolve) => {
            const tx = db.transaction(STORE_NAME, 'readwrite');
            const store = tx.objectStore(STORE_NAME);
            let count = 0;
            entries.forEach(entry => {
                store.put(entry);
                count++;
            });
            tx.oncomplete = () => resolve(count);
            tx.onerror = () => resolve(0);
        });
    }
}

export const audioPersistence = new AudioPersistenceService();