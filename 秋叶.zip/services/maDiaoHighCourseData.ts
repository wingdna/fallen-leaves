
// @ARCHITECT_LOCK: HIGH COURSE SCRIPTURE DATA
// -------------------------------------------------------------------------
// 📜 马吊高课程 (The Supreme Scripture)
// Raw text data organized for RAG (Retrieval-Augmented Generation) context injection.
// -------------------------------------------------------------------------

export interface ScriptureSegment {
    id: string;
    keywords: string[]; // 用于本地快速检索
    content: string;    // 原文
    philosophy: 'WEIGHT' | 'SEQUENCE' | 'URGENCY' | 'SEVERITY'; // 轻重/先后/缓急/宽严
}

export const HIGH_COURSE_SCRIPTURE: ScriptureSegment[] = [
    {
        id: 'CORE_PHILOSOPHY',
        keywords: ['轻重', '先后', '缓急', '宽严', '总纲'],
        content: "以制约“庄家”为最重，其次对付“四门”色样，再其次“二门”。庄重百轻。事情相同而时机不同，或时机相同而处境不同，就有执行的先后之分。应急之时，如手握“大立红万”却急于全出“千万”，是急攻；宜缓之时，有两张“赏”牌却不打“头肩”，是缓守。",
        philosophy: 'WEIGHT'
    },
    {
        id: 'ANTI_BANKER_PRIORITY',
        keywords: ['漏庄', '纵庄', '庄家', '逼庄'],
        content: "设立‘逼庄用赏’这一条，用意何在？如果重点真的在四门，为何不保留‘赏’牌去压制对方的肩、极上桌形成‘色样’，反而轻易用它去逼庄，宁可让庄家得分呢？由此可见，制约庄家为首，压制色样为次。",
        philosophy: 'WEIGHT'
    },
    {
        id: 'BAI_LAO_STRATEGY',
        keywords: ['百老', '十子', '诡避', '佛赤脚'],
        content: "百子两家庄。无赏告百，赔千僧二十子色样。若百老家出十报百，邻百之家须尽大张逼之。百子家巳上千僧、百子，手有小十尽出不留一张制二十色様者，赔。",
        philosophy: 'SEVERITY'
    },
    {
        id: 'TENSION_STATE',
        keywords: ['紧张', '宽张', '顶色', '色样'],
        content: "色样紧张顶，毋论生熟也。至紧张时，熟门固顶，生门亦顶，顺风全见卽十子亦顶。若宽张时生门固不顶，熟门不顶亦不赔。此为简当。",
        philosophy: 'URGENCY'
    },
    {
        id: 'JI_ZHUO_DIALECTIC',
        keywords: ['急捉', '无故', '香炉'],
        content: "无故急捉，致上庄成色、开冲、活百、拖趣者，赔。两家先后急捉，先犯者赔先犯之张，后犯者赔后犯之张。若重急上庄，虽有万千亦赔。",
        philosophy: 'SEQUENCE'
    },
    {
        id: 'THREE_DOORS_TRAP',
        keywords: ['开三', '故造', '三门'],
        content: "无故开三，致上庄成色样、冲、活百、上趣者，赔。头门巳正，又将本赏作二门，更发三门，谓之故造。与无故开三同赔。",
        philosophy: 'SEVERITY'
    },
    {
        id: 'SAN_HUA_DEFENSE',
        keywords: ['散花', '佛顶', '倒散'],
        content: "百子家出十报百之时，法宜预留十子一张，以防散花。若于千百之后灭去十子，致后来成散花者，赔。至第六张既灭十子，而百子家于第七张上倒散，不赔。",
        philosophy: 'URGENCY'
    }
];

export const getRelevantScripture = (tags: string[]): string => {
    // Simple keyword matching simulation for RAG
    const relevant = HIGH_COURSE_SCRIPTURE.filter(s => 
        s.keywords.some(k => tags.includes(k))
    );
    if (relevant.length === 0) return HIGH_COURSE_SCRIPTURE[0].content; // Return core philosophy as fallback
    return relevant.map(s => `【${s.id}】: ${s.content}`).join('\n');
};
