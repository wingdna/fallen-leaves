
// --- ZEN AUDIO ASSETS (V14: Expanded Universe) ---

// 默认 BGM
export const BGM_URL = "https://cdn.pixabay.com/download/audio/2022/10/14/audio_985556209e.mp3?filename=chinese-instrumental-123793.mp3";

export interface ZenTrack {
    id: string;
    name: string;
    desc: string;
    url: string;
    isCustom?: boolean;
    region?: 'CN' | 'JP' | 'KR' | 'WEST' | 'NATURE' | 'SPACE';
}

// [SOURCE 1] Pixabay (Stable CDN, High Quality)
const PIXABAY_TRACKS: ZenTrack[] = [
    { id: 'zen_cn_guqin', region: 'CN', name: '🇨🇳 华夏·高山流水', desc: '古琴铮铮，巍巍泰山', url: "https://cdn.pixabay.com/download/audio/2022/10/14/audio_985556209e.mp3?filename=chinese-instrumental-123793.mp3" },
    { id: 'zen_jp_shaku', region: 'JP', name: '🇯🇵 扶桑·尺八虚空', desc: '一音成佛，万籁俱寂', url: "https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3?filename=zen-garden-110699.mp3" },
    { id: 'zen_kr_gaya', region: 'KR', name: '🇰🇷 高丽·晨露伽倻', desc: '清脆婉转，如泣如诉', url: "https://cdn.pixabay.com/download/audio/2022/03/09/audio_c8c8a73467.mp3?filename=meditation-impulse-3075.mp3" },
    { id: 'zen_yoga_flow', region: 'WEST', name: '🧘 瑜伽·灵动之流', desc: '身心合一，舒展自如', url: "https://cdn.pixabay.com/download/audio/2022/02/10/audio_fc8c835255.mp3?filename=yoga-music-17799.mp3" },
    { id: 'zen_temple_bell', region: 'CN', name: '🛕 古刹·晨钟暮鼓', desc: '深山藏古寺，禅意深远', url: "https://cdn.pixabay.com/download/audio/2022/01/18/audio_d2c2067756.mp3?filename=tibetan-meditation-gamma-waves-13355.mp3" },
    { id: 'zen_nature_rain', region: 'NATURE', name: '🌧️ 自然·听雨眠', desc: '夜阑卧听风吹雨', url: "https://cdn.pixabay.com/download/audio/2022/02/07/audio_6590620954.mp3?filename=waterfall-14697.mp3" },
    { id: 'zen_forest_birds', region: 'NATURE', name: '🐦 森林·百鸟朝凤', desc: '清晨的森林交响曲', url: "https://cdn.pixabay.com/download/audio/2022/04/27/audio_307e472566.mp3?filename=forest-lullaby-110624.mp3" },
    { id: 'zen_heal_bowl', region: 'WEST', name: '🥣 灵性·颂钵', desc: '高频共振，净化磁场', url: "https://cdn.pixabay.com/download/audio/2021/09/06/audio_9c05c0a373.mp3?filename=tibetan-bowls-meditation-19632.mp3" },
    { id: 'zen_cn_dunhuang', region: 'CN', name: '🇨🇳 敦煌·飞天', desc: '丝路花雨，大漠孤烟', url: "https://cdn.pixabay.com/download/audio/2022/03/24/audio_0769352723.mp3?filename=meditation-bowl-103723.mp3" },
    { id: 'zen_jp_kyoto', region: 'JP', name: '🇯🇵 京都·枯山水', desc: '砂石之间，见大千世界', url: "https://cdn.pixabay.com/download/audio/2022/10/25/audio_2733979602.mp3?filename=bamboo-flute-meditation-12275.mp3" },
    { id: 'zen_ocean_waves', region: 'NATURE', name: '🌊 沧海·潮起潮落', desc: '海浪拍岸，心胸开阔', url: "https://cdn.pixabay.com/download/audio/2022/01/18/audio_d0a13f69d2.mp3?filename=ocean-waves-112906.mp3" }
];

// [SOURCE 2] Internet Archive (Public Domain / Community Audio)
const ARCHIVE_TRACKS: ZenTrack[] = [
    { id: 'arch_tibetan_bowl', region: 'WEST', name: '🧘 冥想·藏地钵音', desc: 'Archive.org - 净化心灵', url: "https://archive.org/download/tibetan-singing-bowl/Tibetan-Singing-Bowl.mp3" },
    { id: 'arch_forest_amb', region: 'NATURE', name: '🌲 自然·深林气息', desc: 'Archive.org - 纯净白噪', url: "https://archive.org/download/nature-sounds-forest-birds/Nature%20Sounds%20-%20Forest%20Birds.mp3" },
    { id: 'arch_heavy_rain', region: 'NATURE', name: '⛈️ 自然·暴雨洗礼', desc: 'Archive.org - 深度解压', url: "https://archive.org/download/rain-heavy-loud/Rain_Heavy_Loud.mp3" },
    { id: 'arch_fireplace', region: 'NATURE', name: '🔥 自然·壁炉篝火', desc: 'Archive.org - 温暖治愈', url: "https://archive.org/download/fireplace-sound-effect/Fireplace%20Sound%20Effect.mp3" },
    { id: 'arch_crickets', region: 'NATURE', name: '🦗 自然·夏夜虫鸣', desc: 'Archive.org - 宁静致远', url: "https://archive.org/download/crickets-sound-effect/Crickets.mp3" },
    { id: 'arch_piano_calm', region: 'WEST', name: '🎹 钢琴·静谧时刻', desc: 'Archive.org - 极简旋律', url: "https://archive.org/download/calm-piano-music/Calm%20Piano%20Music.mp3" },
    { id: 'arch_buddha_chant', region: 'CN', name: '📿 梵音·大悲咒', desc: 'Archive.org - 庄严清净', url: "https://archive.org/download/GreatCompassionMantra/Great%20Compassion%20Mantra.mp3" }
];

// [SOURCE 3] NASA (Public Domain Space Sounds)
const NASA_TRACKS: ZenTrack[] = [
    { id: 'nasa_earth', region: 'SPACE', name: '🌍 宇宙·地球之声', desc: 'NASA - 旅行者号录音', url: "https://archive.org/download/GoldenRecordSoundsOfEarth/Golden_Record_Sounds_of_Earth.mp3" },
    { id: 'nasa_sun', region: 'SPACE', name: '☀️ 宇宙·太阳风暴', desc: 'NASA - 等离子体波', url: "https://archive.org/download/NASA-Audio-Kepler-Star-KIC12268220C/Kepler%3A%20Star%20KIC12268220C%20Light%20Curve%20Waves%20to%20Sound.mp3" },
    { id: 'nasa_interstellar', region: 'SPACE', name: '🌌 宇宙·星际穿越', desc: 'NASA - 空间站环境音', url: "https://archive.org/download/nasa-audio-iss-ambience/ISS%20Ambience.mp3" }
];

// [SOURCE 4] Google Sounds (Reliable Fallback)
const GOOGLE_TRACKS: ZenTrack[] = [
    { id: 'goog_forest', region: 'NATURE', name: '🌲 谷歌·森林清晨', desc: 'Google Sounds', url: "https://actions.google.com/sounds/v1/ambiences/forest_morning.ogg" },
    { id: 'goog_rain', region: 'NATURE', name: '🌧️ 谷歌·雨打芭蕉', desc: 'Google Sounds', url: "https://actions.google.com/sounds/v1/weather/rain_heavy_loud.ogg" },
    { id: 'goog_ocean', region: 'NATURE', name: '🌊 谷歌·惊涛拍岸', desc: 'Google Sounds', url: "https://actions.google.com/sounds/v1/water/waves_crashing_on_rock_beach.ogg" },
    { id: 'goog_stream', region: 'NATURE', name: '💧 谷歌·清泉流响', desc: 'Google Sounds', url: "https://actions.google.com/sounds/v1/water/stream_water_flowing.ogg" }
];

// Initial Playlist: Curated Mix (3 Pixabay, 2 Archive, 1 NASA, 2 Google)
export const ZEN_PLAYLIST = [
    PIXABAY_TRACKS[0], // Guqin
    ARCHIVE_TRACKS[0], // Tibetan Bowl
    PIXABAY_TRACKS[1], // Shakuhachi
    NASA_TRACKS[0],    // Earth Sound
    GOOGLE_TRACKS[1],  // Rain
    ARCHIVE_TRACKS[5], // Piano
    PIXABAY_TRACKS[10] // Ocean
];

// Reserve Pool: All non-duplicate tracks
const ALL_TRACKS = [
    ...PIXABAY_TRACKS,
    ...ARCHIVE_TRACKS,
    ...NASA_TRACKS,
    ...GOOGLE_TRACKS
];

// 储备池获取器 (避免重复)
export const getReplacementTrack = (currentUrls: Set<string>): ZenTrack | null => {
    // Filter pool to find tracks whose URL is NOT in the current playing list
    const availableTracks = ALL_TRACKS.filter(t => !currentUrls.has(t.url));
    
    // Also include tracks from the initial pool if they are not currently used (recycling)
    const allAvailable = ALL_TRACKS.filter(t => !currentUrls.has(t.url));
    
    if (allAvailable.length === 0) {
        // Emergency Fallback: If all exhausted, allow recycling random track
        const randomIndex = Math.floor(Math.random() * ALL_TRACKS.length);
        const candidate = ALL_TRACKS[randomIndex];
        return {
            ...candidate,
            id: `${candidate.id}_recycle_${Date.now()}`
        };
    }
    
    // Pick random
    const randomIndex = Math.floor(Math.random() * allAvailable.length);
    const candidate = allAvailable[randomIndex];
    
    // Return a fresh object
    return {
        ...candidate,
        id: `${candidate.id}_${Date.now()}_${Math.floor(Math.random()*1000)}` 
    };
};

// Core System SFX
export const SFX_ASSETS = {
    WOOD: "synth://bamboo_thock",   
    STONE: "synth://pebble_stream", 
    PAPER: "synth://leaf_rustle",   
    CHIME: "synth://wind_chime",    
    DRUM: "synth://distant_thunder" 
};

export const AUDIO_CONFIG = {
    bgmVolume: 0.4, 
    sfxVolume: 0.35, 
    fadeDuration: 2000, 
    dbName: 'MaDiao_Zen_Vault',
    storeName: 'nature_sounds_v6'
};
