
// @ARCHITECT_LOCK: MASTER MIND SERVICE
// -------------------------------------------------------------------------
// 🧠 大师心智 (Master Mind)
// The bridge between the "High Course" text and the Runtime Engine.
// Uses Gemini to interpret the archaic text dynamically based on game state.
// -------------------------------------------------------------------------

import { GoogleGenAI } from "@google/genai";
import { Player, Card, GameHistory, Suit } from '../types';
import { getRelevantScripture } from './maDiaoHighCourseData';
import { evaluateHighCourseRisk } from './riskEngineV2_HighCourse';

// 策略修正值 (由LLM下发给引擎)
export interface StrategyModifier {
    tensionLevel: 'RELAXED' | 'NORMAL' | 'HIGH' | 'CRITICAL'; // 局势张力
    primaryFocus: 'ANTI_BANKER' | 'ANTI_SE_YANG' | 'ANTI_BAI_LAO'; // 当前重心
    aggressiveness: number; // 0.0 - 1.0
    allowedViolations: string[]; // 允许豁免的违例ID (例如 "允许开三")
    reasoning: string; // 大师的思考过程 (用于UI展示)
}

const DEFAULT_MODIFIER: StrategyModifier = {
    tensionLevel: 'NORMAL',
    primaryFocus: 'ANTI_BANKER',
    aggressiveness: 0.5,
    allowedViolations: [],
    reasoning: "局势尚不明朗，按兵不动。"
};

let lastAnalysisTime = 0;
let cachedModifier: StrategyModifier = DEFAULT_MODIFIER;

const getAI = () => {
    if (typeof process !== 'undefined' && process.env.API_KEY) {
        return new GoogleGenAI({ apiKey: process.env.API_KEY });
    }
    return null;
};

// --- 核心方法：大师推演 (Master Deduction) ---
// 这是一个异步的、较慢的过程，不会阻塞游戏主循环。
// 它会根据当前盘面，去“查阅”古籍，然后告诉引擎该怎么做。
export const consultTheMaster = async (
    player: Player,
    roundNumber: number,
    openedSuits: any[],
    bankerId: number,
    trickCards: any[]
): Promise<StrategyModifier> => {
    // 节流：防止每帧调用
    if (Date.now() - lastAnalysisTime < 5000) return cachedModifier;
    lastAnalysisTime = Date.now();

    const ai = getAI();
    if (!ai) return DEFAULT_MODIFIER;

    // 1. 提取当前局势关键词
    const keywords: string[] = [];
    if (roundNumber > 5) keywords.push('紧张', '比张', '错留');
    if (trickCards.length > 0) keywords.push('纵庄', '急捉', '漏庄');
    if (player.hand.some(c => c.value === 11 || c.value === 10)) keywords.push('万千', '不立');
    
    // 2. 检索古籍 (RAG)
    const scriptureExcerpt = getRelevantScripture(keywords);

    // 3. 构建 Prompt
    const prompt = `
    Role: You are the 'Ma Diao Master'. You strictly follow the 'High Course' philosophy.
    
    Context:
    - Round: ${roundNumber}/8
    - My Role: ${player.id === bankerId ? 'Banker' : 'Peasant'}
    - My Hand: ${player.hand.map(c => c.name).join(', ')}
    - Table: ${trickCards.length > 0 ? trickCards.map(c => c.card.name).join(', ') : 'Empty'}
    
    Ancient Scripture (The Law):
    ${scriptureExcerpt}
    
    Task:
    Analyze the situation based on the Scripture. Resolve contradictions using the principle: "Banker > Pattern (Se Yang)".
    Return a JSON object with:
    - tensionLevel: 'RELAXED' | 'NORMAL' | 'HIGH' | 'CRITICAL'
    - primaryFocus: 'ANTI_BANKER' | 'ANTI_SE_YANG' | 'ANTI_BAI_LAO'
    - allowedViolations: Array of rule IDs to ignore this turn (e.g. if 'Top Se Yang' is critical, ignore 'Kai San Men').
    - reasoning: A short, philosophical explanation in Chinese (vernacular but authoritative).
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: prompt,
            config: { responseMimeType: "application/json" }
        });

        const result = JSON.parse(response.text || '{}');
        cachedModifier = {
            ...DEFAULT_MODIFIER,
            ...result
        };
        return cachedModifier;
    } catch (e) {
        console.warn("Master Mind is meditating (Error):", e);
        return cachedModifier;
    }
};

// --- 引擎接口：融合大师意志 ---
// 在 riskEngineV2 中调用此函数，将硬编码逻辑与 AI 动态建议融合
export const applyMasterWisdom = (
    baseRisk: any, 
    modifier: StrategyModifier
) => {
    if (!baseRisk) return null;

    // 1. 豁免权 (Indulgence)
    // 如果大师说某些规则此刻可以忽略（因为有更高级的战术目标），则降级风险
    if (modifier.allowedViolations.includes(baseRisk.ruleId)) {
        return {
            ...baseRisk,
            riskLevel: 'NOTICE', // 降级为提示
            message: `【大师特许】${baseRisk.message} (大师判定：${modifier.reasoning})`
        };
    }

    // 2. 紧张度加权 (Tension Weighting)
    // 在 CRITICAL 状态下，任何 NOTICE 都可能升级为 WARNING
    if (modifier.tensionLevel === 'CRITICAL' && baseRisk.riskLevel === 'NOTICE') {
        return {
            ...baseRisk,
            riskLevel: 'WARNING',
            message: `【局势紧迫】${baseRisk.message}`
        };
    }

    return baseRisk;
};
