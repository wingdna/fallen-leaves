
// @ARCHITECT_LOCK: CORE RULE ENGINE (REFACTORED)
// -------------------------------------------------------------------------
// ⛔️ CRITICAL SAFETY WARNING ⛔️
// This file implements the "Three Preventions" using a Strategy Pattern.
// logic integrity is paramount.
// Updated: Backported High Course rules (V2) for better tactical coverage.
// -------------------------------------------------------------------------

import { Player, Card, Suit, CardRank, CardColor, RiskLevel, TacticalPriority, RiskAssessment, SuitStatus } from '../types';
import { ID_WAN_WAN, ID_QIAN_WAN, ID_BAI_WAN, ID_20_WAN, ID_90_WAN, ID_1_GUAN, ID_1_SUO, ID_9_WEN, ID_9_GUAN, ID_9_SUO, ID_KONG_WEN } from '../constants';
import { PenaltyType } from './ruleDefinitions';

// --- CONTEXT DEFINITION ---
interface RuleContext {
    player: Player;
    card: Card;
    tableCards: { card: Card, playerId: number }[];
    bankerId: number;
    allPlayers: Player[];
    recordedCards: Card[];
    openedSuits: { suit: Suit, leaderId: number, isBanker: boolean }[];
    firstLeadInfo: { card: Card, playerId: number } | null;
    roundNumber: number;
    mianZhangCard: Card | null;
    bankerFirstLeadCard: Card | null;
    // Derived Context (Calculated once)
    winningInfo?: { card: Card; playerId: number; currentBest: number; isBankerLeading: boolean };
    isTensionHigh?: boolean;
    faceUpPlayedCardIds?: Set<string>; // Optional for V1 but used for Tension check
    
    // [OPTIMIZATION] Cached Reference Set for isZhenZhang
    knownCardsSet?: Set<string>;
}

// --- STRATEGY INTERFACE ---
interface RuleEvaluator {
    id: string;
    priority: number; // Higher runs first
    evaluate: (ctx: RuleContext) => RiskAssessment | null;
}

// --- HELPERS ---
const isRed = (card: Card) => card.color === CardColor.RED;
const isGreen = (card: Card) => card.color === CardColor.GREEN;
const isQu = (card: Card) => [ID_20_WAN, ID_1_GUAN, ID_1_SUO, ID_9_WEN].includes(card.id);

// Tension Check (Simplified Backport from V2)
const isTableTensionHigh = (roundNumber: number, faceUpPlayedCardIds: Set<string> | undefined): boolean => {
    if (roundNumber >= 5) return true;
    if (!faceUpPlayedCardIds) return false;
    const shangIds = [ID_9_GUAN, ID_9_SUO, ID_KONG_WEN, ID_WAN_WAN, ID_QIAN_WAN, ID_BAI_WAN];
    for (const id of shangIds) {
        if (faceUpPlayedCardIds.has(id)) return true;
    }
    return false;
};

// [OPTIMIZED] Use cached Set from context if available
const isZhenZhang = (card: Card, ctx: RuleContext): boolean => {
    // [DEFENSIVE] Safety check for context integrity
    if (!ctx || !ctx.player || !ctx.recordedCards || !ctx.tableCards) return false;

    let W = ctx.knownCardsSet;
    if (!W) {
        // Fallback: build if not present (should ideally be built once in wrapper)
        W = new Set<string>();
        ctx.player.hand.forEach(c => W!.add(c.id));
        ctx.recordedCards.forEach(c => W!.add(c.id));
        ctx.tableCards.forEach(tc => W!.add(tc.card.id));

        if (ctx.mianZhangCard) {
            const isQing = ctx.mianZhangCard.rank === CardRank.QING;
            const is90Wan = ctx.mianZhangCard.id === ID_90_WAN;
            if (isQing && !is90Wan) {
                W.add(ctx.mianZhangCard.id);
            }
        }
    }

    const maxVal = (card.suit === Suit.CASH || card.suit === Suit.TEXTS) ? 11 : 9;
    
    // Quick check: if card is max value, it's definitely Zhen Zhang (unless Mian Zhang logic interferes, but simplified here)
    if (card.value === maxVal) return true;

    for (let v = card.value + 1; v <= maxVal; v++) {
        const higherCardInHand = ctx.player.hand.some(c => c.suit === card.suit && c.value === v);
        if (higherCardInHand) continue;
        
        const higherCardInRecorded = ctx.recordedCards.some(c => c.suit === card.suit && c.value === v);
        if (higherCardInRecorded) continue;
        
        const higherCardOnTable = ctx.tableCards.some(tc => tc.card.suit === card.suit && tc.card.value === v);
        if (higherCardOnTable) continue;
        
        const mianZhangMatch = (ctx.mianZhangCard && ctx.mianZhangCard.suit === card.suit && ctx.mianZhangCard.value === v && ctx.mianZhangCard.rank === CardRank.QING && ctx.mianZhangCard.id !== ID_90_WAN);
        if (mianZhangMatch) continue;

        // If we reach here, it means a higher card 'v' exists somewhere UNKNOWN (in other players' hands).
        // So 'card' is NOT guaranteed to be largest -> Not Zhen Zhang.
        return false;
    }
    return true;
};

const isDaZhang = (card: Card): boolean => {
    if (card.suit === Suit.TEXTS) return card.value >= 7;
    return card.value >= 6;
};

const getSequenceWinners = (hand: Card[], winningCard: Card, recordedCards: Card[]): Card[] => {
    return hand.filter(c => c.suit === winningCard.suit && c.value > winningCard.value);
};

// --- RULE IMPLEMENTATIONS (Strategies) ---

// 1. 不立赏 (Leading Rule)
const BuLiShangRule: RuleEvaluator = {
    id: 'BU_LI_SHANG',
    priority: 100,
    evaluate: (ctx) => {
        const { player, card } = ctx;
        if (player.capturedCards && player.capturedCards.length > 0) return null;

        const hand = player.hand;
        const hasWan = hand.some(c => c.id === ID_WAN_WAN);
        const hasQian = hand.some(c => c.id === ID_QIAN_WAN);
        const hasBai = hand.some(c => c.id === ID_BAI_WAN);

        // A. 提尽千王
        if (hasWan && hasQian && hasBai) {
            if (hand.length > 1 && card.id === ID_QIAN_WAN) {
                 return { riskLevel: RiskLevel.PENALTY, ruleId: PenaltyType.TI_JIN_QIAN_WANG, message: '提尽千王：三公在手，手牌>1时不能发千万！', tacticalContext: TacticalPriority.ANTI_BANKER };
            }
        }

        // B. 倒立千红 / 不立万
        if (hasWan && hasQian && !hasBai) {
            if (card.id === ID_QIAN_WAN) {
                return { riskLevel: RiskLevel.PENALTY, ruleId: PenaltyType.DAO_LI_QIAN_HONG, message: '【高课程】倒立千红：万千在手，先红后千是铁律。倒立者独赔！', tacticalContext: TacticalPriority.ANTI_BANKER };
            }
            if (card.id !== ID_WAN_WAN) {
                return { riskLevel: RiskLevel.PENALTY, ruleId: PenaltyType.BU_LI_WAN, message: '不立万：有万无百，必须首发万万！', tacticalContext: TacticalPriority.ANTI_BANKER };
            }
            return null;
        }

        // C. 同门赏肩
        const suits = [Suit.CASH, Suit.STRINGS, Suit.COINS, Suit.TEXTS];
        for (const suit of suits) {
            const suitCards = hand.filter(c => c.suit === suit);
            const shang = suitCards.find(c => c.rank === CardRank.ZUN);
            const jian = suitCards.find(c => c.rank === CardRank.JIAN);

            if (shang && jian) {
                const isPlayingShangOrJian = (card.id === shang.id || card.id === jian.id);
                const isPlayingSequence = suitCards.some(c => c.id === card.id && (Math.abs(c.value - shang.value) === 1 || Math.abs(c.value - jian.value) === 1));
                
                if (card.suit !== suit) {
                     return { riskLevel: RiskLevel.PENALTY, ruleId: PenaltyType.BU_LI_SHANG, message: '不立赏：持有同门赏肩，必须优先打出该门！', tacticalContext: TacticalPriority.ANTI_BANKER };
                }
                
                if (!isPlayingShangOrJian && !isPlayingSequence) {
                     return { riskLevel: RiskLevel.PENALTY, ruleId: PenaltyType.BU_LI_SHANG, message: '不立赏：必须打出赏、肩或其同花顺！', tacticalContext: TacticalPriority.ANTI_BANKER };
                }
            }
        }
        return null;
    }
};

// 2. 不报百 (Leading Rule)
const BuBaoBaiRule: RuleEvaluator = {
    id: 'BU_BAO_BAI',
    priority: 90,
    evaluate: (ctx) => {
        const { player, card, openedSuits } = ctx;
        if (player.isDealer) return null;
        if (!player.hand.some(c => c.id === ID_BAI_WAN)) return null;

        const openedNonCash = openedSuits.filter(s => s.suit !== Suit.CASH);
        if (openedNonCash.length === 0) return null;

        const bankerLed = openedSuits.some(s => s.isBanker);
        if (bankerLed && card.suit === Suit.CASH) {
            return { riskLevel: RiskLevel.PENALTY, ruleId: PenaltyType.WO_DI_BAI_LAO, message: '卧底百老：庄家已首发过，百老不可发十字门！', tacticalContext: TacticalPriority.ANTI_BAI_LAO };
        }

        const uniqueSuits = new Set(openedNonCash.map(s => s.suit));
        if (uniqueSuits.size >= 2 && card.suit === Suit.CASH) {
            return { riskLevel: RiskLevel.PENALTY, ruleId: PenaltyType.WO_DI_BAI_LAO, message: '卧底百老：两门熟门已定，百老不可发十字门！', tacticalContext: TacticalPriority.ANTI_BAI_LAO };
        }

        const hasShang = player.hand.some(c => c.rank === CardRank.ZUN);
        if (!hasShang && card.suit === Suit.CASH) {
            return { riskLevel: RiskLevel.PENALTY, ruleId: PenaltyType.WU_SHANG_BAO_BAI, message: '无赏报百：无赏不可发十字门！', tacticalContext: TacticalPriority.ANTI_BAI_LAO };
        }

        if (!bankerLed && uniqueSuits.size < 2 && hasShang) {
            if (card.suit !== Suit.CASH) {
                return { riskLevel: RiskLevel.PENALTY, ruleId: PenaltyType.BU_BAO_BAI, message: '不报百：符合条件必须首发十字门！', tacticalContext: TacticalPriority.ANTI_BAI_LAO };
            }
        }
        return null;
    }
};

// 3. 禁门次序 (Leading Rule)
const JinMenCiXuRule: RuleEvaluator = {
    id: 'JIN_MEN_CI_XU',
    priority: 80,
    evaluate: (ctx) => {
        const { player, card, openedSuits } = ctx;
        if (player.isDealer) return null;

        const hand = player.hand;
        const openedNonCashSuits = new Set(openedSuits.filter(s => s.suit !== Suit.CASH).map(s => s.suit));
        const jinMenCards = hand.filter(c => c.suit !== Suit.CASH && !openedNonCashSuits.has(c.suit));
        
        const hasBai = hand.some(c => c.id === ID_BAI_WAN);
        const hasWan = hand.some(c => c.id === ID_WAN_WAN);
        const hasQian = hand.some(c => c.id === ID_QIAN_WAN);
        const bankerLedWan = openedSuits.some(s => s.suit === Suit.CASH && s.isBanker); 

        // Conflict Resolution: Bu Li Wan Override
        if (hasWan && hasQian && !hasBai && card.id === ID_WAN_WAN) return null;

        if (!bankerLedWan && !hasWan && !hasQian && hasBai) {
            const bigQing = hand.some(c => c.suit === Suit.CASH && c.rank === CardRank.QING && c.value > 4); 
            if (bigQing && card.id !== ID_BAI_WAN) {
                 return { riskLevel: RiskLevel.PENALTY, ruleId: PenaltyType.QIAN_SENG_WO_DI, message: '千僧卧底：无千万万万，有百及大青，应先发百万！', tacticalContext: TacticalPriority.ANTI_BANKER };
            }
        }

        if (jinMenCards.length > 0 && card.suit === Suit.CASH) {
             return { riskLevel: RiskLevel.PENALTY, ruleId: PenaltyType.JIN_MEN_CI_XU, message: '禁门次序：应先发三门（未开门/生门），不可发十字门！', tacticalContext: TacticalPriority.ANTI_BANKER };
        }
        return null;
    }
};

// 4. 十字门发牌特殊规则 (Leading Rule) + [UPDATED] Gu Fa Shi Zi
const CashLeadingRule: RuleEvaluator = {
    id: 'CASH_LEADING',
    priority: 70,
    evaluate: (ctx) => {
        const { player, card, openedSuits, roundNumber, faceUpPlayedCardIds } = ctx;
        if (player.isDealer) return null;
        
        const hasWan = player.hand.some(c => c.id === ID_WAN_WAN);
        const hasQian = player.hand.some(c => c.id === ID_QIAN_WAN);
        const hasBai = player.hand.some(c => c.id === ID_BAI_WAN);
        const n = player.hand.length;

        // 五桌提万
        const isRedWan = [ID_WAN_WAN, ID_QIAN_WAN, ID_BAI_WAN].includes(card.id);
        if (isRedWan && n === 4) {
             return { riskLevel: RiskLevel.PENALTY, ruleId: PenaltyType.WU_ZHUO_TI_WAN, message: '五桌提万：剩4张牌时不可提万！', tacticalContext: TacticalPriority.ANTI_BANKER };
        }

        const playerLedCash = openedSuits.some(s => s.suit === Suit.CASH && s.leaderId === player.id);

        if (hasWan && hasQian) {
            if (n > 1) {
                if (hasBai && card.id === ID_WAN_WAN) return { riskLevel: RiskLevel.PENALTY, ruleId: PenaltyType.TI_JIN_QIAN_WANG, message: '提尽千王：三公在手首发万万！', tacticalContext: TacticalPriority.ANTI_BANKER };
                if (!hasBai) {
                    if (playerLedCash && card.id === ID_QIAN_WAN) return { riskLevel: RiskLevel.PENALTY, ruleId: PenaltyType.TI_JIN_QIAN_WANG, message: '提尽千王：曾首发万，今发千，违例！', tacticalContext: TacticalPriority.ANTI_BANKER };
                    if (!playerLedCash && card.id === ID_QIAN_WAN) return { riskLevel: RiskLevel.PENALTY, ruleId: PenaltyType.DAO_LI_QIAN_HONG, message: '【高课程】倒立千红：未发万先发千！', tacticalContext: TacticalPriority.ANTI_BANKER };
                }
            }
        }

        if (hasQian && !hasBai) {
            if (n > 1) {
                if (!hasWan && card.id === ID_QIAN_WAN) return { riskLevel: RiskLevel.PENALTY, ruleId: PenaltyType.CHUANG_QIAN, message: '闯千：单千无百，首发千违例！', tacticalContext: TacticalPriority.ANTI_BANKER };
                if (hasWan && card.id === ID_QIAN_WAN && playerLedCash) return { riskLevel: RiskLevel.PENALTY, ruleId: PenaltyType.CHUANG_QIAN, message: '闯千：有万无百，再次发千违例！', tacticalContext: TacticalPriority.ANTI_BANKER };
            }
        }
        
        // 单纯首发千万检查
        if (card.id === ID_QIAN_WAN && n === 8) {
             return { riskLevel: RiskLevel.PENALTY, ruleId: PenaltyType.LEAD_QIAN_WAN, message: '首发千万是禁手。', tacticalContext: TacticalPriority.ANTI_BANKER };
        }

        // [BACKPORTED] Gu Fa Shi Zi
        if (card.suit === Suit.CASH) {
            const isTension = isTableTensionHigh(roundNumber, faceUpPlayedCardIds);
            if (!isTension && !hasBai) {
                 return {
                    riskLevel: RiskLevel.PENALTY,
                    ruleId: 'GU_FA_SHI_ZI', 
                    message: '【高课程】故发十子：三花未落尽，无故发十字门是自寻死路，包赔全场！',
                    tacticalContext: TacticalPriority.ANTI_BAI_LAO
                };
            }
        }

        return null;
    }
};

// 5. 灭牌次序 (Melting Order) - [BACKPORTED RULE]
const MeltingOrderRule: RuleEvaluator = {
    id: 'MIE_PAI_ORDER',
    priority: 110, // High priority check before other following logic
    evaluate: (ctx) => {
        const { player, card, tableCards } = ctx;
        if (tableCards.length === 0) return null; // Leading logic handled elsewhere
        
        const leadSuit = tableCards[0].card.suit;
        // Check if player CAN follow suit
        const canFollow = player.hand.some(c => c.suit === leadSuit);
        
        // Only apply if melting (not following suit)
        if (card.suit !== leadSuit && !canFollow) {
            if (card.suit !== Suit.CASH) {
                // Holding Fodder Cash? (Qing, Not 90, Not 20)
                const hasFodderCash = player.hand.some(c => 
                    c.suit === Suit.CASH && 
                    c.rank === CardRank.QING && 
                    c.id !== ID_90_WAN && 
                    c.id !== ID_20_WAN
                );

                if (hasFodderCash) {
                    return {
                        riskLevel: RiskLevel.WARNING, // Warning in V1, Penalty in V2 strict mode
                        ruleId: 'MIE_PAI_ORDER',
                        message: '【高课程】错留十字：垫牌应“先十后别”。留着十字门黑牌不垫，是给百老留路，兵家大忌！',
                        tacticalContext: TacticalPriority.ANTI_BAI_LAO
                    };
                }
            }
        }
        return null;
    }
};

// 6. 纵趣/放功千/纵百 (Following Rule - Priority 0)
const PriorityZeroRule: RuleEvaluator = {
    id: 'PRIORITY_ZERO',
    priority: 100,
    evaluate: (ctx) => {
        const { player, card, winningInfo, bankerId } = ctx;
        if (!winningInfo) return null;
        const { card: winningCard, playerId: winningPlayerId } = winningInfo;

        // Skip if I am winning or I am banker
        if (winningPlayerId === player.id || winningPlayerId === bankerId) return null;

        // Zong Qu
        if (isQu(winningCard) && player.hand.some(c => c.suit === winningCard.suit && c.value > winningCard.value)) {
            if (!(card.suit === winningCard.suit && card.value > winningCard.value)) {
                 return { riskLevel: RiskLevel.PENALTY, ruleId: PenaltyType.ZONG_QU_GAME, message: '【高课程】纵趣：趣张乃色样之魂，见趣不打，你是想送他公贺吗？', tacticalContext: TacticalPriority.ANTI_SE_YANG };
            }
        }

        // [BACKPORTED] Zong Bai
        if (winningCard.id === ID_BAI_WAN && player.hand.some(c => c.suit === Suit.CASH && c.value > winningCard.value)) {
            if (!(card.suit === Suit.CASH && card.value > winningCard.value)) {
                return {
                    riskLevel: RiskLevel.PENALTY,
                    ruleId: 'ZONG_BAI',
                    message: '【高课程】纵百：百子两家庄！见百必捉，纵放者同纵庄罪。',
                    tacticalContext: TacticalPriority.ANTI_SE_YANG
                };
            }
        }

        // Fang Gong Qian
        if (winningCard.id === ID_QIAN_WAN && player.hand.some(c => c.id === ID_WAN_WAN)) {
            if (card.id !== ID_WAN_WAN) {
                 return { riskLevel: RiskLevel.PENALTY, ruleId: PenaltyType.FANG_GONG_QIAN, message: '放功千：必须用万万捉千万！', tacticalContext: TacticalPriority.ANTI_BANKER };
            }
        }
        return null;
    }
};

// 7. 漏庄/急捉 (Following Rule - Priority 1)
const PriorityOneRule: RuleEvaluator = {
    id: 'PRIORITY_ONE',
    priority: 90,
    evaluate: (ctx) => {
        const { player, card, winningInfo, bankerId, tableCards, recordedCards, mianZhangCard } = ctx;
        if (!winningInfo) return null;
        const { card: winningCard, playerId: winningPlayerId } = winningInfo;
        const isBanker = player.id === bankerId;
        const hand = player.hand;

        // If I'm banker, rules are relaxed
        if (isBanker) return null;

        // Can I win?
        const winners = hand.filter(c => c.suit === winningCard.suit && c.value > winningCard.value).sort((a,b) => b.value - a.value); 
        const canWin = winners.length > 0;
        
        if (!canWin) return null;

        const isCapturing = card.suit === winningCard.suit && card.value > winningCard.value;
        const bankerPlayed = tableCards.some(tc => tc.playerId === bankerId);
        
        if (!bankerPlayed) {
            // Logic: Qin Wang (Optional protection of banker if eligible)
            const isXCash = winningCard.suit === Suit.CASH;
            const capturedCount = player.capturedCards ? player.capturedCards.length : 0;
            const holdsWanOrQian = hand.some(c => c.id === ID_WAN_WAN || c.id === ID_QIAN_WAN);
            const nonCashShangCount = hand.filter(c => c.suit !== Suit.CASH && c.rank === CardRank.ZUN).length;
            const isQinWangEligible = !isXCash && capturedCount === 0 && holdsWanOrQian && nonCashShangCount < 2;

            if (isQinWangEligible) {
                const isTrue = isZhenZhang(card, ctx);
                const isMax = card.id === winners[0].id;
                const sequenceWinners = getSequenceWinners(hand, winningCard, recordedCards);
                const isSeq = sequenceWinners.some(c => c.id === card.id);

                if (isCapturing) {
                    if (!isTrue && !isMax && !isSeq) return null; // Valid Qin Wang
                    // Else fall through
                } else {
                    return { riskLevel: RiskLevel.PENALTY, ruleId: PenaltyType.LOU_ZHUANG, message: '【高课程】漏庄：制庄为第一要务！你有牌能管却纵容庄家，此乃通敌之罪。', tacticalContext: TacticalPriority.ANTI_BANKER };
                }
            } else {
                if (!isCapturing) {
                     const isTrue = isZhenZhang(card, ctx);
                     const isMax = card.id === winners[0].id;
                     if (isTrue || isMax) {
                         return { riskLevel: RiskLevel.PENALTY, ruleId: PenaltyType.LOU_ZHUANG_FAIL, message: '【高课程】漏庄：持有真张或大牌必须捉打！', tacticalContext: TacticalPriority.ANTI_BANKER };
                     }
                }
            }
        } else {
            // Scenario B: Banker HAS played.
            const winnerIsPeasant = winningPlayerId !== bankerId;
            if (winnerIsPeasant) {
                // Teammate winning
                if (isCapturing) {
                    // Exception: Cash High Card Battle
                    if (winningCard.suit === Suit.CASH && card.suit === Suit.CASH) {
                        const winningIsBig = winningCard.value === 9 || winningCard.value === 10;
                        const playingIsBig = card.value === 10 || card.value === 11;
                        if (winningIsBig && playingIsBig) return null;
                    }
                    // Ji Zhuo check (unless it's Qu)
                    if (!isGreen(winningCard)) {
                        return { riskLevel: RiskLevel.PENALTY, ruleId: PenaltyType.JI_ZHUO, message: '【高课程】急捉：庄家已过，友军已赢，此时无故捉打是“自相残杀”，易送庄家香炉脚！', tacticalContext: TacticalPriority.ANTI_SE_YANG };
                    }
                }
            }
        }
        return null;
    }
};

// 8. 纵庄 (Following Rule - Priority 2)
const ZongZhuangRule: RuleEvaluator = {
    id: 'ZONG_ZHUANG',
    priority: 80,
    evaluate: (ctx) => {
        const { player, card, winningInfo, bankerId, tableCards } = ctx;
        if (!winningInfo) return null;
        const { card: winningCard, playerId: winningPlayerId } = winningInfo;

        const canWin = player.hand.some(c => c.suit === winningCard.suit && c.value > winningCard.value);
        if (canWin && winningPlayerId === bankerId && !player.isDealer) {
            const isCapturing = card.suit === winningCard.suit && card.value > winningCard.value;
            if (!isCapturing) {
                 if (isDaZhang(winningCard) || tableCards.length === 3) {
                     return { riskLevel: RiskLevel.PENALTY, ruleId: PenaltyType.ZONG_ZHUANG, message: '纵庄：庄家大牌必须捉！', tacticalContext: TacticalPriority.ANTI_BANKER };
                 }
            }
        }
        return null;
    }
};

const LEADING_STRATEGIES = [BuLiShangRule, BuBaoBaiRule, JinMenCiXuRule, CashLeadingRule];
const FOLLOWING_STRATEGIES = [MeltingOrderRule, PriorityZeroRule, PriorityOneRule, ZongZhuangRule];

// --- MAIN EXPORT ---

export const evaluatePlayRisk = (
    player: Player,
    card: Card,
    tableCards: { card: Card, playerId: number }[],
    bankerId: number,
    allPlayers: Player[],
    recordedCards: Card[],
    openedSuits: { suit: Suit, leaderId: number, isBanker: boolean }[] = [],
    firstLeadInfo: { card: Card, playerId: number } | null = null,
    roundNumber: number = 1,
    mianZhangCard: Card | null = null,
    bankerFirstLeadCard: Card | null = null
): RiskAssessment | null => {
    
    // Prepare Context
    // [FIX] Added faceUpPlayedCardIds by deriving from recordedCards for V1 simple support
    const faceUpPlayedCardIds = new Set(recordedCards.map(c => c.id));
    
    const ctx: RuleContext = {
        player, card, tableCards, bankerId, allPlayers, recordedCards, openedSuits, firstLeadInfo, roundNumber, mianZhangCard, bankerFirstLeadCard, faceUpPlayedCardIds
    };

    if (tableCards.length === 0) {
        // Leading Phase
        for (const rule of LEADING_STRATEGIES) {
            const result = rule.evaluate(ctx);
            if (result) return result;
        }
    } else {
        // Following Phase
        // Calculate Winning Info Once
        const leadSuit = tableCards[0].card.suit;
        let winningCard = tableCards[0].card;
        let winningPlayerId = tableCards[0].playerId;
        let currentBest = winningCard.value;

        tableCards.forEach(tc => {
            if (tc.card.suit === leadSuit && tc.card.value > currentBest) {
                currentBest = tc.card.value;
                winningCard = tc.card;
                winningPlayerId = tc.playerId;
            }
        });
        
        ctx.winningInfo = { card: winningCard, playerId: winningPlayerId, currentBest, isBankerLeading: winningPlayerId === bankerId };

        for (const rule of FOLLOWING_STRATEGIES) {
            const result = rule.evaluate(ctx);
            if (result) return result;
        }
    }

    return { riskLevel: RiskLevel.SAFE, ruleId: 'SAFE', message: '安全', tacticalContext: TacticalPriority.ANTI_BANKER };
};

// --- SUIT STATUS & UTILS (PRESERVED) ---

export const getSuitStatusContext = (
    player: Player, 
    card: Card, 
    bankerId: number, 
    openedSuits: { suit: Suit, leaderId: number, isBanker: boolean }[], 
    recordedCards: Card[], 
    firstLeadInfo: any, 
    faceUpCardIds: Set<string>,
    bankerFirstLeadCard: Card | null
): SuitStatus => {
    // 1. CASH LOGIC
    if (card.suit === Suit.CASH) {
        const allBigThreeUp = faceUpCardIds.has(ID_WAN_WAN) && faceUpCardIds.has(ID_QIAN_WAN) && faceUpCardIds.has(ID_BAI_WAN);
        if (allBigThreeUp) return 'SAFE'; 

        const hasBai = player.hand.some(c => c.id === ID_BAI_WAN);
        if (player.isDealer) {
            return hasBai ? 'SAFE' : 'FORBIDDEN';
        } else {
            if (hasBai) {
                if (bankerFirstLeadCard && bankerFirstLeadCard.id !== ID_WAN_WAN) {
                    return 'SAFE';
                }
            }
            return 'FORBIDDEN';
        }
    }

    // 2. NON-CASH LOGIC (Jin Men)
    const nonCashOpened = openedSuits.filter(s => s.suit !== Suit.CASH);
    const peasantLedSuits = new Set<Suit>();
    nonCashOpened.forEach(s => {
        if (!s.isBanker) peasantLedSuits.add(s.suit);
    });

    let forbiddenSuit: Suit | null = null;
    let isLocked = false;

    const bankerLeadEntry = nonCashOpened.find(s => s.isBanker);
    if (bankerLeadEntry) {
        let pCount = 0;
        for (const s of nonCashOpened) {
            if (s.suit === bankerLeadEntry.suit && s.isBanker) {
                if (pCount < 2) {
                    forbiddenSuit = s.suit;
                    isLocked = true;
                }
                break;
            }
        }
    }

    if (!isLocked) {
        const pSuits = Array.from(peasantLedSuits);
        if (pSuits.length >= 2) {
            const allNonCash = [Suit.STRINGS, Suit.COINS, Suit.TEXTS];
            const familiar = new Set([pSuits[0], pSuits[1]]);
            const remaining = allNonCash.find(s => !familiar.has(s));
            if (remaining) forbiddenSuit = remaining;
        }
    }

    if (forbiddenSuit && card.suit === forbiddenSuit) {
        return 'FORBIDDEN';
    }

    return 'SAFE';
};

export const getPriorityDiscardCards = (
    player: Player, 
    tableCards: { card: Card, playerId: number }[], 
    recordedCards: Card[], 
    openedSuits: { suit: Suit, leaderId: number, isBanker: boolean }[], 
    bankerId: number, 
    firstLeadInfo: { card: Card, playerId: number } | null
) => {
    return player.hand;
};

export const getCaptureRequirement = (
    player: Player, 
    tableCards: { card: Card, playerId: number }[], 
    bankerId: number
) => {
    return { isForced: false, winningCards: [] };
};
