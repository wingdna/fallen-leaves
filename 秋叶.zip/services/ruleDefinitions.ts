
export enum PenaltyType {
  LOU_ZHUANG = 'LOU_ZHUANG',
  ZONG_ZHUANG = 'ZONG_ZHUANG',
  JI_ZHUO = 'JI_ZHUO',
  // Deprecated sub-types of JI_ZHUO removed
  
  LEAD_QIAN_WAN = 'LEAD_QIAN_WAN',
  ZONG_QU_GAME = 'ZONG_QU', 
  FANG_GONG_QIAN = 'FANG_GONG_QIAN',
  LOU_ZHUANG_FAIL = 'LOU_ZHUANG_FAIL',
  
  // Active Strategy Rules
  DAO_LI = 'DAO_LI',
  BU_LI_WAN = 'BU_LI_WAN',
  BU_LI_SHANG = 'BU_LI_SHANG',
  DAO_LI_QIAN_HONG = 'DAO_LI_QIAN_HONG',
  TI_JIN_QIAN_WANG = 'TI_JIN_QIAN_WANG',
  WO_DI_BAI_LAO = 'WO_DI_BAI_LAO',
  WU_SHANG_BAO_BAI = 'WU_SHANG_BAO_BAI',
  BU_BAO_BAI = 'BU_BAO_BAI',
  QIAN_SENG_WO_DI = 'QIAN_SENG_WO_DI',
  JIN_MEN_CI_XU = 'JIN_MEN_CI_XU',
  WU_ZHUO_TI_WAN = 'WU_ZHUO_TI_WAN',
  CHUANG_QIAN = 'CHUANG_QIAN'
}

export const RULE_DESCRIPTIONS: Record<string, string> = {
  [PenaltyType.FANG_GONG_QIAN]: "放功千：千万捉了百万，你持万万却未捉千万。",
  [PenaltyType.LOU_ZHUANG]: "漏庄：未能顶住庄家。",
  [PenaltyType.ZONG_ZHUANG]: "纵庄：放任庄家赢牌或未正确捉打。",
  [PenaltyType.JI_ZHUO]: "急捉：捉牌理由不足（非真张/大张/连张）或牌力不够。",
  [PenaltyType.ZONG_QU_GAME]: "纵趣：当趣张（极）称霸牌池时，持有大牌者必须捉打，违者包赔。",
  [PenaltyType.LEAD_QIAN_WAN]: "首发千万：禁手。",
  [PenaltyType.LOU_ZHUANG_FAIL]: "漏庄：持有真张或大牌必须捉打！",
  
  // New Descriptions
  [PenaltyType.DAO_LI]: "倒立：持有万万和千万（无百万），首发千万为严重违例。",
  [PenaltyType.BU_LI_WAN]: "不立万：持有万万和千万（无百万），首发必须立万（出万万），否则违例。",
  [PenaltyType.BU_LI_SHANG]: "不立赏：持有同门赏、肩，首发必须出赏、肩或其同花顺连牌，否则违例。",
  [PenaltyType.DAO_LI_QIAN_HONG]: "倒立千红：持有万万，首发千万，以急桌论处。",
  [PenaltyType.TI_JIN_QIAN_WANG]: "提尽千王：双持万千只能首发红万，千僧留守，违者包赔。",
  [PenaltyType.WO_DI_BAI_LAO]: "卧底百老：庄家已首发过，或两门熟门已定，百老不应再出十字门。",
  [PenaltyType.WU_SHANG_BAO_BAI]: "无赏报百：手中无赏，不应首发十字门报百。",
  [PenaltyType.BU_BAO_BAI]: "不报百：符合报百条件（闲家、持百、有熟门）必须首发十字门。",
  [PenaltyType.QIAN_SENG_WO_DI]: "千僧卧底：无千万万万，有百万及大青张，应先发百万。",
  [PenaltyType.JIN_MEN_CI_XU]: "禁门次序：三门优先级高于十字门。应先发三门。",
  [PenaltyType.WU_ZHUO_TI_WAN]: "五桌提万：剩余4张牌时违规提万。",
  [PenaltyType.CHUANG_QIAN]: "闯千：单持千万（无百万），首发千万属于违规（除非顶色）。"
};
