
// @ARCHITECT_LOCK: SYSTEM EVENT BUS
// -------------------------------------------------------------------------
// 🛡️ INFRASTRUCTURE LAYER
// Decouples Game Logic from UI Effects (Sound, Toasts, Analytics).
// Implements strict Singleton + Observer pattern.
// -------------------------------------------------------------------------

import { ScoreNotification } from '../types';

type EventType = 
    | 'PLAY_SOUND' 
    | 'SHOW_TOAST' 
    | 'GAME_EVENT' // For Analytics/Telemetry
    | 'SYSTEM_ERROR'
    | 'AUDIO_ERROR'; // [NEW] For handling music load failures

interface SoundPayload { type: 'WOOD' | 'STONE' | 'PAPER' | 'CHIME' | 'DRUM' }
interface GameEventPayload { type: string; playerId?: number; context?: any }
interface AudioErrorPayload { url: string; error?: any }

type PayloadMap = {
    'PLAY_SOUND': SoundPayload;
    'SHOW_TOAST': ScoreNotification;
    'GAME_EVENT': GameEventPayload;
    'SYSTEM_ERROR': { message: string; error?: any };
    'AUDIO_ERROR': AudioErrorPayload;
};

type Handler<T extends EventType> = (payload: PayloadMap[T]) => void;

class EventBus {
    private static instance: EventBus;
    private handlers: Map<EventType, Set<Handler<any>>> = new Map();

    private constructor() {}

    public static getInstance(): EventBus {
        if (!EventBus.instance) {
            EventBus.instance = new EventBus();
        }
        return EventBus.instance;
    }

    public on<T extends EventType>(type: T, handler: Handler<T>): () => void {
        if (!this.handlers.has(type)) {
            this.handlers.set(type, new Set());
        }
        this.handlers.get(type)!.add(handler);
        // Return unbind function
        return () => {
            this.handlers.get(type)?.delete(handler);
        };
    }

    public emit<T extends EventType>(type: T, payload: PayloadMap[T]): void {
        const handlers = this.handlers.get(type);
        if (handlers) {
            handlers.forEach(h => {
                try {
                    h(payload);
                } catch (e) {
                    console.error(`[EventBus] Handler failed for ${type}`, e);
                }
            });
        }
    }
}

export const sysEvents = EventBus.getInstance();
