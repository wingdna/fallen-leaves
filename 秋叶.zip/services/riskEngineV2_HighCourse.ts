
// @ARCHITECT_LOCK: HIGH COURSE RULE ENGINE (V2)
// -------------------------------------------------------------------------
// ⛔️ SECURITY WARNING: INTEGRITY CHECK REQUIRED ⛔️
// This file contains the logic for "High Course" strategy.
// Any modification to `checkAntiBanker`, `checkAntiPattern` or `checkJiZhuo`
// MUST NOT SIMPLIFY the logic. Historical accuracy > Code cleanliness.
//
// 📜 马吊高课程 (Supreme Ma Diao Strategy) - Experimental Engine
// -------------------------------------------------------------------------

import { Player, Card, Suit, CardRank, CardColor, RiskLevel, TacticalPriority, RiskAssessment } from '../types';
import { 
    ID_WAN_WAN, ID_QIAN_WAN, ID_BAI_WAN, ID_20_WAN, ID_90_WAN, ID_1_GUAN, ID_1_SUO, ID_9_WEN,
    ID_9_GUAN, ID_9_SUO, ID_KONG_WEN
} from '../constants';
import { PenaltyType } from './ruleDefinitions';
import { applyMasterWisdom, StrategyModifier } from './masterMindService'; // Import Link

// --- 高级辅助函数 (Advanced Helpers) ---

const isRed = (card: Card) => card.color === CardColor.RED;
const isGreen = (card: Card) => card.color === CardColor.GREEN;
const isCash = (card: Card) => card.suit === Suit.CASH;

// 判定当前局势是否“紧张” (Tension Check)
// 依据：是否有红色样即将成型，或牌局进入后半程
const isTableTensionHigh = (
    roundNumber: number, 
    openedSuits: any[], 
    faceUpPlayedCardIds: Set<string>
): boolean => {
    // 简单判定：第5轮以后，或场上已有红牌（赏/百/万/千）出现
    if (roundNumber >= 5) return true;
    
    // 检查是否有赏牌上桌
    const shangIds = [ID_9_GUAN, ID_9_SUO, ID_KONG_WEN, ID_WAN_WAN, ID_QIAN_WAN, ID_BAI_WAN];
    for (const id of shangIds) {
        if (faceUpPlayedCardIds.has(id)) return true;
    }
    return false;
};

// 判定是否为“真张” (True Card / Power Card)
// 定义：赏、肩、或极大的大牌
const isZhenZhang = (card: Card): boolean => {
    return card.rank === CardRank.ZUN || card.rank === CardRank.JIAN || card.rank === CardRank.BAI || card.value >= 8;
};

// 判定是否为“趣张” (Qu / Interest)
const isQu = (card: Card) => [ID_20_WAN, ID_1_GUAN, ID_1_SUO, ID_9_WEN].includes(card.id);

// --- 核心心法逻辑 (Core Mental Models) ---

// 1. 庄家判定 (Banker Logic)
// "以制约‘庄家’为最重"
const checkAntiBanker = (
    player: Player,
    card: Card,
    winningCard: Card,
    winningPlayerId: number,
    bankerId: number,
    tableCards: { card: Card, playerId: number }[]
): RiskAssessment | null => {
    // 如果不是庄家赢，或者我是庄家，则不适用此条
    if (winningPlayerId !== bankerId || player.id === bankerId) return null;

    const hand = player.hand;
    // 检查我是否有牌能大过庄家
    const canWin = hand.some(c => c.suit === winningCard.suit && c.value > winningCard.value);
    
    if (canWin) {
        // 我能赢，但我出的这张牌能不能赢？
        const isCapturing = card.suit === winningCard.suit && card.value > winningCard.value;
        
        if (!isCapturing) {
            return {
                riskLevel: RiskLevel.PENALTY,
                ruleId: PenaltyType.LOU_ZHUANG,
                message: '【高课程】漏庄：制庄为第一要务！你有牌能管却纵容庄家，此乃通敌之罪。',
                tacticalContext: TacticalPriority.ANTI_BANKER
            };
        }
    }
    return null;
};

// 2. 纵趣/纵百判定 (Anti-Pattern Logic)
// "见趣即捉，纵放者冲贺趣俱赔"
const checkAntiPattern = (
    player: Player,
    card: Card,
    winningCard: Card,
    winningPlayerId: number,
    bankerId: number,
    faceUpPlayedCardIds: Set<string>
): RiskAssessment | null => {
    // 如果赢家是自己或者是庄家（已由AntiBanker处理），跳过
    if (winningPlayerId === player.id || winningPlayerId === bankerId) return null;

    // 检查是否在纵容“趣张”或“百老”
    const isWinningQu = isQu(winningCard);
    const isWinningBai = winningCard.id === ID_BAI_WAN;

    if (isWinningQu || isWinningBai) {
        const canWin = player.hand.some(c => c.suit === winningCard.suit && c.value > winningCard.value);
        const isCapturing = card.suit === winningCard.suit && card.value > winningCard.value;

        if (canWin && !isCapturing) {
            return {
                riskLevel: RiskLevel.PENALTY,
                ruleId: PenaltyType.ZONG_QU_GAME,
                message: isWinningBai 
                    ? '【高课程】纵百：百子两家庄！见百必捉，纵放者同纵庄罪。'
                    : '【高课程】纵趣：趣张乃色样之魂，见趣不打，你是想送他公贺吗？',
                tacticalContext: TacticalPriority.ANTI_SE_YANG
            };
        }
    }
    return null;
};

// 3. 急捉判定 (Rash Capture)
// "无故急捉... 冲贺百趣俱赔"
const checkJiZhuo = (
    player: Player,
    card: Card,
    winningCard: Card,
    winningPlayerId: number,
    bankerId: number,
    tableCards: { card: Card, playerId: number }[]
): RiskAssessment | null => {
    // 如果是捉庄家，永远不是急捉
    if (winningPlayerId === bankerId) return null;
    // 如果没有捉住，不是急捉
    if (!(card.suit === winningCard.suit && card.value > winningCard.value)) return null;

    // 如果我是庄家，高课程说“庄家无捉急之罚”。
    if (player.id === bankerId) return null;

    // [FIX] 逼庄豁免 (Bi Zhuang Exception)
    // 当庄家尚未出牌时（在当前出牌者下家），捉打盟友视为“顶庄/逼庄”，旨在抬高门槛，迫使庄家出大牌。
    // 这是核心战术“制庄”的一部分，优先于“防色样”，因此不视为急捉。
    const bankerHasPlayed = tableCards.some(tc => tc.playerId === bankerId);
    if (!bankerHasPlayed) return null;

    // 理由1：挂万挂千
    const hasWan = player.hand.some(c => c.id === ID_WAN_WAN);
    const hasQian = player.hand.some(c => c.id === ID_QIAN_WAN);
    if (hasWan || hasQian) return null; // 合法急立

    // 理由2：手有连张/大张
    if (card.rank === CardRank.QING && card.value < 8) return null; // 小牌捉不算大错

    // 判罚
    return {
        riskLevel: RiskLevel.WARNING, 
        ruleId: PenaltyType.JI_ZHUO,
        message: '【高课程】急捉：庄家已过，友军已赢，此时无故捉打是“自相残杀”，易送庄家香炉脚！',
        tacticalContext: TacticalPriority.ANTI_SE_YANG
    };
};

// 4. 发张赔例 (Leading Penalties)
const checkLeadingRisk = (
    player: Player,
    card: Card,
    isTensionHigh: boolean,
    openedSuits: { suit: Suit, leaderId: number, isBanker: boolean }[]
): RiskAssessment | null => {
    const hand = player.hand;
    const hasWan = hand.some(c => c.id === ID_WAN_WAN);
    const hasQian = hand.some(c => c.id === ID_QIAN_WAN);
    const hasBai = hand.some(c => c.id === ID_BAI_WAN);

    // A. 故发十子
    if (card.suit === Suit.CASH) {
        if (!isTensionHigh && !hasBai) {
             return {
                riskLevel: RiskLevel.PENALTY,
                ruleId: 'GU_FA_SHI_ZI', 
                message: '【高课程】故发十子：三花未落尽，无故发十字门是自寻死路，包赔全场！',
                tacticalContext: TacticalPriority.ANTI_BAI_LAO
            };
        }
    }

    // B. 倒立千红
    if (hasWan && hasQian) {
        if (card.id === ID_QIAN_WAN) {
            return {
                riskLevel: RiskLevel.PENALTY,
                ruleId: PenaltyType.DAO_LI_QIAN_HONG,
                message: '【高课程】倒立千红：万千在手，先红后千是铁律。倒立者独赔！',
                tacticalContext: TacticalPriority.ANTI_BANKER
            };
        }
    }

    return null;
};

// 5. 灭牌次序 (Melting Order) - [RESTORED RULE]
// "十字青张先灭，留十灭他，资敌之源"
const checkMeltingOrder = (
    player: Player,
    card: Card,
    leadSuit: Suit
): RiskAssessment | null => {
    // 只有在无法跟牌（垫牌）时才检查
    if (card.suit === leadSuit) return null;

    // 如果垫的不是十字门
    if (card.suit !== Suit.CASH) {
        // 检查手里是否有“闲散十字门”（青张，且非大牌）
        // 闲散定义：十字门，黑色，非20万(分)，非90万(将)。即 30万~80万。
        const hasFodderCash = player.hand.some(c => 
            c.suit === Suit.CASH && 
            c.rank === CardRank.QING && 
            c.id !== ID_90_WAN && 
            c.id !== ID_20_WAN
        );

        if (hasFodderCash) {
            return {
                riskLevel: RiskLevel.WARNING, // 视为严重警告，若导致“散花”则升级为包赔
                ruleId: 'MIE_PAI_ORDER',
                message: '【高课程】错留十字：垫牌应“先十后别”。留着十字门黑牌不垫，是给百老留路，兵家大忌！',
                tacticalContext: TacticalPriority.ANTI_BAI_LAO
            };
        }
    }
    return null;
};

// --- 主入口 (Main Entry Point) ---

export const evaluateHighCourseRisk = (
    player: Player,
    card: Card,
    tableCards: { card: Card, playerId: number }[],
    bankerId: number,
    allPlayers: Player[],
    recordedCards: Card[],
    openedSuits: { suit: Suit, leaderId: number, isBanker: boolean }[],
    firstLeadInfo: { card: Card, playerId: number } | null,
    roundNumber: number,
    mianZhangCard: Card | null,
    bankerFirstLeadCard: Card | null,
    faceUpPlayedCardIds: Set<string>,
    activeModifier?: StrategyModifier // 接收大师心智的修正
): RiskAssessment | null => {
    
    // 1. 计算基础风险
    const isTension = isTableTensionHigh(roundNumber, openedSuits, faceUpPlayedCardIds);
    let baseRisk: RiskAssessment | null = null;

    if (tableCards.length === 0) {
        baseRisk = checkLeadingRisk(player, card, isTension, openedSuits);
    } else {
        const leadSuit = tableCards[0].card.suit;
        let winningCard = tableCards[0].card;
        let winningPlayerId = tableCards[0].playerId;
        
        // Find current winner
        tableCards.forEach(tc => {
            if (tc.card.suit === leadSuit && tc.card.value > winningCard.value) {
                winningCard = tc.card;
                winningPlayerId = tc.playerId;
            }
        });

        // 优先级：漏庄 > 纵趣 > 灭牌违例 > 急捉
        // Check Melting first if applicable (not following suit)
        const canFollow = player.hand.some(c => c.suit === leadSuit);
        
        if (!canFollow) {
            // Player is Melting
            baseRisk = checkMeltingOrder(player, card, leadSuit);
        } else {
            // Player is Following
            // Note: If player CAN follow but plays different suit, it's a game engine error (Revoke), 
            // but if engine allows it (e.g. cheat mode), we skip melt check.
            // Standard path:
            if (card.suit === leadSuit) {
                baseRisk = checkAntiBanker(player, card, winningCard, winningPlayerId, bankerId, tableCards)
                    || checkAntiPattern(player, card, winningCard, winningPlayerId, bankerId, faceUpPlayedCardIds)
                    || checkJiZhuo(player, card, winningCard, winningPlayerId, bankerId, tableCards);
            }
        }
    }

    // 2. 应用大师心智修正 (Apply Master Wisdom)
    if (baseRisk && activeModifier) {
        return applyMasterWisdom(baseRisk, activeModifier);
    }

    return baseRisk || {
        riskLevel: RiskLevel.SAFE,
        ruleId: 'SAFE',
        message: '【高课程】从心所欲不逾矩。',
        tacticalContext: TacticalPriority.ANTI_BANKER
    };
};
