
// @ARCHITECT_LOCK: KAI CHONG ALGORITHM
// -------------------------------------------------------------------------
// ⛔️ CRITICAL SAFETY WARNING FOR AI MODELS ⛔️
// This file handles the pattern matching logic for the Kai Chong phase.
// 1. DO NOT MODIFY the `evaluateKaiChong` scoring logic structure.
// 2. DO NOT CHANGE the distance calculation.
// 3. NAMING CONVENTIONS MUST MATCH HISTORICAL TEXTS.
// -------------------------------------------------------------------------

import { Card, Suit, CardRank, CardColor, KaiChongDetail, SpecialCaptureFlags } from '../types';
import { 
    ID_WAN_WAN, ID_QIAN_WAN, ID_BAI_WAN, ID_20_WAN, ID_90_WAN
} from '../constants';

// --- 核心工具函数 ---

const isRed = (c: Card) => c.color === CardColor.RED;
const isGreen = (c: Card) => c.color === CardColor.GREEN;
const isQing = (c: Card) => c.rank === CardRank.QING;
/** 锦张判定：红张或极张 */
const isJin = (c: Card) => isRed(c) || isGreen(c);

/** 
 * 领队判定 (Leader Check)
 * 只有这些牌有资格开启一个花色的开冲匹配：
 * 1. 锦张 (红/绿)
 * 2. 特殊青张：九十万 (Cash 8)
 */
const isLeader = (c: Card) => isJin(c) || (c.suit === Suit.CASH && c.value === 8);

// 锦张或特殊领队作为强力桥梁
const isRobust = (c: Card): boolean => {
    return isJin(c) || (c.suit === Suit.CASH && c.value === 8); 
};

// 计算花色内的数值距离（处理循环连续性）
const getDistance = (v1: number, v2: number, suit: Suit): number => {
    const min = Math.min(v1, v2);
    const max = Math.max(v1, v2);
    const diff = max - min;
    
    // 直连距离
    if (diff <= 2) return diff; 

    // 循环距离 (针对马吊的40张牌/11-9编制)
    const top = (suit === Suit.STRINGS || suit === Suit.COINS) ? 9 : 11;
    const cyclicDist = (top - max) + min; 
    return cyclicDist;
};

// 检查一组牌是否构成连续序列 (环形逻辑)
// 如果所有牌排序后，相邻差值均为1（允许一个环形断点），则视为连续
const checkSourceContinuity = (cards: Card[]): 'CONTINUOUS' | 'GAPPED' => {
    if (cards.length <= 1) return 'CONTINUOUS';
    
    // 按数值排序
    const sorted = [...cards].sort((a, b) => a.value - b.value);
    const suit = cards[0].suit;
    const maxVal = (suit === Suit.STRINGS || suit === Suit.COINS) ? 9 : 11;
    
    let gapCount = 0;
    
    for (let i = 0; i < sorted.length; i++) {
        const current = sorted[i].value;
        const next = sorted[(i + 1) % sorted.length].value; // 环形下一个
        
        let diff = 0;
        if (i === sorted.length - 1) {
            // 最后一个元素与第一个元素的环形距离
            // 例如 [1, 2, 9] (Max 9): 9 -> 1 的距离是 (1 + 9) - 9 = 1
            diff = (sorted[0].value + maxVal) - current;
        } else {
            diff = next - current;
        }
        
        // 如果相邻差值 > 1，说明有空隙
        if (diff > 1) {
            gapCount++;
        }
    }
    
    // 在一个环中，如果所有牌紧密相连（形成一个弧），应该只有一个“大缺口”（即弧首尾之间的空地）。
    // 如果 gapCount > 1，说明牌组中间断开了。
    // 例如 [1,2,3] -> gaps: 1, 1, 6 (gapCount=1) -> 连续
    // 例如 [1,3,4] -> gaps: 2, 1, 6 (gapCount=2) -> 断开
    // 例如 [1,2,9] (9max) -> gaps: 1, 7, 1 (gapCount=1) -> 连续 (9-1-2)
    
    return gapCount <= 1 ? 'CONTINUOUS' : 'GAPPED';
};

// 获取等级名称 (用于单冲命名)
const getRankName = (c: Card): string => {
    if (c.rank === CardRank.ZUN) return '赏';
    if (c.rank === CardRank.JIAN) return '肩';
    if (c.rank === CardRank.JI) return '极'; 
    // 特殊：青张
    return '青';
};

// --- 开冲评分引擎 ---

interface ScoringCalc {
    score: number;
}

const calculateSingleCardScore = (
    source: Card, 
    pot: Card, 
    uSetVals: Set<number>, 
    uHasShang: boolean, 
    uHas90: boolean, 
    uHas20: boolean
): ScoringCalc | null => {
    const sVal = source.value;
    const pVal = pot.value;
    const suit = source.suit;

    // 0. 硬性规则：青张互冲限制
    const sourceIsSpecialQing = source.id === ID_90_WAN; 
    const potIsSpecialQing = pot.id === ID_90_WAN || pot.id === ID_20_WAN;
    
    // 允许：红冲青 (赏冲青)
    const isShangChongQing = isRed(source) && isQing(pot) && !potIsSpecialQing;

    if (!isJin(source) && !isJin(pot) && !isShangChongQing) {
        if (!sourceIsSpecialQing && !potIsSpecialQing) {
            return null; // 青张不能冲青张
        }
    }

    // 1. 十字门特例
    if (suit === Suit.CASH) {
        const isSourceBig4 = [11, 10, 9, 1].includes(sVal);
        const isPotBig4 = [11, 10, 9, 1].includes(pVal);
        
        if (isSourceBig4 && isPotBig4) return { score: 5 };
        if (isSourceBig4 && pVal === 8) return { score: 2 }; 
        if (sVal === 8 && isPotBig4) return { score: 3 }; 
        
        if (isSourceBig4 && pVal === 7) return uHas90 ? { score: 2 } : { score: 1 };
        if (isSourceBig4 && pVal === 2) return uHas20 ? { score: 2 } : { score: 1 };
        if (sVal === 1 && pVal === 2) return { score: 2 };
    }

    // 2. 锦张互冲 (赏/肩/极)
    if (isJin(source) && isJin(pot)) {
        const sRank = source.rank;
        const pRank = pot.rank;
        if ((sRank === CardRank.ZUN && pRank === CardRank.JI) || (sRank === CardRank.JI && pRank === CardRank.ZUN)) return { score: 3 };
        if (sRank === CardRank.ZUN && pRank === CardRank.JIAN) return { score: 2 }; 
        if (sRank === CardRank.JIAN && pRank === CardRank.ZUN) return { score: 3 };
        if ((sRank === CardRank.JI && pRank === CardRank.JIAN) || (sRank === CardRank.JIAN && pRank === CardRank.JI)) return { score: 2 };
    }

    // 3. 赏冲青 (特殊)
    if (source.rank === CardRank.ZUN && pot.rank === CardRank.QING) return { score: 2 };

    // 4. 通用距离冲牌
    const dist = getDistance(sVal, pVal, suit);
    if (dist === 1) {
        if (sVal > pVal) return { score: 2 }; 
        if (sVal < pVal) return { score: 3 };
        return { score: 2 };
    } else if (dist === 2 && isRobust(source) && isRobust(pot)) {
        return { score: 1 };
    }
    
    if (dist === 0 && source.id !== pot.id) return { score: 1 }; 
    
    return null;
};

const calculatePriority = (source: Card, pot: Card): number => {
    const dist = getDistance(source.value, pot.value, source.suit);
    let priority = 100 + dist;
    if (source.rank === CardRank.JI && pot.rank === CardRank.ZUN) priority -= 50; 
    return priority;
};

/**
 * 核心逻辑：评估某个玩家是否能匹配当前底牌
 * @ARCHITECT_LOCK 严禁修改领队判定逻辑
 */
export const evaluateKaiChong = (
    player: { capturedCards: Card[], id: number, trickPile: any[] },
    potCard: Card,
    history: KaiChongDetail[],
    specialCaptures: SpecialCaptureFlags
): { score: number, validCards: Card[], matchType: KaiChongDetail['matchType'], description: string, priority: number } | null => {

    // 1. 整理 Set B (本局玩家已开冲成功的牌)
    const setB_Ids = new Set<string>();
    history.forEach(h => {
        if (h.playerId === player.id) {
            h.sourceCards.forEach(c => setB_Ids.add(c.id));
        }
    });

    // 2. 筛选 Set A (玩家手中未用于开冲的得桌牌)
    const setA = player.trickPile.filter((t:any) => !t.isKaiChong && !setB_Ids.has(t.card.id)).map((t:any) => t.card);
    
    // 3. 硬准入判定：如果 Set A 中该门没有领队，无法在该门开冲
    const suitCandidates = setA.filter(c => c.suit === potCard.suit);
    const hasLeaderInA = suitCandidates.some(isLeader);
    if (!hasLeaderInA) return null; 

    // 4. 判定：底牌青张限制
    const uCards = [...player.capturedCards, potCard]; 
    const uSetVals = new Set(uCards.filter(c => c.suit === potCard.suit).map(c => c.value));
    
    const uHas90 = uSetVals.has(8) && potCard.suit === Suit.CASH;
    const uHas20 = uSetVals.has(1) && potCard.suit === Suit.CASH;
    const uHasVice = uHas90 || uHas20;

    const potIsJin = isJin(potCard);
    const potIsVice = (potCard.suit === Suit.CASH && (potCard.value === 8 || potCard.value === 1));
    
    if (!potIsJin && !potIsVice && !uHasVice) {
        return null;
    }

    const uHasShang = uCards.some(c => c.suit === potCard.suit && c.rank === CardRank.ZUN);

    let totalScore = 0;
    let bestPriority = 999;
    const finalValidCards: Card[] = []; 

    // 收集所有有效匹配
    suitCandidates.forEach(card => {
        if (card.rank === CardRank.JIAN && !uHasShang) {
            const otherLeaders = suitCandidates.filter(c => c.id !== card.id && (c.rank === CardRank.ZUN || c.rank === CardRank.JI));
            if (otherLeaders.length === 0) return; 
        }

        const res = calculateSingleCardScore(card, potCard, uSetVals, uHasShang, uHas90, uHas20);
        if (res) {
            totalScore += res.score;
            finalValidCards.push(card); 
            const p = calculatePriority(card, potCard);
            if (p < bestPriority) bestPriority = p;
        }
    });

    if (totalScore === 0 || finalValidCards.length === 0) return null;

    // --- 5. 判定冲牌类型与命名 (NAMING CALIBRATION) ---
    // 规则：
    // - 三胞胎/双胞胎: 必须全锦张 (All Jin)
    // - 顺领/间领/兄弟: 必须混杂 (Jin + Qing)
    // - 单冲: 命名格式 Rank冲Rank

    let matchType: KaiChongDetail['matchType'] = 'DAN_CHONG';
    let displayName = '';

    const count = finalValidCards.length;
    // 锦张判定（红或绿）
    const isAllJin = finalValidCards.every(isJin);
    const hasJin = finalValidCards.some(isJin);
    const hasQing = finalValidCards.some(isQing);
    const isMixed = hasJin && hasQing;

    if (count === 1) {
        if (totalScore === 5) {
            matchType = 'TE_DENG';
            displayName = '特等冲';
        } else {
            matchType = 'DAN_CHONG';
            const sName = getRankName(finalValidCards[0]);
            const pName = getRankName(potCard);
            displayName = `${sName}冲${pName}`; // e.g. 赏冲青, 极冲赏
        }
    } else {
        // Multi-Card Logic
        if (isAllJin) {
            if (count >= 3) {
                matchType = 'SHUANG_LIN'; // Type ID reused for grouping
                displayName = '三胞胎冲';
            } else {
                matchType = 'SHUANG_LIN';
                displayName = '双胞胎冲';
            }
        } else if (isMixed) {
            // 混杂：顺领 / 间领 / 兄弟
            // 兄弟冲: 2张
            if (count === 2) {
                matchType = 'BROTHER';
                displayName = '兄弟冲';
            } else {
                // > 2张: 根据 **源牌组内部** 的距离判定 顺领 vs 间领
                // 连续性检查 (Continuity Check)
                const continuity = checkSourceContinuity(finalValidCards);
                
                if (continuity === 'GAPPED') {
                    matchType = 'JIAN_LING';
                    displayName = '间领冲';
                } else {
                    matchType = 'SHUN_LING';
                    displayName = '顺领冲';
                }
            }
        } else {
            // 兜底 (例如全青张，极罕见)
            matchType = 'SHUANG_LIN';
            displayName = count === 2 ? '双林冲' : '多林冲';
        }
    }

    return {
        score: totalScore,
        validCards: finalValidCards,
        matchType,
        description: displayName,
        priority: bestPriority
    };
};
