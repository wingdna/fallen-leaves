
// @ARCHITECT_LOCK: TELEMETRY KERNEL
// -------------------------------------------------------------------------
// 🛡️ SYSTEM INTEGRITY: DIAGNOSTICS
// Captures runtime exceptions, performance dips, and state snapshots.
// Persists to LocalStorage for Admin retrieval.
// -------------------------------------------------------------------------

import { GamePhase } from '../types';

export interface LogEntry {
    id: string;
    timestamp: number;
    level: 'INFO' | 'WARN' | 'ERROR' | 'FATAL';
    category: 'SYSTEM' | 'GAMEPLAY' | 'PERFORMANCE' | 'NETWORK';
    message: string;
    metadata?: any;
}

const STORAGE_KEY_LOGS = 'madiao_system_logs_v1';
const MAX_LOGS = 100;

class TelemetryService {
    private static instance: TelemetryService;
    private logs: LogEntry[] = [];
    private isPersisting = false;

    private constructor() {
        this.loadLogs();
        this.setupGlobalHandlers();
    }

    public static getInstance(): TelemetryService {
        if (!TelemetryService.instance) {
            TelemetryService.instance = new TelemetryService();
        }
        return TelemetryService.instance;
    }

    private setupGlobalHandlers() {
        if (typeof window !== 'undefined') {
            window.addEventListener('error', (event) => {
                this.captureError('SYSTEM', 'Uncaught Exception', {
                    message: event.message,
                    filename: event.filename,
                    lineno: event.lineno,
                    colno: event.colno
                });
            });

            window.addEventListener('unhandledrejection', (event) => {
                this.captureError('SYSTEM', 'Unhandled Promise Rejection', {
                    reason: event.reason ? event.reason.toString() : 'Unknown'
                });
            });
        }
    }

    private loadLogs() {
        try {
            const saved = localStorage.getItem(STORAGE_KEY_LOGS);
            if (saved) {
                this.logs = JSON.parse(saved);
            }
        } catch (e) {
            // If logs are corrupt, start fresh
            this.logs = [];
        }
    }

    private persistLogs() {
        if (this.isPersisting) return;
        this.isPersisting = true;
        
        // Debounce write
        setTimeout(() => {
            try {
                // Keep only last N logs
                if (this.logs.length > MAX_LOGS) {
                    this.logs = this.logs.slice(this.logs.length - MAX_LOGS);
                }
                localStorage.setItem(STORAGE_KEY_LOGS, JSON.stringify(this.logs));
            } catch (e) {
                console.warn("Telemetry Write Failed", e);
            } finally {
                this.isPersisting = false;
            }
        }, 1000);
    }

    public log(level: LogEntry['level'], category: LogEntry['category'], message: string, metadata?: any) {
        const entry: LogEntry = {
            id: Math.random().toString(36).substr(2, 9),
            timestamp: Date.now(),
            level,
            category,
            message,
            metadata
        };
        
        // Console echo for dev
        if (level === 'ERROR' || level === 'FATAL') {
            console.error(`[${category}] ${message}`, metadata);
        } else if (level === 'WARN') {
            console.warn(`[${category}] ${message}`, metadata);
        }

        this.logs.push(entry);
        this.persistLogs();
    }

    public captureError(category: LogEntry['category'], context: string, error: any) {
        this.log('ERROR', category, context, {
            errorMsg: error?.message || String(error),
            stack: error?.stack,
            ...error
        });
    }

    public recordStateSnapshot(phase: GamePhase, activePlayer: number, tableCardCount: number) {
        // Sample critical state for debugging logic locks
        this.log('INFO', 'GAMEPLAY', `State Snapshot: ${phase}`, {
            activePlayer,
            tableCardCount
        });
    }

    public getLogs(): LogEntry[] {
        return [...this.logs].sort((a, b) => b.timestamp - a.timestamp);
    }

    public clearLogs() {
        this.logs = [];
        localStorage.removeItem(STORAGE_KEY_LOGS);
    }
}

export const telemetry = TelemetryService.getInstance();
