
// @ARCHITECT_LOCK: LAYOUT STRATEGY PATTERN
// -------------------------------------------------------------------------
// ⛔️ DO NOT MODIFY LOGIC STRUCTURE ⛔️
// Centralized Layout Engine Strategy Map.
// UI components must consume these strategies, NOT create their own media queries.
// -------------------------------------------------------------------------

export type LayoutMode = 'mobile_portrait' | 'mobile_landscape' | 'tablet_portrait' | 'tablet_landscape' | 'desktop';

export interface TablePosition {
    x?: number; y?: number; 
    top?: string; bottom?: string; left?: string; right?: string; 
    rotateZ?: number;
    anchor?: 'top' | 'bottom' | 'left' | 'right' | 'center';
    align?: 'start' | 'center' | 'end';
    maxWidth?: number; // Constraint for dynamic scaling
}

export interface Player3DConfig {
    top?: string; bottom?: string; left?: string; right?: string;
    scale: number;
    handYOffset: number; handXOffset: number;
    wonCardsTablePos?: TablePosition;
}

export interface HUDConfig {
    style: string;
}

export interface TableCardConfig {
    baseZ: number; winnerLiftZ: number; rotationX: number; scale: number; forceUpright?: boolean;
}

export interface LayoutStrategy {
    mode: LayoutMode;
    camera: { rotateX: number; z: number; perspective: string };
    table: { width: string; height: string; yOffset: number; thickness: number };
    isVertical: boolean;
    hidePaperDolls: boolean;
    hide3DActionPlate: boolean;
    elementsOnTable: boolean;
    compass: { 
        size: string; 
        yOffset: number; 
        shape: 'rect' | 'circle' | 'zen'; 
        needleScale: number 
    };
    mianZhangPos: { top?: string; left?: string; right?: string; bottom?: string; rotateZ?: number };
    actionButton: { y: number; z: number; scale: number };
    cardScale: number;
    tableCardConfig: TableCardConfig;
    tableCardSpread: { x: number; y: number };
    cardCenterOffset: { x: number; y: number };
    players3D: Record<'Top' | 'Left' | 'Right' | 'Bottom', Player3DConfig>;
    hud: Record<'Top' | 'Left' | 'Right' | 'Bottom', HUDConfig>;
    hand: { type: 'fan' | 'spread_center' | 'spread_justify'; cardWidthRem: number; bottomOffset: string; liftZ: number; tiltX: number; arcRadius?: number; maxFanAngle?: number; overlapFactor?: number; };
}

const DESKTOP_STRATEGY: LayoutStrategy = {
    mode: 'desktop',
    camera: { rotateX: 52, z: -580, perspective: '1500px' },
    // [DESKTOP UPDATE]: Height expanded to 132vh (1.1x), yOffset pushed to 410px to cover bottom edge
    table: { width: '96vw', height: '132vh', yOffset: 410, thickness: 45 }, 
    isVertical: false,
    hidePaperDolls: true, 
    hide3DActionPlate: true, 
    elementsOnTable: true,
    compass: { size: '54vw', yOffset: 0, shape: 'zen', needleScale: 1.2 },
    mianZhangPos: { top: '3%', left: '3%', rotateZ: 25 },
    actionButton: { y: 480, z: 55, scale: 1.4 }, 
    cardScale: 1.1, 
    tableCardSpread: { x: 180, y: 160 }, 
    tableCardConfig: { baseZ: 60, winnerLiftZ: 220, rotationX: -25, scale: 1.0, forceUpright: true },
    cardCenterOffset: { x: 0, y: 0 },
    players3D: {
        // [DESKTOP MAGNETIC EDGE]
        // Top: Horizontally centered (left:50%), anchored to top edge (top:2%).
        Top: { top: '-25%', left: '50%', scale: 1.0, handYOffset: 0, handXOffset: 0, 
            wonCardsTablePos: { top: '2%', left: '50%', anchor: 'top', align: 'center', maxWidth: 600, rotateZ: 180 } },
        // Left: Vertically centered (top:50%), anchored to left edge (left:2%).
        Left: { left: '2%', top: '50%', scale: 1.0, handYOffset: 0, handXOffset: 0, 
            wonCardsTablePos: { left: '2%', top: '50%', anchor: 'left', align: 'center', maxWidth: 450, rotateZ: 90 } },
        // Right: Vertically centered (top:50%), anchored to right edge (right:2%).
        Right: { right: '2%', top: '50%', scale: 1.0, handYOffset: 0, handXOffset: 0, 
            wonCardsTablePos: { right: '2%', top: '50%', anchor: 'right', align: 'center', maxWidth: 450, rotateZ: -90 } },
        // Bottom: Fixed to 1/6 width (16.66%), expanding right.
        Bottom: { bottom: '2%', left: '50%', scale: 1.0, handYOffset: 0, handXOffset: 0, 
            wonCardsTablePos: { bottom: '6%', left: '16.66%', anchor: 'left', align: 'start', maxWidth: 600, rotateZ: 0 } } 
    },
    hud: {
        Top: { style: "top-10 left-1/2 -translate-x-1/2 scale-110" },
        Left: { style: "left-16 top-1/2 -translate-y-1/2 scale-110" },
        Right: { style: "right-16 top-1/2 -translate-y-1/2 scale-110" },
        // [VISUAL UPDATE] Action Capsule lowered to 135px (embedded behind cards)
        Bottom: { style: "bottom-[135px] left-1/2 -translate-x-1/2 scale-[1.0]" } 
    },
    // [VISUAL UPDATE] Hand Cards lowered (80px -> 10px) to sink them back down
    hand: { type: 'spread_center', cardWidthRem: 9.5, bottomOffset: '10px', liftZ: 80, tiltX: 15, overlapFactor: 0.35 }
};

const MOBILE_PORTRAIT_STRATEGY: LayoutStrategy = {
    mode: 'mobile_portrait',
    camera: { rotateX: 35, z: -50, perspective: '2000px' },
    table: { width: '140vw', height: '145vh', yOffset: 480, thickness: 30 },
    isVertical: true,
    hidePaperDolls: true,
    hide3DActionPlate: true,
    elementsOnTable: true,
    compass: { size: '84vw', yOffset: -40, shape: 'zen', needleScale: 1.0 },
    mianZhangPos: { left: '5%', top: '2%', rotateZ: 15 },
    actionButton: { y: 380, z: 20, scale: 0.9 },
    cardScale: 0.8,
    tableCardConfig: { baseZ: 40, winnerLiftZ: 100, rotationX: -25, scale: 1.0, forceUpright: false },
    tableCardSpread: { x: 80, y: 110 },
    cardCenterOffset: { x: 0, y: 0 }, 
    players3D: {
        // [MOBILE PORTRAIT MAGNETIC EDGE]
        // Top: Centered Horizontally, Anchored Top
        Top: { top: '4%', left: '50%', scale: 0.7, handYOffset: 160, handXOffset: 0, 
            wonCardsTablePos: { top: '4%', left: '50%', maxWidth: 280, anchor: 'top', rotateZ: 180, align: 'center' } 
        },
        // Left: Centered Vertically, Anchored Left Edge (14% is visual edge of 140vw table)
        Left: { left: '2%', top: '35%', scale: 0.7, handYOffset: 80, handXOffset: 0, 
            wonCardsTablePos: { left: '14%', top: '50%', maxWidth: 320, anchor: 'left', rotateZ: 90, align: 'center' } 
        },
        // Right: Centered Vertically, Anchored Right Edge
        Right: { right: '2%', top: '35%', scale: 0.7, handYOffset: 80, handXOffset: 60, 
            wonCardsTablePos: { right: '14%', top: '50%', maxWidth: 320, anchor: 'right', rotateZ: -90, align: 'center' } 
        },
        // Bottom: Fixed 1/6 width, expanding right
        Bottom: { top: '82%', left: '50%', scale: 0.85, handYOffset: 0, handXOffset: 0, 
            wonCardsTablePos: { bottom: '20%', left: '16.66%', maxWidth: 350, anchor: 'left', rotateZ: 0, align: 'start' } 
        }
    },
    hud: {
        Top: { style: "top-4 left-1/2 -translate-x-1/2" },
        Left: { style: "left-4 top-[35%] -translate-y-1/2" },
        Right: { style: "right-4 top-[35%] -translate-y-1/2" },
        Bottom: { style: "bottom-[135px] left-1/2 -translate-x-1/2" }
    },
    // [VISUAL UPDATE] Spacing: 0.35 overlap; Offset -2.5% for tangent bottom
    hand: { type: 'spread_center', cardWidthRem: 4.8, bottomOffset: '-2.5%', liftZ: 200, tiltX: 0, overlapFactor: 0.35 }
};

const MOBILE_LANDSCAPE_STRATEGY: LayoutStrategy = {
    ...DESKTOP_STRATEGY,
    mode: 'mobile_landscape',
    camera: { rotateX: 65, z: -50, perspective: '1000px' },
    table: { width: '110vw', height: '100vw', yOffset: 140, thickness: 20 },
    compass: { size: '66vw', yOffset: 20, shape: 'zen', needleScale: 1.0 },
    cardScale: 0.9,
    tableCardConfig: { baseZ: 5, winnerLiftZ: 40, rotationX: -5, scale: 1.0 },
    cardCenterOffset: { x: 0, y: 0 },
    hud: {
        Top: { style: "top-2 left-1/2 -translate-x-1/2" },
        Left: { style: "left-4 top-1/2 -translate-y-1/2" },
        Right: { style: "right-4 top-1/2 -translate-y-1/2" },
        Bottom: { style: "bottom-[70px] left-1/2 -translate-x-1/2" }
    },
    players3D: {
        ...DESKTOP_STRATEGY.players3D,
        // Landscape overrides - Magnetic Edges
        Top: { top: '-25%', left: '50%', scale: 1.0, handYOffset: 0, handXOffset: 0, 
            wonCardsTablePos: { top: '2%', left: '50%', anchor: 'top', align: 'center', maxWidth: 500, rotateZ: 180 } },
        Left: { left: '2%', top: '50%', scale: 1.0, handYOffset: 0, handXOffset: 0, 
            wonCardsTablePos: { left: '5%', top: '50%', anchor: 'left', align: 'center', maxWidth: 350, rotateZ: 90 } },
        Right: { right: '2%', top: '50%', scale: 1.0, handYOffset: 0, handXOffset: 0, 
            wonCardsTablePos: { right: '5%', top: '50%', anchor: 'right', align: 'center', maxWidth: 350, rotateZ: -90 } },
        Bottom: { bottom: '2%', left: '50%', scale: 1.0, handYOffset: 0, handXOffset: 0,
            wonCardsTablePos: { bottom: '15%', left: '16.66%', anchor: 'left', align: 'start', maxWidth: 500, rotateZ: 0 } 
        }
    },
    // [VISUAL UPDATE] Spacing: 0.35 overlap; Offset -2.5% for tangent bottom
    hand: { type: 'spread_center', cardWidthRem: 6.5, bottomOffset: '-2.5%', overlapFactor: 0.35, liftZ: 50, tiltX: 10 }
};

export const getLayoutStrategy = (width: number, height: number): LayoutStrategy => {
    const aspect = width / height;
    if (width >= 1024 && aspect >= 1.3) return DESKTOP_STRATEGY;
    if (aspect < 1) return MOBILE_PORTRAIT_STRATEGY;
    return MOBILE_LANDSCAPE_STRATEGY;
};
