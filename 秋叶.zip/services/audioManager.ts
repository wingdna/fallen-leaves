import { BGM_URL, SFX_ASSETS, AUDIO_CONFIG } from './audioAssets';
import { sysEvents } from './eventBus';

// @ARCHITECT_LOCK: AUDIO KERNEL
// -------------------------------------------------------------------------
// ⛔️ DO NOT REMOVE `resumeContext` logic ⛔️
// -------------------------------------------------------------------------

type SoundType = 'WOOD' | 'STONE' | 'PAPER' | 'CHIME' | 'DRUM';

class AudioManager {
    private static instance: AudioManager;
    private ctx: AudioContext | null = null;
    private gainNode: GainNode | null = null;
    
    // BGM Node is now strictly an HTMLAudioElement
    public bgmNode: HTMLAudioElement | null = null;
    private isMuted: boolean = false;
    private isInitialized: boolean = false;
    
    private sfxCache: Map<string, AudioBuffer> = new Map();

    private constructor() {}

    public static getInstance(): AudioManager {
        if (!AudioManager.instance) {
            AudioManager.instance = new AudioManager();
        }
        return AudioManager.instance;
    }

    public async init() {
        if (this.isInitialized) return;

        try {
            const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
            if (AudioCtx) {
                this.ctx = new AudioCtx({ sampleRate: 44100 });
                this.gainNode = this.ctx.createGain();
                this.gainNode.gain.value = 0.3; 
                this.gainNode.connect(this.ctx.destination);
                this.setupAutoResume();
            }

            await this.preloadAllSFX();
            
            // [FIX] Simple BGM Initialization
            this.bgmNode = new Audio();
            this.bgmNode.loop = true;
            this.bgmNode.volume = AUDIO_CONFIG.bgmVolume;
            
            // Bind global error handler for the node
            this.attachErrorListener();

            // Pre-set source but do not play until interaction
            this.bgmNode.src = BGM_URL;
            
            this.isInitialized = true;
            console.log("[AudioManager] System Initialized (Global Zen)");
        } catch (e) {
            console.error("[AudioManager] Init Failed", e);
        }
    }

    private attachErrorListener() {
        if (!this.bgmNode) return;
        // Reset listener to avoid duplicates if called multiple times
        this.bgmNode.onerror = null; 
        this.bgmNode.onerror = (e) => {
            const src = this.bgmNode?.src;
            console.warn("[AudioManager] BGM Source Error:", src);
            if (src) {
                sysEvents.emit('AUDIO_ERROR', { url: src, error: e });
            }
        };
    }

    private setupAutoResume() {
        const resume = () => {
            if (this.ctx && this.ctx.state === 'suspended') {
                this.ctx.resume().catch(e => console.warn("Audio resume failed", e));
            }
            // Auto-start BGM on first interaction if not muted
            if (this.bgmNode && !this.isMuted && this.bgmNode.paused && this.bgmNode.src) {
                const playPromise = this.bgmNode.play();
                if (playPromise !== undefined) {
                    playPromise.catch(e => {
                        console.warn("Auto-play blocked", e);
                        // Do not emit error for auto-play block, it's normal behavior
                    });
                }
            }
        };
        document.addEventListener('click', resume, { once: true });
        document.addEventListener('touchstart', resume, { once: true });
        document.addEventListener('keydown', resume, { once: true });
    }

    private async ensureContextRunning() {
        if (!this.ctx) await this.init();
        if (this.ctx && this.ctx.state === 'suspended') {
            await this.ctx.resume();
        }
    }

    private async preloadAllSFX() {
        const entries = Object.entries(SFX_ASSETS) as [SoundType, string][];
        const promises = entries.map(([type, url]) => this.loadBuffer(url, type));
        await Promise.all(promises);
    }

    // --- SYNTHESIZER KERNEL (Procedural SFX) ---
    private createProceduralBuffer(type: string): AudioBuffer {
        if (!this.ctx) throw new Error("No Context");
        const sr = this.ctx.sampleRate;
        const createSoftNoise = (duration: number) => {
            const buffer = this.ctx!.createBuffer(1, sr * duration, sr);
            const data = buffer.getChannelData(0);
            let b0 = 0, b1 = 0, b2 = 0;
            for(let i=0; i<data.length; i++) {
                const white = Math.random() * 2 - 1;
                b0 = 0.99886 * b0 + white * 0.0555179;
                b1 = 0.99332 * b1 + white * 0.0750759;
                b2 = 0.96900 * b2 + white * 0.1538520;
                data[i] = (b0 + b1 + b2) * 0.15; 
            }
            return buffer;
        };

        let buffer: AudioBuffer;
        switch (type) {
            case 'pebble_stream': 
                buffer = this.ctx.createBuffer(1, sr * 0.6, sr);
                const dPebble = buffer.getChannelData(0);
                for(let i=0; i<dPebble.length; i++) {
                    const t = i / sr;
                    const freq = 600 - (t * 1200); 
                    let env = t < 0.01 ? t / 0.01 : Math.exp(-(t - 0.01) * 15);
                    dPebble[i] = Math.sin(2 * Math.PI * Math.max(100, freq) * t) * env * 0.5;
                }
                break;
            case 'leaf_rustle':
                buffer = createSoftNoise(0.8); 
                const dLeaf = buffer.getChannelData(0);
                for(let i=0; i<dLeaf.length; i++) {
                    const t = i / sr;
                    dLeaf[i] *= (0.5 - 0.5 * Math.cos(2 * Math.PI * (t / 0.8))) * 0.3; 
                }
                break;
            case 'bamboo_thock': 
                buffer = this.ctx.createBuffer(1, sr * 0.5, sr);
                const dBamboo = buffer.getChannelData(0);
                for(let i=0; i<dBamboo.length; i++) {
                    const t = i / sr;
                    const osc1 = Math.sin(2 * Math.PI * 180 * t) * Math.exp(-t * 12);
                    const osc2 = Math.sin(2 * Math.PI * 380 * t) * Math.exp(-t * 20) * 0.3;
                    let attack = t < 0.005 ? t / 0.005 : 1;
                    dBamboo[i] = (osc1 + osc2) * attack * 0.6;
                }
                break;
            case 'wind_chime': 
                buffer = this.ctx.createBuffer(1, sr * 5.0, sr); 
                const dChime = buffer.getChannelData(0);
                const freqs = [432, 648, 864]; 
                for(let i=0; i<dChime.length; i++) {
                    const t = i / sr;
                    let sample = 0;
                    freqs.forEach((f, idx) => { sample += Math.sin(2 * Math.PI * f * t) * Math.exp(-t * (0.8 + idx * 0.5)); });
                    dChime[i] = sample * 0.15 * (t < 0.1 ? t / 0.1 : 1);
                }
                break;
            case 'distant_thunder':
                buffer = createSoftNoise(3.0);
                const dThunder = buffer.getChannelData(0);
                let lp = 0;
                for(let i=0; i<dThunder.length; i++) {
                    const t = i / sr;
                    lp += (dThunder[i] - lp) * 0.008; 
                    let env = t < 0.5 ? t / 0.5 : Math.exp(-(t - 0.5) * 0.8);
                    dThunder[i] = lp * 8.0 * env;
                }
                break;
            default: buffer = createSoftNoise(0.1);
        }
        return buffer;
    }

    private async loadBuffer(url: string, key: string): Promise<AudioBuffer | null> {
        if (!this.ctx) return null;
        try {
            if (this.sfxCache.has(key)) return this.sfxCache.get(key)!;
            
            if (url.startsWith('synth://')) {
                const type = url.replace('synth://', '');
                const buffer = this.createProceduralBuffer(type); 
                this.sfxCache.set(key, buffer);
                return buffer;
            }

            const response = await fetch(url);
            const arrayBuffer = await response.arrayBuffer();
            const audioBuffer = await this.ctx.decodeAudioData(arrayBuffer);
            this.sfxCache.set(key, audioBuffer);
            return audioBuffer;
        } catch (e) {
            try {
                const buffer = this.createProceduralBuffer('bamboo_thock');
                this.sfxCache.set(key, buffer);
                return buffer;
            } catch(err) { return null; }
        }
    }

    // [FIX] Direct Playback for BGM - Bypassing complex fade logic for reliability
    public switchMusic(url: string) {
        if (!this.bgmNode) {
            this.bgmNode = new Audio(url);
            this.bgmNode.loop = true;
            this.attachErrorListener();
        } else {
            this.bgmNode.pause();
            this.bgmNode.src = url;
            this.attachErrorListener(); // Re-attach or ensure listener is there
            this.bgmNode.load(); // Force reload
        }

        if (!this.isMuted) {
            // Simple promise handling
            const playPromise = this.bgmNode.play();
            if (playPromise !== undefined) {
                playPromise
                    .then(() => {
                        if (this.bgmNode) this.bgmNode.volume = AUDIO_CONFIG.bgmVolume;
                    })
                    .catch(e => {
                        console.warn("[AudioManager] BGM Play Error:", e);
                        sysEvents.emit('AUDIO_ERROR', { url, error: e });
                    });
            }
        }
    }

    // [NEW] Explicit Pause/Resume logic for UI controls
    public pauseBGM() {
        if (this.bgmNode && !this.bgmNode.paused) {
            this.bgmNode.pause();
        }
    }

    public resumeBGM() {
        if (this.bgmNode && this.bgmNode.paused && this.bgmNode.src && !this.isMuted) {
            this.bgmNode.play().catch(console.warn);
        }
    }

    public playBGM() {
        if (this.bgmNode && !this.isMuted && this.bgmNode.src) {
            this.bgmNode.play().catch(e => console.warn("Play blocked", e));
            this.bgmNode.volume = AUDIO_CONFIG.bgmVolume;
        }
    }

    public setMute(muted: boolean) {
        this.isMuted = muted;
        if (!this.ctx) return;
        if (this.ctx.state === 'suspended' && !muted) this.ctx.resume();
        
        if (this.bgmNode) {
            if (muted) {
                this.bgmNode.pause();
            } else {
                if (this.bgmNode.paused && this.bgmNode.src) {
                    this.bgmNode.play().catch(() => {});
                    this.bgmNode.volume = AUDIO_CONFIG.bgmVolume;
                }
            }
        } 
    }

    public async playSFX(type: SoundType) {
        if (this.isMuted) return;
        await this.ensureContextRunning();
        if (!this.ctx || !this.gainNode) return;
        
        let buffer: AudioBuffer | null | undefined = this.sfxCache.get(type);
        if (!buffer) {
            const url = SFX_ASSETS[type];
            buffer = await this.loadBuffer(url, type);
        }
        
        if (buffer) {
            const source = this.ctx.createBufferSource();
            source.buffer = buffer;
            source.connect(this.gainNode);
            source.start(0);
        }
    }

    public async playPCM(data: Uint8Array | string) {
        if (this.isMuted) return;
        await this.ensureContextRunning();
        if (!this.ctx || !this.gainNode) return;
        
        // Gentle ducking
        if (this.bgmNode) this.bgmNode.volume = AUDIO_CONFIG.bgmVolume * 0.3; 

        if (typeof data === 'string') {
            const audio = new Audio(data);
            audio.onended = () => { if (this.bgmNode && !this.isMuted) this.bgmNode.volume = AUDIO_CONFIG.bgmVolume; };
            audio.play().catch(() => {});
        } else {
            try {
                const dataInt16 = new Int16Array(data.buffer);
                const buffer = this.ctx.createBuffer(1, dataInt16.length, 24000);
                const channelData = buffer.getChannelData(0);
                for (let i = 0; i < dataInt16.length; i++) channelData[i] = dataInt16[i] / 32768.0;
                
                const source = this.ctx.createBufferSource();
                source.buffer = buffer;
                source.connect(this.gainNode);
                source.onended = () => { 
                    if (this.bgmNode && !this.isMuted) {
                        this.bgmNode.volume = AUDIO_CONFIG.bgmVolume;
                    } 
                };
                source.start();
            } catch (e) {
                console.warn("[AudioManager] PCM Playback error", e);
            }
        }
    }
}

export const audioManager = AudioManager.getInstance();