
import { TutorialScenario, Suit } from '../types';
import { 
    ID_WAN_WAN, ID_QIAN_WAN, ID_BAI_WAN, ID_20_WAN, ID_90_WAN, 
    ID_1_GUAN, ID_9_GUAN, ID_1_SUO, ID_9_SUO, ID_1_WEN, ID_9_WEN,
    ID_6_GUAN, ID_8_GUAN, ID_5_GUAN, ID_KONG_WEN,
    ID_9_SUO as ID_9_SUO_TRUE, ID_1_SUO as ID_1_SUO_TRUE,
    ID_BAN_WEN
} from '../constants';

// --- CARD SETS ---
const CASH_SUIT = ['c_11', 'c_10', 'c_9', 'c_8', 'c_7', 'c_6', 'c_5', 'c_4', 'c_3', 'c_2', 'c_1'];
const GUAN_SUIT = ['s_9', 's_8', 's_7', 's_6', 's_5', 's_4', 's_3', 's_2', 's_1'];
const SUO_SUIT = ['k_9', 'k_8', 'k_7', 'k_6', 'k_5', 'k_4', 'k_3', 'k_2', 'k_1'];
const WEN_SUIT = ['t_11', 't_10', 't_9', 't_8', 't_7', 't_6', 't_5', 't_4', 't_3', 't_2', 't_1'];

// NEW SCENARIO 0: INTRO (认牌)
export const SCENARIO_INTRO_CARDS: TutorialScenario = {
    id: 'TUTORIAL_INTRO_CARDS',
    title: '第零章：认牌',
    description: '初入江湖，先识马吊四十张真容。学习花色与大小。',
    bankerId: 1, // Hideyoshi
    startingPlayerId: 1, // Banker starts
    
    // INITIAL VISUAL SETUP: 
    playerHandIds: CASH_SUIT,
    aiHandIds: {
        1: SUO_SUIT,
        2: WEN_SUIT,
        3: GUAN_SUIT
    },
    steps: [
        {
            id: 'step_0_full_view',
            message: "少侠，欢迎穿越回大明万历年间！一副马吊牌有【40张】，分【十、贯、索、文】四门。记住行规：各门派壁垒深严，井水不犯河水，打谁的门就得以此门应对。",
            waitForClick: true
        },
        {
            id: 'step_0_guan',
            message: "先看你手里的【贯子门】（万子）。这门派最老实，跟麻将万子一个德行：【以大欺小】。【九贯】是带头大哥，【一贯】是受气小弟。",
            setPlayerHand: GUAN_SUIT, 
            waitForClick: true
        },
        {
            id: 'step_0_suo',
            message: "这是【索子门】（条子）。规矩照旧：【数字大的说话】。【九索】顶天立地，【一索】只能垫底。",
            setPlayerHand: SUO_SUIT, 
            waitForClick: true
        },
        {
            id: 'step_0_wen',
            message: "注意！这是【文钱门】（饼子），练的是【逆练神功】！这儿是【数字越小越豪横】！【空文】(0)是掌门，【半文】(0.5)是护法，九文(9)反而是端茶倒水的弟弟。",
            setPlayerHand: WEN_SUIT, 
            waitForClick: true
        },
        {
            id: 'step_0_cash',
            message: "最后是【十字门】，这可是皇亲国戚。万万、千万、百万是十字门最大的牌，就像扑克里的J、Q、K，但平时总是闭关修炼，难见真身，而且互相看不惯！除此之外，数字也是【大者赢】，唯独【二十万】是个例外，虽然也是贵族（趣张），但身板最小。",
            setPlayerHand: CASH_SUIT, 
            waitForClick: true
        },
        {
            id: 'step_0_game_intro',
            message: "认全了人，咱们练练手。切记铁律：【同门厮杀，闲杂人等闪开】。系统已重新发牌，准备接招！",
            setPlayerHand: [ID_9_GUAN, ID_8_GUAN, ID_9_WEN, ID_WAN_WAN, ID_90_WAN, 'k_2', 'k_3', 'k_4'],
            setAiHands: {
                1: [ID_5_GUAN, 't_2', 'k_5', 'k_6', 'k_7', 'k_8', 's_1', 's_5'], 
                2: ['s_3', 't_3', 'k_3', 'c_4', 'c_5', 'c_6', 'c_7', 'c_8'],
                3: ['s_4', 't_4', 's_6', 's_7', 'c_2', 't_8', 'c_9', 't_5']
            },
            waitForClick: true
        },
        {
            id: 'step_0_r1_lead',
            message: "庄家（右边那货）先动了，甩出一张【五贯】。",
            aiMoves: [{ playerId: 1, cardId: ID_5_GUAN }]
        },
        {
            id: 'step_0_r1_others',
            message: "其他两家牌力不行，纷纷垫牌认怂...",
            aiMoves: [{ playerId: 2, cardId: 's_3' }, { playerId: 3, cardId: 's_4' }]
        },
        {
            id: 'step_0_r1_player',
            message: "轮到你了。手里攥着【九贯】，9比5大，这不欺负人吗？赶紧打出去，【捉】他个落花流水！",
            forcedCardId: ID_9_GUAN,
            highlightCardIds: [ID_9_GUAN]
        },
        {
            id: 'step_0_r1_win',
            message: "干得漂亮！九贯横扫全场，这墩牌归你了，行话叫【得桌】。赢家就是老大，下一轮由你发牌。",
            waitForClick: true
        },
        {
            id: 'step_0_r1_shang_zhuo',
            message: "瞧见没？赢的牌会留在桌面上显摆，这叫【上桌】。只有每回合最大的那张牌才有资格留在台面上，输家的牌都进废牌堆了。",
            highlightCardIds: [ID_9_GUAN],
            waitForClick: true
        },
        {
            id: 'step_0_r2_explain',
            message: "再复习一遍【文钱门】的邪门规矩：【小牌吃大牌】，饼子越少的越凶。教你一个通用小技巧（看左上角数字，数字越大的越凶）。",
            waitForClick: true
        },
        {
            id: 'step_0_r2_lead',
            message: "试试这张【九文】。虽然它是9，但在文钱门里它是弟中弟。打出去看看谁理你。",
            forcedCardId: ID_9_WEN,
            highlightCardIds: [ID_9_WEN]
        },
        {
            id: 'step_0_r2_others',
            message: "庄家出了【八文】。文钱门里8比9凶，所以庄家把你捉了！幸亏盟友给力，没让庄家得逞。",
            aiMoves: [{ playerId: 1, cardId: 't_2' }, { playerId: 2, cardId: 't_3' }, { playerId: 3, cardId: 't_4' }],
            waitForClick: false
        },
        {
            id: 'step_0_r2_loss',
            message: "这墩被盟友赢回去了。记住：【文钱门，数值小的才是爷】。",
            waitForClick: true
        },
        {
            id: 'step_0_r3_lead',
            message: "又一轮：庄家祭出了【五索】。",
            aiMoves: [{ playerId: 1, cardId: 'k_5' }]
        },
        {
            id: 'step_0_r3_others',
            message: "队友们表示管不起，继续灭牌...",
            aiMoves: [{ playerId: 2, cardId: 'k_3' }, { playerId: 3, cardId: 's_6' }]
        },
        {
            id: 'step_0_r3_player',
            message: "坏了，你手里没比五索大的索子！规矩是：【打不过就得垫牌】，而且优先垫【十字门青张】（黑牌）。这【九十】虽然不小，但花色不对就是废纸，含泪垫了吧。",
            forcedCardId: ID_90_WAN,
            highlightCardIds: [ID_90_WAN]
        },
        {
            id: 'step_0_r3_result',
            message: "这就是马吊的残酷：不是同门，大牌也枉然。尤其是十字门的黑牌，天生的炮灰命。恭喜少侠，认牌课程通关！",
            waitForClick: true
        }
    ]
};

// SCENARIO 1: THE BASICS (Keep unchanged)
export const SCENARIO_BASICS: TutorialScenario = {
    id: 'TUTORIAL_BASICS',
    title: '第一章：断庄',
    description: '学习如何利用规则截断庄家的攻势。',
    bankerId: 1,
    playerHandIds: [ID_9_GUAN, ID_8_GUAN, 's_1', 'c_2', 'c_3', 'k_1', 'k_2', 't_1'],
    aiHandIds: {
        1: [ID_6_GUAN, 's_7', 'c_10', 'c_11', 'k_9', 'k_8', 't_9', 't_10'], 
        2: ['s_2', 'c_6', 'c_5', 'k_7', 'k_6', 't_8', 't_7', 't_6'],
        3: ['s_3', 'c_4', 'c_9', 'k_5', 'k_4', 't_5', 't_4', 't_3']
    },
    steps: [
        { id: 'step_intro', message: "公元1592年，战火纷飞。你身处孤岛，牌桌即战场。上家是万历皇帝，左边是李舜臣，右边那个嚣张的庄家就是【丰臣秀吉】。你的任务很简单：和盟友【联手坑庄】。", waitForClick: true },
        { id: 'step_goal', message: "闲家切记：光自己赢够两墩（正本）是不够的！必须【死命顶住庄家】，宁可自己不赢，也不能让庄家赢，懂吗？", waitForClick: true },
        { id: 'step_suit_rule', message: "看手牌【贯子门】，大者为王。你手握【九贯】和【八贯】，这可是两把大砍刀，专治各种不服。", highlightCardIds: [ID_9_GUAN, ID_8_GUAN], waitForClick: true },
        { id: 'step_trick_1_start', message: "庄家出【六贯】探路，意图试探虚实。", aiMoves: [{ playerId: 1, cardId: ID_6_GUAN }] },
        { id: 'step_trick_1_follow_2', message: "万历爷牌小，【灭牌】认怂，不做无谓牺牲。", aiMoves: [{ playerId: 2, cardId: 's_2' }] },
        { id: 'step_trick_1_follow_3', message: "李将军也管不起，顺势【灭牌】。", aiMoves: [{ playerId: 3, cardId: 's_3' }] },
        { id: 'step_trick_1_action', message: "全村的希望都在你身上！请出【九贯】（9 > 6），给我狠狠地【捉】住他！", forcedCardId: ID_9_GUAN, highlightCardIds: [ID_9_GUAN] },
        { id: 'step_trick_1_win', message: "漂亮！这叫【捉牌】。只要压死庄家，就是为国争光。", waitForClick: true },
        { id: 'step_trick_2_lead', message: "趁热打铁！打出这张【八贯】，继续施压。", forcedCardId: ID_8_GUAN, highlightCardIds: [ID_8_GUAN] },
        { id: 'step_trick_2_ai_1', message: "丰臣秀吉手里只剩【七贯】，不敌你的八贯，只能含恨【灭牌】。", aiMoves: [{ playerId: 1, cardId: 's_7' }] },
        { id: 'step_trick_2_ai_2', message: "万历爷【垫牌】（灭牌）。", aiMoves: [{ playerId: 2, cardId: 'c_6' }] },
        { id: 'step_trick_2_ai_3', message: "李将军也【垫牌】，大家都是盟友，不会拆你的台。", aiMoves: [{ playerId: 3, cardId: 'c_9' }] },
        { id: 'step_trick_2_end', message: "连下两城！你已凑够两墩，算【正本】了（得0吊，算是及格了）。记住口诀：【大牌压死人，两墩才算人】。", waitForClick: true }
    ]
};

// SCENARIO 2: FORCING THE BANKER (Keep unchanged)
export const SCENARIO_FORCING_BANKER: TutorialScenario = {
    id: 'TUTORIAL_BI_ZHUANG',
    title: '第二章：逼庄',
    description: '身为庄家的上家，你掌握着庄家的命门。要学会用大牌封锁庄家。',
    bankerId: 1,
    startingPlayerId: 2, 
    playerHandIds: [ID_9_SUO_TRUE, 'k_2', 'k_1', 'c_2', 'c_3', 's_1', 's_2', 't_1'],
    aiHandIds: {
        1: ['k_6', 'k_8', 'c_10', 'c_11', 's_9', 's_8', 't_9', 't_10'],
        2: ['k_3', 'c_6', 'c_5', 's_7', 's_6', 't_8', 't_7', 't_6'],
        3: ['k_5', 'c_4', 'c_9', 's_3', 's_4', 't_5', 't_4', 't_3']
    },
    steps: [
        { id: 'step_2_intro', message: "第二课：【逼庄】（顶庄）。你坐在庄家上家，这位置最关键，相当于守门员。你出什么，庄家紧跟着就打什么，所以你得卡死他。", waitForClick: true },
        { id: 'step_2_trick_start', message: "万历爷发了张【三索】喂牌。", aiMoves: [{ playerId: 2, cardId: 'k_3' }] },
        { id: 'step_2_follow', message: "李将军用最大牌【逼庄】，打出了【五索】。目前李将军最大。", aiMoves: [{ playerId: 3, cardId: 'k_5' }] },
        { id: 'step_2_analysis', message: "关键时刻！庄家还没出牌。如果你出小了，庄家随便扔张【六索】就通吃全场。绝不能让他得逞！", highlightCardIds: [ID_9_SUO_TRUE, 'k_2', 'k_1'], waitForClick: true },
        { id: 'step_2_action', message: "必须【顶死他】！打出你最大的【九索】，封死庄家的路。这就叫【逼庄】，逼得庄家有牌也赢不了，只能干瞪眼。", forcedCardId: ID_9_SUO_TRUE, highlightCardIds: [ID_9_SUO_TRUE] },
        { id: 'step_2_banker_fail', message: "庄家手里虽然有【六索、八索】，但碰上你的九索泰山压顶，只能含泪【垫】出八索。", aiMoves: [{ playerId: 1, cardId: 'k_8' }] },
        { id: 'step_2_win', message: "漂亮！你赢下了这一墩。若刚才贪心留大牌，庄家就赢了。这叫【该顶不顶，全家受苦】。", waitForClick: true }
    ]
};

// SCENARIO 3: MELTING (Keep unchanged)
export const SCENARIO_MELTING: TutorialScenario = {
    id: 'TUTORIAL_MELTING',
    title: '第三章：垫牌',
    description: '当盟友已赢时，不可自相残杀。学会巧妙垫牌（灭牌），为后续继续能量。',
    bankerId: 1, 
    startingPlayerId: 1,
    preconfiguredState: { openedSuits: [{ suit: Suit.TEXTS, leaderId: 1, isBanker: true }] },
    playerHandIds: ['c_4', 't_2', 'k_9', 'k_8', 'k_7', 'k_6', 't_5', 't_6'],
    aiHandIds: {
        1: [ID_6_GUAN, 'c_6', 'c_10', 'c_11', 's_9', 's_8', 't_9', 't_10'],
        2: [ID_9_GUAN, 'c_5', 'c_1', 'k_5', 'k_4', 't_8', 't_7', 't_11'],
        3: ['s_3', 'c_2', 'c_7', 'k_3', 'k_2', 't_4', 't_1', 't_3']
    },
    steps: [
        { id: 'step_3_intro', message: "第三课：【垫牌】（灭牌）。盟友赢牌时，别傻乎乎地去捉他（除非抢分）。这时候要学会扔垃圾。扔垃圾口诀：【先扔十字门黑牌】 > 【扔禁门/生门的黑牌】 > 【扔熟门的黑牌】。", waitForClick: true },
        { id: 'step_3_r1_lead', message: "第一轮：庄家打出了【六贯】。", aiMoves: [{ playerId: 1, cardId: ID_6_GUAN }] },
        { id: 'step_3_r1_win_anim', message: "万历皇帝和李将军出牌...", aiMoves: [{ playerId: 2, cardId: ID_9_GUAN }, { playerId: 3, cardId: 's_3' }], waitForClick: false },
        { id: 'step_3_r1_win', message: "万历爷霸气，直接【九贯】镇场！庄家歇菜。", waitForClick: true },
        { id: 'step_3_r1_analysis', message: "轮到你了。盟友赢定了，你只需垫牌。根据【防百老戒色】心法，【十字门青张】（黑牌）是资敌的祸根，留着容易被百老利用，必须优先销毁。", highlightCardIds: ['c_4', 't_2'], waitForClick: true },
        { id: 'step_3_r1_rule', message: "虽然只有一张十字门【五十万】，但留着它祸害无穷，赶紧【垫掉】！", highlightCardIds: ['c_4'], forcedCardId: 'c_4' },
        { id: 'step_3_r1_play', message: "明智之举！这叫断了敌人的念想。", waitForClick: true },
        { id: 'step_3_r2_start', message: "第二轮：万历爷可能喝高了，竟打出十字门【六十万】！这可是给百老送桥啊。", aiMoves: [{ playerId: 2, cardId: 'c_5' }] },
        { id: 'step_3_r2_follow_anim', message: "李将军试图补救...", aiMoves: [{ playerId: 3, cardId: 'c_7' }], waitForClick: false },
        { id: 'step_3_r2_follow', message: "李将军见势不妙，赶紧打出【八十万】补救！试图稳住局面。", waitForClick: true },
        { id: 'step_3_r2_you', message: "你没十字门烂牌了，那就挑张【禁门】（还没人出过的花色）里的废物【八文】垫了吧！点击出牌！", forcedCardId: 't_2', highlightCardIds: ['t_2'] },
        { id: 'step_3_end', message: "学会了吧？垫牌心法：【友军赢牌我退让，十字黑牌先灭光。禁门是祸不是福，灭清舍趣保红张！】", waitForClick: true }
    ]
};

// SCENARIO 4: DIAO & SETTLEMENT (FIXED)
export const SCENARIO_SETTLEMENT: TutorialScenario = {
    id: 'TUTORIAL_SETTLEMENT',
    title: '第四章：吊数与结算',
    description: '打完一局，详解“赤脚”、“正本”与结算。',
    bankerId: 1, // Toyotomi (Right)
    startingPlayerId: 1, // Banker leads
    playerHandIds: ['c_3', 'c_2', 't_2', 't_3', ID_9_GUAN, ID_8_GUAN, 's_6', 's_5'],
    aiHandIds: {
        // [FIXED] Banker Hand: Removed c_9 (Million), replaced with c_5 (60 Wan) to avoid confusion.
        // Removed potential conflict cards.
        1: ['k_8', 'k_6', ID_90_WAN, 'c_5', 't_6', 't_9', 'k_2', 's_7'], 
        // Wanli
        2: ['k_7', 'k_5', 'c_8', 'c_1', 't_7', 't_5', 's_3', 's_2'],  
        // Yi (West):
        // [FIXED] Ensured no k_1 (1 Suo). s_1 (1 Guan) is kept for R5 melt.
        3: ['k_9', 'k_4', 'c_6', 'c_7', 't_8', ID_BAN_WEN, 's_4', 's_1']   
    },
    steps: [
        {
            id: 'step_4_intro',
            message: "第四课：算账。打完一局得算分。目标：【赢两墩】叫正本（得0吊）。赢不到两墩叫【赤脚】（-1吊），赢超过两墩叫【得吊】（+1吊）。分数是根据吊数差来算的，比如庄家赤脚(-1)，你正本(0)，你就赢他1分。",
            waitForClick: true
        },
        // R1
        { id: 'step_4_r1_start', message: "第一轮：庄家出【八索】立威，索子门成了【禁门】。", aiMoves: [{ playerId: 1, cardId: 'k_8' }] },
        { id: 'step_4_r1_follow_anim', message: "万历爷和李将军纷纷出牌...", aiMoves: [{ playerId: 2, cardId: 'k_7' }, { playerId: 3, cardId: 'k_9' }], waitForClick: false },
        { id: 'step_4_r1_follow', message: "万历爷【灭牌】，李将军够狠，【九索】反杀！李将军拿下一墩。", waitForClick: true },
        { id: 'step_4_r1_action', message: "轮到你，别管有没有索子，优先把那个累赘【十字门三十万】垫了！", forcedCardId: 'c_2', highlightCardIds: ['c_2'] },
        // R2
        { id: 'step_4_r2_start', message: "第二轮：李将军乘胜追击出【二文】（在文钱门算大牌）。", aiMoves: [{ playerId: 3, cardId: 't_8' }] },
        { id: 'step_4_r2_action', message: "你有【四十万】，又是十字门黑牌，别犹豫，【灭掉】它！", forcedCardId: 'c_3', highlightCardIds: ['c_3'] },
        { id: 'step_4_r2_follow_anim', message: "其他人出牌...", aiMoves: [{ playerId: 1, cardId: 't_6' }, { playerId: 2, cardId: 't_7' }], waitForClick: false },
        { id: 'step_4_r2_follow', message: "庄家管不上，李将军连赢两墩，已经【正本】了。", waitForClick: true },
        // R3
        { id: 'step_4_r3_start', message: "第三轮：李将军出【七十万】。", aiMoves: [{ playerId: 3, cardId: 'c_6' }], waitForClick: true },
        { id: 'step_4_r3_action', message: "你没禁门废牌了，既然赢不了，就选张最小的【八筒】扔了吧。", forcedCardId: 't_2', highlightCardIds: ['t_2'] },
        { id: 'step_4_r3_follow_anim', message: "庄家出手了...", aiMoves: [{ playerId: 1, cardId: ID_90_WAN }, { playerId: 2, cardId: 'c_8' }], waitForClick: false },
        { id: 'step_4_r3_follow', message: "庄家反扑，【九十万】压死七十万！这墩归庄家。", waitForClick: true },
        // R4
        { id: 'step_4_r4_start', message: "第四轮：庄家出【七贯】。", aiMoves: [{ playerId: 1, cardId: 's_7' }] },
        { id: 'step_4_r4_follow_anim', message: "闲家出牌...", aiMoves: [{ playerId: 2, cardId: 's_3' }, { playerId: 3, cardId: 's_4' }], waitForClick: false },
        { id: 'step_4_r4_follow', message: "万历爷【灭牌】，李将军【灭牌】。", waitForClick: true },
        { id: 'step_4_r4_action', message: "机会来了！手握【九贯】（赏），这是贯子门的老大。别客气，打出去【捉】住他！", forcedCardId: ID_9_GUAN, highlightCardIds: [ID_9_GUAN] },
        { id: 'step_4_r4_win', message: "漂亮！你赢得了第一墩（1桌）。离【正本】还差1墩。", waitForClick: true },
        // R5
        { id: 'step_4_r5_action', message: "第五轮：继续发飙，打出【八贯】（肩）。", forcedCardId: ID_8_GUAN, highlightCardIds: [ID_8_GUAN] },
        { id: 'step_4_r5_follow_anim', message: "众人垫牌...", aiMoves: [{ playerId: 1, cardId: 'k_6' }, { playerId: 2, cardId: 's_2' }, { playerId: 3, cardId: 's_1' }], waitForClick: false },
        { id: 'step_4_r5_follow', message: "庄家没贯子了，只能垫牌。你的八贯称王！", waitForClick: true },
        { id: 'step_4_r5_win', message: "双喜临门！这墩拿下，你也凑够两桌（正本）了。后面再赢就是赚【吊】了！", waitForClick: true },
        // R6
        { id: 'step_4_r6_action', message: "第六轮：出【六贯】。庄家大牌耗尽，只能干瞪眼。", forcedCardId: 's_6' },
        { id: 'step_4_r6_follow_anim', message: "对手庄家垫牌...", aiMoves: [{ playerId: 1, cardId: 'k_2' }, { playerId: 2, cardId: 't_5' }, { playerId: 3, cardId: 'k_4' }], waitForClick: false },
        { id: 'step_4_r6_follow', message: "其他人【垫牌】。", waitForClick: true },
        // R7
        { id: 'step_4_r7_action', message: "第七轮：出【五贯】，继续收割。", forcedCardId: 's_5' },
        { id: 'step_4_r7_follow_anim', message: "庄家手中无贯子，垫出【六十万】。", aiMoves: [{ playerId: 1, cardId: 'c_5' }, { playerId: 2, cardId: 'c_1' }, { playerId: 3, cardId: 'c_7' }], waitForClick: false },
        { id: 'step_4_r7_follow', message: "其他人也垫牌。这墩还是你的。", waitForClick: true },
        // R8
        { id: 'step_4_r8_action', message: "最后一轮，剩张【七文】，听天由命吧。", forcedCardId: 't_3' },
        { id: 'step_4_r8_follow_anim', message: "本局结束...", aiMoves: [{ playerId: 1, cardId: 't_9' }, { playerId: 2, cardId: 'k_5' }, { playerId: 3, cardId: ID_BAN_WEN }], waitForClick: false },
        { id: 'step_4_r8_follow', message: "本局结束。现在进入【自动比张】环节...", waitForClick: true },
        { id: 'step_4_kai_chong', message: "系统正在自动比张和开冲... 请耐心等待...", waitForClick: false },
        // [FIX] Highlight the Score Modal Pills
        {
            id: 'step_4_settlement_wait',
            message: "请看【结算单】（透过遮罩看下面）。你赢了4墩，【吊数】(+1)，美滋滋。庄家只赢1墩，惨遭【赤脚】(-1)。一来一回，你净赚2分。这就是马吊的快乐！",
            waitForClick: true
        }
    ]
};

// SCENARIO 5: ADVANCED CARDS (Keep unchanged)
export const SCENARIO_ADVANCED_CARDS: TutorialScenario = {
    id: 'TUTORIAL_ADVANCED_CARDS',
    title: '第五章：识器 (进阶)',
    description: '深入了解红张、趣张、百万的特殊计分规则以及色样概念。',
    bankerId: 1, 
    startingPlayerId: 1, 
    // 8 Cards in Hand: 4 Shang + 3 Jian + 1 Jian(Ban Wen) = 8
    playerHandIds: [ID_WAN_WAN, ID_QIAN_WAN, ID_9_GUAN, ID_9_SUO, ID_KONG_WEN, ID_8_GUAN, 'k_8', ID_BAN_WEN],
    // 5 Cards Pre-Won: Bai Wan, 20 Wan, 1 Guan, 1 Suo, 9 Wen assigned to West Player (Id 3)
    initialCapturedCards: [
        {
            playerId: 3,
            cardIds: [ID_BAI_WAN, ID_20_WAN, ID_1_GUAN, ID_1_SUO, ID_9_WEN]
        }
    ],
    aiHandIds: {
        1: [ID_90_WAN, 'c_7', 'c_5', 't_7', 't_6', 's_5', 's_6', 's_1'], // Filler
        2: ['c_6', 'c_4', 'k_7', 'k_6', 't_8', 't_5', 's_4', 's_3'], // Filler
        3: ['c_3', 'c_2', 'k_5', 'k_4', 't_4', 't_3', 's_2', 't_2']  // Filler
    },
    steps: [
        { 
            id: 'step_5_shang', 
            message: "第五课：识器（看牌）。全副马吊核心只有13张【锦张】。首先请看你手里的【四赏】（红牌至尊）：万万、九贯、九索、空文。",
            highlightCardIds: [ID_WAN_WAN, ID_9_GUAN, ID_9_SUO, ID_KONG_WEN], 
            waitForClick: true 
        },
        { 
            id: 'step_5_jian', 
            message: "其次是手里的【四肩】（仅次于赏）：千万、八贯、八索、半文。",
            highlightCardIds: [ID_QIAN_WAN, ID_8_GUAN, 'k_8', ID_BAN_WEN], 
            waitForClick: true 
        },
        { 
            id: 'step_5_ji', 
            message: "再看左边西家（李舜臣）得牌区，那里摆着【四极】（趣）：二十万、一贯、一索、九文。",
            highlightCardIds: [ID_20_WAN, ID_1_GUAN, ID_1_SUO, ID_9_WEN], 
            waitForClick: true 
        },
        { 
            id: 'step_5_bai', 
            message: "最后是这张【百万】，它是百老身份的象征，统领全局。",
            highlightCardIds: [ID_BAI_WAN], 
            waitForClick: true 
        },
        { 
            id: 'step_5_reset',
            message: "认清这13张宝贝了吗？现在我们要正式开打了。系统将重新发牌，还原到实战残局。",
            clearCapturedCards: true,
            setPlayerHand: [ID_WAN_WAN, ID_QIAN_WAN, ID_BAI_WAN, ID_9_GUAN, ID_20_WAN, ID_1_GUAN, ID_8_GUAN, 's_7'],
            setAiHands: {
                1: [ID_90_WAN, 'c_7', 'k_9', 'k_8', 't_11', 't_10', 's_5', 's_6'],
                2: ['c_5', 'c_6', 'k_7', 'k_6', 't_9', 't_8', 's_4', 's_3'],
                3: ['c_3', 'c_4', 'k_5', 'k_4', 't_7', 't_6', 's_2', 't_1']
            },
            waitForClick: true 
        },
        { id: 'step_5_red_cards', message: "看你手里的【红张】：万万、千万、百万、九贯。拿着它们不仅能赢，还能凑【色样】（特殊加分）。", highlightCardIds: [ID_WAN_WAN, ID_QIAN_WAN, ID_BAI_WAN, ID_9_GUAN], waitForClick: true },
        { id: 'step_5_green_cards', message: "再看【趣张】（绿牌）：二十万、一贯。别看它们小，上桌就有分！但二十万是把神经刀，被捉了不仅没分，还得丢出牌权。", highlightCardIds: [ID_20_WAN, ID_1_GUAN], waitForClick: true },
        { id: 'step_5_bai_wan_rule', message: "最骚的是这张【百万】。起手有它就是【百老】，拿在手里就算1分（吊百）。但它是把双刃剑...", highlightCardIds: [ID_BAI_WAN], waitForClick: true },
        { id: 'step_5_bai_wan_risk', message: "如果百万成功上桌且你正本了，那就是【大活百】（+3分）！但如果百万上桌你却没正本，那叫【佛赤脚】，得倒赔每家5分！刺激不？", waitForClick: true },
        { id: 'step_5_game_start', message: "让我们演练一把。目标：赢下两墩，并打出百万，达成【大活百】。庄家出牌了...", aiMoves: [{ playerId: 1, cardId: ID_90_WAN }] },
        { id: 'step_5_r1_others', message: "其他人跟牌...", aiMoves: [{ playerId: 2, cardId: 'c_5' }, { playerId: 3, cardId: 'c_3' }] },
        { id: 'step_5_r1_player', message: "庄家出了九十万。你直接甩出【万万】至尊，谁敢拦我？第一墩到手。", forcedCardId: ID_WAN_WAN, highlightCardIds: [ID_WAN_WAN] },
        { id: 'step_5_r1_win', message: "漂亮！万万是至尊，没人能挡。现在你赢了1墩。还需要1墩才能正本。", waitForClick: true },
        { id: 'step_5_r2_lead', message: "现在轮到你出牌。二十万太浪容易翻车，你有【百万】且已有一墩垫底，不如趁热打铁打出百万！只要这把赢了，【正本】+【大活百】通吃！", forcedCardId: ID_BAI_WAN, highlightCardIds: [ID_BAI_WAN] },
        { id: 'step_5_r2_others', message: "庄家只有八十万，含泪跟牌...", aiMoves: [{ playerId: 1, cardId: 'c_7' }, { playerId: 2, cardId: 'c_6' }, { playerId: 3, cardId: 'c_4' }], waitForClick: false },
        { id: 'step_5_r2_win', message: "百万赢了！恭喜！百万上桌且正本，喜提【大活百】（+3分）。", waitForClick: true },
        { id: 'step_5_conclusion', message: "记住：【稳拿大活百，胜过险求二十万】。课程结束，去江湖闯荡吧！", waitForClick: true }
    ]
};

export const TUTORIAL_LEVELS = [SCENARIO_INTRO_CARDS, SCENARIO_BASICS, SCENARIO_FORCING_BANKER, SCENARIO_MELTING, SCENARIO_SETTLEMENT, SCENARIO_ADVANCED_CARDS];
