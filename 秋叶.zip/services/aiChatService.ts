import { SupportedLanguage, AILearningState } from '../types';

export type ChatContext = 
    | 'GAME_START' 
    | 'TRICK_WIN' 
    | 'TRICK_WIN_BIG'
    | 'TRICK_LOSS' 
    | 'PENALTY' 
    | 'ROUND_WIN' 
    | 'ROUND_LOSS' 
    | 'KAI_CHONG_SUCCESS'
    | 'KAI_CHONG_FAIL'
    | 'PLAY_HIGH_CARD'
    | 'WAITING'
    | 'TEACH_VIOLATION'
    | 'LECTURE_DIAO'
    | 'LECTURE_SE_YANG'
    | 'LECTURE_CHONG'
    | 'TACTICAL_ADVICE'
    | 'PHASE_CHANGE_BI_ZHANG'
    | 'PHASE_CHANGE_KAI_CHONG'
    | 'LEAD_ADVICE';

const MESSAGES: Record<SupportedLanguage, Record<ChatContext, string[]>> = {
    zh_CN: {
        GAME_START: [
            "夫马吊者，兵法也。四十张牌，变化无穷，诸君慎之。",
            "局以变生，制由机发。请诸位落座，共演此纵横之术。",
            "此案墨玉微凉，正如兵道之冷峻。请。"
        ],
        TRICK_WIN: [
            "笑纳了。正所谓：取之有道。",
            "兵贵神速，此牌出得正是时候。",
            "承让，此乃运筹之妙。"
        ],
        TRICK_WIN_BIG: [
            "一夫当关，万夫莫开！",
            "至尊在此，谁敢造次？",
            "痛快！此局气势如虹，势不可挡！"
        ],
        TRICK_LOSS: [
            "大意了，竟被汝钻了空子。",
            "此乃诱敌深入之计，汝莫要高兴太早。",
            "胜败兵家常事，暂且让你一回。"
        ],
        PENALTY: [
            "哎呀！老夫竟犯了如此低级之错，愧对先贤！",
            "这...这是‘包赔’？吾一世英名，毁于一旦！",
            "一时眼花，罪过罪过。"
        ],
        ROUND_WIN: [
            "运筹帷幄之中，决胜千里之外。",
            "今日手气，颇有当年冯梦龙之风。",
            "吾之牌技，虽不及古人，亦足以在此桌称雄矣。"
        ],
        ROUND_LOSS: [
            "时运不济，命途多舛...",
            "卷土重来未可知，下局定要翻盘。",
            "这一局输得蹊跷，待老夫复盘一番。"
        ],
        KAI_CHONG_SUCCESS: [
            "天作之合！此乃天意！",
            "妙哉！这底牌正如吾意。",
            "神来之笔，冲得漂亮！"
        ],
        KAI_CHONG_FAIL: [
            "缘分未到，强求不得。",
            "底牌无情，奈何奈何。",
            "时机未到，且看下回分解。"
        ],
        PLAY_HIGH_CARD: [
            "泰山压顶！谁能挡我？",
            "此牌一出，乾坤定矣。"
        ],
        WAITING: [
            "思考良久，莫非在推演天机？",
            "兵贵神速，犹豫则败北。",
            "莫让光阴虚度，速速出牌。"
        ],
        TEACH_VIOLATION: [
            "孺子不可教也！《牌经》有云：首发千万乃是大忌！你怎敢造次？",
            "荒唐！非‘百老’而首发十字门，你这是自寻死路！",
            "不懂规矩！趣张在手，岂可灭绝青牌？回去再读读规则吧！",
            "慎之！此举若在明廷，定要治你个‘纵庄’之罪！"
        ],
        LECTURE_DIAO: [
            "听好了，‘吊数’便是你每局的功德。没捞到两墩（正本），你就是那赤脚的苦行僧，得赔钱给人家！"
        ],
        LECTURE_SE_YANG: [
            "色样乃是马吊之魂！一旦有人亮出‘皇会图’或‘鲫鱼背’，全场皆要致贺。这可是大进账！"
        ],
        LECTURE_CHONG: [
            "开冲之时，最忌孤军深入。你的‘青张’必须靠‘锦张’撑腰，连成一片方能克敌制胜。"
        ],
        TACTICAL_ADVICE: [
            "此时应‘防庄’为上，莫要贪小利而失大局。",
            "看对方出牌路数，恐怕手里攥着大赏呢，小心为妙。",
            "此门已成‘熟门’，你手里的极张该动一动了。"
        ],
        PHASE_CHANGE_BI_ZHANG: [
            "八轮已毕，到了‘比张’见真章的时候。赤脚还是正本，在此一举！",
            "比张者，生死存亡之际也。且看谁能死里逃生。"
        ],
        PHASE_CHANGE_KAI_CHONG: [
            "得桌已定，且看这七张底牌能翻出什么浪花！进入‘开冲’环节。",
            "掘藏之妙，皆在这底牌之中。莫要眨眼！"
        ],
        LEAD_ADVICE: [
            "发牌要看门道。无赏不发十字，这是规矩。",
            "先试探生门，莫要急着出尊张。",
            "身为闲家，当合力围剿庄家，莫要内讧！"
        ]
    },
    zh_TW: { GAME_START: ["夫馬吊者，兵法也。"], TRICK_WIN: ["笑納了。"], TRICK_WIN_BIG: ["一夫當關！"], TRICK_LOSS: ["大意了。"], PENALTY: ["哎呀！"], ROUND_WIN: ["運籌帷幄。"], ROUND_LOSS: ["時運不濟。"], KAI_CHONG_SUCCESS: ["天作之合！"], KAI_CHONG_FAIL: ["緣分未到。"], PLAY_HIGH_CARD: ["泰山壓頂！"], WAITING: ["思考良久。"], TEACH_VIOLATION: ["孺子不可教也！"], LECTURE_DIAO: ["聽好了，‘吊數’便是你每局的功德。"], LECTURE_SE_YANG: ["色樣乃是馬吊之魂！"], LECTURE_CHONG: ["開衝之時，最忌孤軍深入。"], TACTICAL_ADVICE: ["此時應‘防庄’為上。"], PHASE_CHANGE_BI_ZHANG: ["八輪已畢。"], PHASE_CHANGE_KAI_CHONG: ["進入‘開衝’環節。"], LEAD_ADVICE: ["發牌要看門道。"] },
    en: { GAME_START: ["Ma Diao is strategy."], TRICK_WIN: ["Acquired."], TRICK_WIN_BIG: ["Dominance!"], TRICK_LOSS: ["A lapse."], PENALTY: ["Alas!"], ROUND_WIN: ["Victory."], ROUND_LOSS: ["Defeat."], KAI_CHONG_SUCCESS: ["Fate!"], KAI_CHONG_FAIL: ["Not yet."], PLAY_HIGH_CARD: ["Power!"], WAITING: ["Thinking?"], TEACH_VIOLATION: ["Foolish!"], LECTURE_DIAO: ["Listen, 'Diao' is your score foundation."], LECTURE_SE_YANG: ["'Se Yang' is the soul of Ma Diao!"], LECTURE_CHONG: ["During Breakout, don't go alone."], TACTICAL_ADVICE: ["Defend against the Banker now."], PHASE_CHANGE_BI_ZHANG: ["The final showdown begins."], PHASE_CHANGE_KAI_CHONG: ["Entering Breakout phase."], LEAD_ADVICE: ["Leading is an art."] },
    ja: { GAME_START: ["馬吊は兵法なり。"], TRICK_WIN: ["頂いた。"], TRICK_WIN_BIG: ["圧倒的！"], TRICK_LOSS: ["不覚。"], PENALTY: ["嗚呼！"], ROUND_WIN: ["勝利。"], ROUND_LOSS: ["敗北。"], KAI_CHONG_SUCCESS: ["天命！"], KAI_CHONG_FAIL: ["無念。"], PLAY_HIGH_CARD: ["乾坤一擲！"], WAITING: ["長考？"], TEACH_VIOLATION: ["愚か者め！"], LECTURE_DIAO: ["聞け、『吊数』こそが勝負の礎だ。"], LECTURE_SE_YANG: ["『色様』こそが馬吊の魂なり向。"], LECTURE_CHONG: ["開衝の際、孤立は禁物なり。"], TACTICAL_ADVICE: ["親を抑えるのが上策なり。"], PHASE_CHANGE_BI_ZHANG: ["最後の勝負が始まる。"], PHASE_CHANGE_KAI_CHONG: ["開衝に入る。"], LEAD_ADVICE: ["打ち出しに注意せよ。"] },
    ko: { GAME_START: ["마조는 병법이라."], TRICK_WIN: ["받겠소."], TRICK_WIN_BIG: ["일당백!"], TRICK_LOSS: ["방심했군."], PENALTY: ["오호통재라!"], ROUND_WIN: ["승리."], ROUND_LOSS: ["패배."], KAI_CHONG_SUCCESS: ["천운!"], KAI_CHONG_FAIL: ["아쉽구려."], PLAY_HIGH_CARD: ["태산!"], WAITING: ["장고?"], TEACH_VIOLATION: ["어리석구나!"], LECTURE_DIAO: ["잘 들어라, '조수'는 매 판의 공덕이다."], LECTURE_SE_YANG: ["'색양'은 마조의 혼이다!"], LECTURE_CHONG: ["개충 시에는 고립을 피해야 한다."], TACTICAL_ADVICE: ["장가를 견제하라."], PHASE_CHANGE_BI_ZHANG: ["마지막 승부가 시작된다."], PHASE_CHANGE_KAI_CHONG: ["개충 단계에 진입한다."], LEAD_ADVICE: ["패를 내는 것은 예술이다."] }
};

export const getAIChatMessage = (context: ChatContext, language: SupportedLanguage, personality?: AILearningState): string => {
    const langMessages = MESSAGES[language] || MESSAGES['en'];
    const options = langMessages[context] || [];
    if (options.length === 0) return "";
    const index = Math.floor(Math.random() * options.length);
    return options[index];
};