// ... existing imports ...
import React, { useMemo, useState, useEffect } from 'react';
import { useMaDiaoGame } from '../../hooks/useMaDiaoLogic';
import { useGameSettings } from '../../hooks/useGameSettings';
import { useSkin } from '../../contexts/SkinContext';
import { useUIState } from '../../hooks/useUIState';
import { useAudioSystem } from '../../hooks/useAudioSystem';
import { useGameInteraction } from '../../hooks/useGameInteraction';
import { useAIAgent } from '../../hooks/useAIAgent';
import { getSuitStatusContext } from '../../services/riskEngine';
import { platformService } from '../../services/platformService';
import { Scene3D } from '../Visuals/Scene3D';
import { PlayerListHUD, HumanHandHUD } from '../UI/GameInterface';
import { HomeScreen } from '../UI/HomeScreen';
import { ScoreModal, SettingsModal } from '../UI/Modals';
import { SmartRecorderSetup, SmartRecorderOverlay } from '../UI/SmartRecorder';
import { useSmartRecorder } from '../../hooks/useSmartRecorder'; 
import { SocialLoginModal } from '../UI/SocialLoginModal';
import { SuitHistoryPanel } from '../UI/SuitHistoryPanel'; 
import { TutorialOverlay, GrandpaAvatar } from '../UI/TutorialOverlay'; 
import { WardrobeModal } from '../UI/WardrobeModal'; 
import { PersonalRoom } from '../Room/PersonalRoom'; 
import Chat from '../Chat';
import { AdminGate } from '../Admin/AdminGate';
import { GamePhase, PlayerType, UserProfile, RiskAssessment, Gender } from '../../types';
import { TRANSLATIONS } from '../../constants';
import { TUTORIAL_LEVELS } from '../../services/tutorialScenarios';
import { preloadStaticAudio, generateSpeech } from '../../services/geminiService'; 
import { HUANGHUALI_TEXTURE, ImperialWindow, StylizedButton } from '../UI/Shared'; 
import { upsertUserProfile, getUserProfile } from '../../services/cloudService';
import { sysEvents } from '../../services/eventBus'; // New Import
import { ZenMusicPlayer } from '../UI/ZenMusicPlayer'; // [NEW] Import

const MentorOverlay = ({ message }: { message: string | null }) => {
    if (!message) return null;
    return (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-[450] w-[90%] max-w-lg pointer-events-none animate-fade-in-up">
            <div className="bg-[#1a0f0a]/60 backdrop-blur-xl border border-white/10 p-5 rounded-3xl shadow-[0_30px_60px_rgba(0,0,0,0.5)] flex items-center gap-5 transition-all duration-1000">
                <div className="w-14 h-14 rounded-full border-2 border-[#c5a059]/40 overflow-hidden bg-black/40 shrink-0">
                    <img src="https://api.dicebear.com/9.x/avataaars/svg?seed=Felix&facialHair=majestic&facialHairColor=ffffff&top=shortFlat&hairColor=f1f1f1" className="w-full h-full object-cover grayscale-[0.2]" alt="Tutor" />
                </div>
                <div className="flex flex-col">
                    <span className="text-[#c5a059]/70 text-[9px] font-bold uppercase tracking-[0.3em] mb-1">导师叮嘱</span>
                    <p className="text-white/90 text-sm font-sans leading-relaxed tracking-wide drop-shadow-sm">{message}</p>
                </div>
            </div>
        </div>
    );
};

// [REDESIGNED] Embedded Wall Control (Inset Zitan)
const SystemOverlays = ({ ui, settings, onOpenWardrobe, onToggleChat, chatOpen }: any) => {
    
    // Unified Button Style - Inset, Minimal, Darker
    const ControlButton = ({ onClick, title, children, active, className = "" }: any) => (
        <button 
            onClick={onClick}
            className={`w-8 h-8 flex items-center justify-center rounded-[2px] transition-all duration-300 relative group overflow-hidden ${active ? 'bg-[#3d0e0e] shadow-[inset_0_0_8px_rgba(0,0,0,0.9)]' : 'hover:bg-[#1a0505]/50'} ${className}`}
            title={title}
        >
            <div className={`text-sm filter drop-shadow-lg transition-transform duration-300 group-hover:scale-110 group-active:scale-95 ${active ? 'text-[#ffd700] scale-110' : 'text-[#8c6239] group-hover:text-[#c5a059]'}`}>
                {children}
            </div>
        </button>
    );

    return (
        <div className="fixed top-4 left-4 z-[1100] flex flex-col gap-0 pointer-events-auto select-none scale-90 origin-top-left">
            {/* Embedded Zitan Block (Inset into wall) - [VISUAL UPDATE] Fixed width w-48 */}
            <div className="relative w-48 h-10 rounded-[2px] overflow-hidden flex items-center justify-between px-2 bg-[#0f0404] shadow-[inset_0_2px_5px_rgba(0,0,0,0.8),0_1px_0_rgba(255,255,255,0.05)] border-b border-white/5">
                
                {/* Internal Grain Texture */}
                <div className="absolute inset-0 opacity-20 pointer-events-none mix-blend-overlay" 
                     style={{ backgroundImage: HUANGHUALI_TEXTURE, backgroundSize: '100px 100px' }}></div>

                {/* --- CONTROLS --- */}
                
                <div className="flex items-center gap-1">
                    {/* A. Recorder */}
                    {!settings.isMobileDevice ? (
                        <ControlButton 
                            onClick={() => { ui.setActiveSettingsTab('RECORDER'); ui.setShowSettings(true); }}
                            title="智能录像"
                        >
                            ◉
                        </ControlButton>
                    ) : null}

                    {/* B. Tutor */}
                    <button 
                        onClick={() => onToggleChat(!chatOpen)}
                        className={`w-8 h-8 rounded-full border border-[#3e2b22] transition-all duration-500 relative overflow-hidden shadow-inner group shrink-0 mx-1 ${chatOpen ? 'border-[#c5a059] ring-1 ring-[#c5a059]/30 scale-105 z-10' : 'hover:border-[#8c6239] grayscale-[0.3] hover:grayscale-0'}`}
                        title="导师"
                    >
                        <div className="absolute inset-0 bg-[#1a0f0a]">
                            <GrandpaAvatar />
                        </div>
                        {!chatOpen && <div className="absolute top-0.5 right-0.5 w-1.5 h-1.5 bg-red-600 rounded-full border border-black animate-pulse shadow-[0_0_5px_red]"></div>}
                    </button>
                </div>

                <div className="flex items-center gap-1">
                    {/* C. Wardrobe */}
                    <ControlButton onClick={onOpenWardrobe} title="尚衣局 (换装)">
                        👘
                    </ControlButton>

                    {/* D. Settings */}
                    <ControlButton 
                        onClick={() => { ui.setActiveSettingsTab('GENERAL'); ui.setShowSettings(true); }} 
                        title="设置"
                    >
                        ⚙️
                    </ControlButton>
                </div>
            </div>
        </div>
    );
};

// ... RiskWarningModal logic (Refactored) ...
const RiskWarningModal = ({ risk, onConfirm, onCancel }: { risk: {cardId: string, assessment: RiskAssessment}, onConfirm: () => void, onCancel: () => void }) => {
    const isPenalty = risk.assessment.riskLevel === 'PENALTY';
    const title = isPenalty ? "违例警告 (VIOLATION)" : "战术风险 (WARNING)";
    const highlightColor = isPenalty ? "#ef4444" : "#eab308"; 

    return (
        <div className="fixed inset-0 z-[1500] flex items-center justify-center bg-black/50 backdrop-blur-sm animate-fade-in font-serif p-4">
            <ImperialWindow title={title} onClose={onCancel} width="w-full max-w-md" height="auto" className={isPenalty ? "border-red-900/50" : "border-[#c5a059]/50"}>
                <div className="p-8 flex flex-col items-center text-center relative overflow-hidden">
                    <div className={`absolute inset-0 opacity-10 animate-pulse ${isPenalty ? 'bg-red-900' : 'bg-yellow-900'}`}></div>
                    
                    <div className="relative z-10 flex flex-col items-center">
                        <div className="text-5xl mb-6 filter drop-shadow-[0_0_15px_rgba(0,0,0,0.8)]">
                            {isPenalty ? '🚫' : '⚠️'}
                        </div>
                        
                        <div className="w-full h-px bg-gradient-to-r from-transparent via-[#8c6239]/50 to-transparent mb-6"></div>
                        
                        <p className="text-[#e8e4d9] text-base leading-relaxed font-sans mb-4 drop-shadow-md">
                            {risk.assessment.message}
                        </p>
                        
                        {risk.assessment.tacticalContext && (
                            <div className="mb-8 px-4 py-1.5 bg-black/40 rounded-full border border-white/10 text-[10px] text-[#8c6239] uppercase tracking-widest shadow-inner">
                                Context: {risk.assessment.tacticalContext}
                            </div>
                        )}

                        <div className="flex gap-4 w-full">
                            <StylizedButton onClick={onCancel} className="flex-1 border-[#5c3a21] text-[#a0a0a0]">
                                重新思考
                            </StylizedButton>
                            <button 
                                onClick={onConfirm}
                                className={`flex-1 h-10 md:h-11 rounded-[2px] font-black tracking-[0.2em] text-sm transition-all shadow-lg hover:brightness-110 active:scale-[0.98] border border-transparent ${isPenalty ? 'bg-[#3d0e0e] text-red-400 border-red-900' : 'bg-[#2a1b15] text-yellow-400 border-yellow-900'}`}
                            >
                                坚持出牌
                            </button>
                        </div>
                    </div>
                </div>
            </ImperialWindow>
        </div>
    );
};

export const GameRoot: React.FC = () => {
    const [view, setView] = useState<'GAME' | 'ADMIN' | 'ROOM'>('GAME'); 
    const [userProfile, setUserProfile] = useState<UserProfile | undefined>();
    const [showWardrobe, setShowWardrobe] = useState(false); 
    const [chatOpen, setChatOpen] = useState(false); // [NEW] Lifted Chat State

    // --- DATA PERSISTENCE ---
    useEffect(() => {
        preloadStaticAudio();
        const loadProfile = async () => {
            const profile = await getUserProfile();
            if (profile) {
                console.log("Profile loaded:", profile.username);
                setUserProfile(profile);
            }
        };
        loadProfile();
    }, []);

    const settings = useGameSettings();
    const { skin, availableSkins, setSkinId } = useSkin();
    const ui = useUIState();
    const { playPcmAudio, playProceduralSFX, startBGM } = useAudioSystem(settings.isMuted);
    const recorder = useSmartRecorder();

    // 🏗️ INTEGRATE EVENT BUS LISTENER
    useEffect(() => {
        const unbindSound = sysEvents.on('PLAY_SOUND', (payload) => {
            playProceduralSFX(payload.type);
        });
        return () => { unbindSound(); };
    }, [playProceduralSFX]);

    const { state, actions } = useMaDiaoGame({
        difficulty: settings.difficulty,
        isRiskAlertOn: settings.isRiskAlertOn,
        language: settings.language,
        playSound: () => {}, // Deprecated prop, now handled via EventBus
        baseScore: settings.baseScore,
        ruleEngineVersion: settings.ruleEngineVersion 
    });

    useEffect(() => {
        if (state.phase === GamePhase.DEALING && recorder.isRecording) {
            recorder.stopRecording();
        }
    }, [state.phase, recorder.isRecording]);

    const humanPlayer = useMemo(() => state.players.find(p => p.type === PlayerType.HUMAN), [state.players]);
    const isTutorialActive = !!state.currentScenario;
    // [FIX] Strict null check: Ensure currentScenario exists before accessing steps
    const currentStep = isTutorialActive && !state.isTutorialComplete && state.currentScenario ? state.currentScenario.steps[state.tutorialStepIndex] : null;
    
    useEffect(() => {
        const playTutorialAudio = async () => {
            if (isTutorialActive && currentStep?.message && !settings.isMuted) {
                const audioData = await generateSpeech(currentStep.message, 'Zephyr');
                if (audioData) {
                    playPcmAudio(audioData);
                }
            }
        };
        playTutorialAudio();
    }, [state.tutorialStepIndex, isTutorialActive, settings.isMuted, currentStep?.message]);

    const { interactionState, handle3DActionClick } = useGameInteraction(state, actions, humanPlayer, settings);
    
    const tutorialHighlights = useMemo(() => {
        if (currentStep?.highlightCardIds) {
            return new Set(currentStep.highlightCardIds);
        }
        return interactionState.highlightedCardIds;
    }, [currentStep, interactionState.highlightedCardIds]);

    const { aiChatMessages, thinkingPlayers } = useAIAgent({ gameState: state, gameActions: actions, audioSystem: { playPcmAudio, playProceduralSFX }, isMuted: settings.isMuted, language: settings.language });

    const cardMarkers = useMemo(() => {
        const markers: Record<string, { isMature: boolean, isForbidden: boolean }> = {};
        if (!humanPlayer) return markers;
        humanPlayer.hand.forEach(card => {
            const status = getSuitStatusContext(humanPlayer, card, state.bankerId, state.openedSuits, state.recordedCards, state.firstLeadInfo, state.faceUpPlayedCardIds, state.bankerFirstLeadCard);
            markers[card.id] = { isMature: status === 'SAFE', isForbidden: status === 'FORBIDDEN' };
        });
        return markers;
    }, [humanPlayer, state]);

    const handleTutorialNext = () => {
        if (!state.currentScenario) return;
        const currentIdx = TUTORIAL_LEVELS.findIndex(s => s.id === state.currentScenario?.id);
        const nextScenario = TUTORIAL_LEVELS[currentIdx + 1];
        if (nextScenario) {
            actions.startTutorial(userProfile, nextScenario);
        } else {
            actions.exitToTitle();
        }
    };

    const handleStartGame = async (recordMode: boolean) => {
        if (recordMode) {
            recorder.updateConfig({ timeLimit: 30 });
            const streamReady = await recorder.prepareStream();
            if (streamReady) {
                recorder.startRecording();
                settings.setIsMuted(false); 
            }
        }
        startBGM(); 
        actions.startGame(userProfile);
    };

    const handleStartTutorial = async (scenario: any, recordMode: boolean) => {
        if (recordMode) {
            recorder.updateConfig({ timeLimit: 0 }); 
            const streamReady = await recorder.prepareStream();
            if (streamReady) {
                recorder.startRecording();
            }
        }
        settings.setIsMuted(false); 
        startBGM();
        actions.startTutorial(userProfile, scenario);
    };

    const t = (key: string) => TRANSLATIONS[settings.language][key] || TRANSLATIONS['en'][key];
    const isHomePhase = state.phase === GamePhase.DEALING;

    // --- VIEW ROUTING ---
    if (view === 'ADMIN') return <AdminGate onExit={() => setView('GAME')} />;
    
    if (view === 'ROOM') return <PersonalRoom 
        userProfile={userProfile} 
        onExit={() => setView('GAME')} 
        onStartGame={() => { 
            handleStartGame(false); 
        }} 
        gameState={state}
        interactionState={interactionState}
        onActionClick={handle3DActionClick}
        aiChatMessages={aiChatMessages}
        thinkingPlayers={thinkingPlayers}
        onCardClick={(id: string) => settings.oneClickPlay ? actions.executePlayCard(0, id) : actions.setSelectedCardId(id === state.selectedCardId ? null : id)} 
        onDragPlay={(id: string) => actions.executePlayCard(0, id)} 
        onPlayConfirm={(id: string) => actions.executePlayCard(0, id)} 
        humanPlayer={humanPlayer}
        cardMarkers={cardMarkers}
        oneClickPlay={settings.oneClickPlay}
        actionLabel={interactionState.label}
    />;

    const shouldShowScoreModal = state.phase === GamePhase.SCORING && (
        !isTutorialActive || (state.currentScenario?.id === 'TUTORIAL_SETTLEMENT' && !state.isTutorialComplete)
    );

    const showSmartRecorderSetup = ui.showSettings && ui.activeSettingsTab === 'RECORDER';
    const showStandardSettings = ui.showSettings && ui.activeSettingsTab !== 'RECORDER';

    const handleAvatarUpdate = (url: string) => {
        const newProfile: UserProfile = userProfile ? { ...userProfile, avatar_url: url } : {
            id: `guest_${Date.now()}`,
            username: 'Guest',
            gender: 'MALE' as Gender,
            age: 20,
            country: 'cn',
            is_looking_for_match: false,
            last_active: Date.now(),
            friends: [],
            avatar_url: url,
            coins: 2000
        };
        
        setUserProfile(newProfile);
        upsertUserProfile(newProfile); 
    };

    const handleCoinSpend = (cost: number) => {
        if (!userProfile) return false;
        const current = userProfile.coins || 0;
        if (current < cost) return false;
        
        const newCoins = current - cost;
        const newProfile = { ...userProfile, coins: newCoins };
        setUserProfile(newProfile);
        upsertUserProfile({ coins: newCoins });
        return true;
    };

    return (
        <div className={`fixed inset-0 overflow-hidden transition-colors duration-1000 ${skin.layout.backgroundClass}`}> 
            <Scene3D 
                players={state.players} 
                tableCards={state.tableCards} 
                mianZhangCard={state.mianZhangCard} 
                phase={state.phase} 
                currentPlayerIndex={state.currentPlayerIndex} 
                bankerId={state.bankerId} 
                trickWinnerId={state.trickWinnerId} 
                pot={state.pot}
                kaiChongCardIndex={state.kaiChongCardIndex}
                kaiChongHistory={state.kaiChongHistory}
                interactionState={{ ...interactionState, onActionClick: handle3DActionClick }} 
                highlightedCardIds={isTutorialActive ? tutorialHighlights : undefined}
            />

            {!isHomePhase && state.phase !== GamePhase.SHUFFLING && (
                <>
                    <div className="animate-fade-in relative z-[200]">
                        <MentorOverlay message={aiChatMessages[99]} />
                        <PlayerListHUD 
                            players={state.players} 
                            bankerId={state.bankerId} 
                            currentPlayerIndex={state.currentPlayerIndex} 
                            aiChatMessages={{}} 
                            activeNotification={state.activeNotification}
                            thinkingPlayers={thinkingPlayers} 
                        />
                        {humanPlayer && (
                            <HumanHandHUD 
                                player={humanPlayer} 
                                isMyTurn={state.players[state.currentPlayerIndex]?.id === 0} 
                                onCardClick={(id: string) => settings.oneClickPlay ? actions.executePlayCard(0, id) : actions.setSelectedCardId(id === state.selectedCardId ? null : id)} 
                                onDragPlay={(id: string) => actions.executePlayCard(0, id)} 
                                onPlayConfirm={(id: string) => actions.executePlayCard(0, id)} 
                                selectedCardId={state.selectedCardId} 
                                highlightedCardIds={isTutorialActive ? tutorialHighlights : interactionState.highlightedCardIds} 
                                cardMarkers={cardMarkers} 
                                oneClickPlay={settings.oneClickPlay} 
                                canInteract={!interactionState.disabled} 
                                actionLabel={interactionState.label} 
                            />
                        )}
                        
                        <SystemOverlays 
                            ui={ui} 
                            settings={settings} 
                            onOpenWardrobe={() => setShowWardrobe(true)} 
                            onToggleChat={setChatOpen} 
                            chatOpen={chatOpen} 
                        />
                        
                        <SuitHistoryPanel recordedCards={state.recordedCards} visible={settings.showSuitHistory} />
                        
                        <SmartRecorderOverlay recorder={recorder} />
                        
                        {/* [NEW] Zen Music Player Injection */}
                        <ZenMusicPlayer />
                    </div>

                    {shouldShowScoreModal && (
                        <ScoreModal 
                            results={state.roundResults} 
                            onNextRound={actions.startNextRound} 
                            onHome={actions.exitToTitle} 
                            bankerId={state.bankerId} 
                            language={settings.language} 
                            players={state.players} 
                            isTutorialMode={isTutorialActive} 
                        />
                    )}

                    {state.pendingRisk && (
                        <RiskWarningModal 
                            risk={state.pendingRisk} 
                            onConfirm={() => {
                                actions.setPendingRisk(null);
                                actions.executePlayCard(0, state.pendingRisk!.cardId, true);
                            }} 
                            onCancel={() => actions.setPendingRisk(null)} 
                        />
                    )}

                    {isTutorialActive && (currentStep || state.isTutorialComplete) && (
                        <div className="relative z-[1000]">
                            <TutorialOverlay 
                                step={currentStep || null} 
                                scenarioId={state.currentScenario?.id}
                                onNext={actions.advanceTutorialStep} 
                                isComplete={state.isTutorialComplete}
                                onMenuAction={(action, payload) => {
                                    if (action === 'NEXT') handleTutorialNext();
                                    else if (action === 'SELECT') { if (payload) actions.startTutorial(userProfile, payload); }
                                    else if (action === 'PRACTICE') { actions.exitToTitle(); setTimeout(() => actions.startGame(userProfile), 50); }
                                    else actions.exitToTitle();
                                }}
                            />
                        </div>
                    )}
                </>
            )}

            {isHomePhase && (
                <HomeScreen 
                    userProfile={userProfile} 
                    skin={skin} 
                    availableSkins={availableSkins} 
                    setSkinId={setSkinId} 
                    onStartGame={handleStartGame} 
                    onNetBattle={() => ui.setShowSocialModal(true)} 
                    onStartTutorial={handleStartTutorial}
                    onEnterRoom={() => setView('ROOM')} 
                    onSignOut={async () => { await platformService.auth.logout(); setUserProfile(undefined); actions.exitToTitle(); }} 
                    t={t} 
                />
            )}
            
            {showStandardSettings && <SettingsModal onClose={() => ui.setShowSettings(false)} onOpenAdmin={() => { ui.setShowSettings(false); setView('ADMIN'); }} settings={settings} ui={ui} gameData={state} />}
            
            {showSmartRecorderSetup && <SmartRecorderSetup onClose={() => ui.setShowSettings(false)} recorder={recorder} />}
            
            {ui.showSocialModal && <SocialLoginModal onClose={() => ui.setShowSocialModal(false)} onLoginSuccess={(p: any, matches?: any[]) => { ui.setShowSocialModal(false); setUserProfile(p); actions.startGame(p, matches); }} />}

            {/* WARDROBE MODAL */}
            {showWardrobe && (
                <WardrobeModal 
                    onClose={() => setShowWardrobe(false)} 
                    onSaveAvatar={handleAvatarUpdate} 
                    currentAvatarUrl={userProfile?.avatar_url} 
                    userCoins={userProfile?.coins || 0}
                    onSpendCoins={handleCoinSpend}
                />
            )}

            {/* Controlled Chat Instance */}
            <Chat language={settings.language} isHidden={isHomePhase} isOpen={chatOpen} onToggle={setChatOpen} />
        </div>
    );
};