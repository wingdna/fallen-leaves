
import React, { useState, useEffect, useRef } from 'react';
import { sendMessageToTutor, initializeChat, isAIEnabled } from '../services/geminiService';
import { ChatMessage, SupportedLanguage } from '../types';
import { TRANSLATIONS } from '../constants';

const MessageItem: React.FC<{ msg: ChatMessage }> = ({ msg }) => (
    <div className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} mb-4 px-2`}>
        <div className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm font-sans leading-relaxed ${
            msg.role === 'user' 
                ? 'bg-[#d4af37] text-black rounded-br-none shadow-md' 
                : (msg.role === 'system' ? 'bg-zinc-800 text-zinc-400 italic text-center w-full' : 'bg-[#2a1b15] text-[#f5e6d3] border border-[#8c6239]/50 rounded-bl-none shadow-xl')
        }`}>
            {msg.text}
        </div>
    </div>
);

const MentorAvatarIcon = ({ isOpen, onClick }: any) => (
    <button 
        onClick={onClick}
        className={`group relative w-16 h-16 md:w-20 md:h-20 transition-all duration-500 hover:scale-110 active:scale-95 z-[500] rounded-full border-4 ${isOpen ? 'border-[#c5a059] ring-4 ring-[#c5a059]/20' : 'border-[#3e2b22] shadow-2xl'}`}
    >
        <div className="w-full h-full rounded-full overflow-hidden bg-[#1a0f0a]">
            <img 
                src="https://api.dicebear.com/9.x/avataaars/svg?seed=Felix&facialHair=majestic&facialHairColor=ffffff&top=shortFlat&hairColor=f1f1f1&backgroundColor=1a0f0a" 
                className="w-full h-full object-cover filter contrast-110"
                alt="Tutor"
            />
        </div>
        <div className="absolute -bottom-1 -right-1 bg-[#8c1c0b] text-white text-[9px] px-2 py-0.5 rounded-full border border-[#d4af37] font-black tracking-widest shadow-lg">导师</div>
        {!isOpen && <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full animate-ping opacity-75"></div>}
    </button>
);

const ChatInput = ({ onSend, disabled }: any) => {
    const [text, setText] = useState('');
    const handleSend = () => { if (text.trim() && !disabled) { onSend(text); setText(''); } };
    return (
        <div className="p-4 border-t border-[#3e2b22] bg-[#0c0806] flex gap-2">
            <input 
                type="text" 
                value={text}
                onChange={(e) => setText(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                disabled={disabled}
                placeholder="问问爷爷这把怎么打..."
                className="flex-1 bg-black/40 border border-[#3e2b22] rounded-full px-5 py-2 text-[#e6c278] outline-none focus:border-[#c5a059] text-sm placeholder:text-[#8c6239]/50"
            />
            <button 
                onClick={handleSend}
                disabled={disabled || !text.trim()}
                className="bg-[#3d0e0e] text-[#d4af37] w-10 h-10 rounded-full border border-[#5c1010] flex items-center justify-center hover:bg-[#5c1010] transition-all"
            >
                ➔
            </button>
        </div>
    );
};

interface ChatProps {
  language: SupportedLanguage;
  isHidden?: boolean; 
  isOpen?: boolean; // Controlled Mode
  onToggle?: (open: boolean) => void; // Controlled Mode
}

const Chat: React.FC<ChatProps> = ({ language, isHidden, isOpen: externalIsOpen, onToggle }) => {
  const [internalIsOpen, setInternalIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  
  // Use external control if provided, otherwise internal
  const isControlled = typeof externalIsOpen !== 'undefined';
  const isOpen = isControlled ? externalIsOpen : internalIsOpen;
  const toggleOpen = () => {
      if (isControlled && onToggle) onToggle(!isOpen);
      else setInternalIsOpen(!isOpen);
  };
  
  const MAX_HISTORY = 50; 

  useEffect(() => {
      if (isOpen && messages.length === 0 && isAIEnabled()) {
          initializeChat().then(greet => {
              setMessages([{ role: 'model', text: greet, timestamp: Date.now() }]);
          });
      }
  }, [isOpen]);

  useEffect(() => {
      if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  const handleSend = async (text: string) => {
      setMessages(prev => {
          const next: ChatMessage[] = [...prev, { role: 'user' as const, text, timestamp: Date.now() }];
          return next.slice(-MAX_HISTORY);
      });
      
      setIsTyping(true);
      try {
          const response = await sendMessageToTutor(text);
          setMessages(prev => {
              const next: ChatMessage[] = [...prev, { role: 'model' as const, text: response, timestamp: Date.now() }];
              return next.slice(-MAX_HISTORY);
          });
      } catch (e) {
          setMessages(prev => [...prev, { role: 'model' as const, text: "爷爷年纪大了，刚才走神了，再说一遍？", timestamp: Date.now() }]);
      } finally {
          setIsTyping(false);
      }
  };

  const clearHistory = () => {
      if (confirm("确定要清空与导师的谈话记录吗？")) {
          setMessages([]);
          if (isAIEnabled()) {
              initializeChat().then(greet => {
                  setMessages([{ role: 'model', text: greet, timestamp: Date.now() }]);
              });
          }
      }
  };

  if (isHidden) return null;

  return (
    <div className={`fixed z-[400] flex flex-col items-end ${isControlled ? 'top-20 left-48 items-start' : 'top-10 right-10'}`}>
      {/* Only show default avatar button if NOT controlled externally */}
      {!isControlled && <MentorAvatarIcon isOpen={isOpen} onClick={toggleOpen} />}
      
      {isOpen && (
          <div className="mt-4 w-[320px] md:w-[400px] h-[500px] bg-[#15100e] border border-[#3e2b22] shadow-2xl flex flex-col rounded-2xl overflow-hidden animate-fade-in-up">
              <div className="p-4 bg-[#0c0806] border-b border-[#3e2b22] flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <h3 className="text-[#c5a059] font-bold tracking-widest text-sm">邻家导师</h3>
                    <button 
                        onClick={clearHistory}
                        title="清空历史"
                        className="text-[#8c6239] hover:text-red-400 transition-colors"
                    >
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18"></path><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path></svg>
                    </button>
                  </div>
                  <button onClick={() => isControlled && onToggle ? onToggle(false) : setInternalIsOpen(false)} className="text-[#8c6239] hover:text-white transition-colors">✕</button>
              </div>
              <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 custom-scrollbar bg-[#0a0505]">
                  {messages.map((m, i) => <MessageItem key={i} msg={m} />)}
                  {isTyping && (
                      <div className="flex justify-start mb-4 px-2">
                          <div className="bg-[#1a0f0a] text-[#c5a059] px-4 py-2 rounded-2xl rounded-bl-none text-xs animate-pulse">
                              爷爷正在想怎么跟你说...
                          </div>
                      </div>
                  )}
              </div>
              <ChatInput onSend={handleSend} disabled={isTyping} />
          </div>
      )}
    </div>
  );
};

export default React.memo(Chat);
