
// @ts-nocheck

import React, { useState, useEffect, Suspense, useMemo, useRef } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { 
    OrbitControls, ContactShadows, useCursor, Environment, 
    Sky, Stars, Text, Billboard, useGLTF, Float, Html,
    Sparkles, Grid, Plane, SoftShadows, BakeShadows,
    Instances, Instance, useTexture,
    TransformControls, AccumulativeShadows, RandomizedLight
} from '@react-three/drei';
import * as THREE from 'three';
import { StylizedButton, HUANGHUALI_TEXTURE } from '../UI/Shared';
import { UserProfile, FurnitureItem, FurnitureType, ZoneId, GamePhase, Player } from '../../types';
import { upsertUserProfile, MOCK_PLAYERS } from '../../services/cloudService';
import { WardrobeModal } from '../UI/WardrobeModal';
import { SeatedAvatarModel } from '../Visuals/SeatedAvatar'; 
import { TableCards, PotPile, WonCardPiles } from '../Visuals/TableCards'; 
import { Compass } from '../Visuals/TableEffects'; 
import { PlayerListHUD, HumanHandHUD } from '../UI/GameInterface';
import { ScoreModal } from '../UI/Modals'; 
import { useLayoutEngine } from '../../hooks/useLayoutEngine';
import { SkinContext, useSkin } from '../../contexts/SkinContext';
import { GameSettingsContext, useGameSettings } from '../../hooks/useGameSettings';

// --- INTERFACE DEFINITION (RESTORED) ---
interface PersonalRoomProps {
    userProfile: UserProfile | undefined;
    onExit: () => void;
    onStartGame: () => void;
    gameState: any;
    interactionState: any;
    aiChatMessages: Record<number, string | null>;
    thinkingPlayers: Set<number>;
    onCardClick: (id: string) => void;
    onDragPlay: (id: string) => void;
    onPlayConfirm: (id: string) => void;
    onActionClick?: () => void;
    humanPlayer: Player | undefined;
    cardMarkers: any;
    oneClickPlay: boolean;
    actionLabel: string;
}

// --- TITANIUM GRADE PBR MATERIALS ---
const MATERIAL_POOL = {
    huanghuali: new THREE.MeshPhysicalMaterial({ 
        color: '#b86d28', roughness: 0.25, metalness: 0.1,
        clearcoat: 1.0, clearcoatRoughness: 0.1, sheen: 1.0, sheenColor: '#ffcc00'
    }),
    zitan: new THREE.MeshPhysicalMaterial({ 
        color: '#1a0505', roughness: 0.6, metalness: 0.0,
        clearcoat: 0.3, sheen: 0.2, sheenColor: '#4a0e0e'
    }),
    snow: new THREE.MeshStandardMaterial({
        color: '#ffffff', roughness: 1.0, emissive: '#eeeeee', emissiveIntensity: 0.2
    }),
    water: new THREE.MeshPhysicalMaterial({
        color: '#ffffff', roughness: 0.0, metalness: 0.1, transmission: 0.95, opacity: 0.8, transparent: true, ior: 1.33
    })
};

// --- OPTIMIZED SNOW SYSTEM (INSTANCING) ---
const InstancedSnow = ({ count = 200 }) => {
    const meshRef = useRef();
    const dummy = useMemo(() => new THREE.Object3D(), []);
    const particles = useMemo(() => {
        const temp = [];
        for(let i=0; i<count; i++) {
            temp.push({
                x: (Math.random() - 0.5) * 20,
                y: Math.random() * 10 + 5,
                z: (Math.random() - 0.5) * 20,
                speed: 0.02 + Math.random() * 0.05,
                factor: Math.random() * 100
            });
        }
        return temp;
    }, [count]);

    useFrame((state) => {
        if(!meshRef.current) return;
        particles.forEach((p, i) => {
            let t = state.clock.getElapsedTime() * 0.5;
            p.y -= p.speed;
            if(p.y < 0) p.y = 10;
            
            dummy.position.set(
                p.x + Math.sin(t + p.factor) * 0.5,
                p.y,
                p.z + Math.cos(t + p.factor) * 0.5
            );
            dummy.rotation.set(t, t, t);
            dummy.scale.setScalar(0.05);
            dummy.updateMatrix();
            meshRef.current.setMatrixAt(i, dummy.matrix);
        });
        meshRef.current.instanceMatrix.needsUpdate = true;
    });

    return (
        <instancedMesh ref={meshRef} args={[null, null, count]}>
            <dodecahedronGeometry args={[1, 0]} />
            <meshBasicMaterial color="white" transparent opacity={0.8} />
        </instancedMesh>
    );
};

// --- FURNITURE COMPONENTS ---
const MingTable = () => (
    <group scale={1.5}>
        <mesh position={[0, 0.75, 0]} castShadow receiveShadow material={MATERIAL_POOL.huanghuali}>
            <boxGeometry args={[1.6, 0.04, 1.6]} />
        </mesh>
        <mesh position={[0, 0.71, 0]} material={MATERIAL_POOL.huanghuali}>
            <boxGeometry args={[1.5, 0.04, 1.5]} />
        </mesh>
        {[1, -1].map(x => [1, -1].map(z => (
            <group key={`leg-${x}${z}`} position={[x*0.7, 0, z*0.7]}>
                <mesh position={[0, 0.35, 0]} material={MATERIAL_POOL.huanghuali} castShadow>
                    <cylinderGeometry args={[0.04, 0.035, 0.7, 8]} />
                </mesh>
            </group>
        )))}
    </group>
);

const FurnitureObject: React.FC<any> = ({ item, isSelected, onClick, isEditMode, onInteract, userAvatarUrl, isSeated, onTransform }) => {
    const [hovered, setHover] = useState(false);
    useCursor(isEditMode && hovered);
    const objectRef = useRef();

    const handleClick = (e: any) => {
        e.stopPropagation();
        onClick(item.id);
        if (!isEditMode && onInteract && !isSeated) {
            onInteract(item.type, new THREE.Vector3(item.position[0], item.position[1], item.position[2]), item.rotation);
        }
    };

    return (
        <>
            {isEditMode && isSelected && (
                <TransformControls 
                    object={objectRef} 
                    mode="translate" 
                    onMouseUp={() => {
                        if(objectRef.current) {
                            const { x, y, z } = objectRef.current.position;
                            onTransform(item.id, [x, y, z], objectRef.current.rotation.y);
                        }
                    }} 
                />
            )}
            <group 
                ref={objectRef}
                position={item.position} 
                rotation={[0, item.rotation, 0]} 
                onClick={handleClick} 
                onPointerOver={() => setHover(true)} 
                onPointerOut={() => setHover(false)}
            >
                <MingTable />
                
                {/* Visual Selection Ring */}
                {isSelected && (
                    <mesh position={[0, 0.02, 0]} rotation={[-Math.PI/2, 0, 0]}>
                        <ringGeometry args={[1.2, 1.3, 64]} />
                        <meshBasicMaterial color="#ffd700" toneMapped={false} />
                    </mesh>
                )}

                {/* Interaction Label */}
                {!isEditMode && hovered && !isSeated && (
                    <Html position={[0, 1.5, 0]} center>
                        <div className="px-3 py-1 bg-black/80 border border-[#c5a059] text-[#c5a059] text-xs font-serif rounded pointer-events-none whitespace-nowrap animate-bounce">
                            点击入座 (SIT)
                        </div>
                    </Html>
                )}
            </group>
        </>
    );
};

const RoomEnvironment = () => (
    <group>
        <ambientLight intensity={0.5} color="#b0c4de" />
        <directionalLight position={[5, 10, 5]} intensity={1.5} castShadow shadow-bias={-0.0001} />
        <pointLight position={[-5, 5, -5]} intensity={0.8} color="#ffaa55" />
        
        {/* Floor */}
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
            <planeGeometry args={[50, 50]} />
            <meshStandardMaterial color="#1a1a1a" roughness={0.8} />
        </mesh>
        
        <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
        <InstancedSnow count={300} />
    </group>
);

// --- MAIN COMPONENT ---
export const PersonalRoom: React.FC<PersonalRoomProps> = ({ 
    userProfile, onExit, onStartGame, 
    gameState, interactionState, aiChatMessages, thinkingPlayers,
    onCardClick, onDragPlay, onPlayConfirm, onActionClick, humanPlayer, cardMarkers, oneClickPlay, actionLabel
}) => {
    const [items, setItems] = useState<FurnitureItem[]>([
        { id: 'main_table', type: 'GAME_TABLE', zoneId: 'TEA_ROOM', position: [0, 0, 0], rotation: 0 }
    ]);
    const [selectedId, setSelectedId] = useState<string | null>(null);
    const [isEditMode, setIsEditMode] = useState(false);
    const [isSeated, setIsSeated] = useState(false);
    
    // Camera State
    const [seatedTablePos, setSeatedTablePos] = useState(new THREE.Vector3(0,0,0));
    
    const skinData = useSkin();
    const settingsData = useGameSettings();
    const layoutConfig = useLayoutEngine();

    const handleTransform = (id: string, pos: [number, number, number], rot: number) => {
        setItems(prev => prev.map(item => item.id === id ? { ...item, position: pos, rotation: rot } : item));
    };

    const handleInteract = (type: FurnitureType, pos: THREE.Vector3, rot: number) => {
        setSeatedTablePos(pos);
        setIsSeated(true);
    };

    const isGameActive = gameState && gameState.phase !== GamePhase.DEALING && isSeated;

    return (
        <div className="fixed inset-0 bg-[#02040a] z-[100] font-serif">
            <Canvas shadows dpr={[1, 2]} camera={{ position: [5, 6, 8], fov: 40 }}>
                
                <SkinContext.Provider value={skinData}>
                    <GameSettingsContext.Provider value={settingsData}>
                        <RoomEnvironment />
                        
                        <group>
                            {items.map(item => (
                                <FurnitureObject 
                                    key={item.id} 
                                    item={item} 
                                    isSelected={selectedId === item.id} 
                                    onClick={setSelectedId} 
                                    isEditMode={isEditMode} 
                                    onInteract={handleInteract} 
                                    onTransform={handleTransform}
                                    isSeated={isSeated}
                                />
                            ))}
                        </group>

                        {/* GAME OVERLAY 3D - Placeholder for future expansion */}
                        {isSeated && isGameActive && (
                            <group position={seatedTablePos}>
                                {/* Game elements would render here in 3D space if fully ported */}
                            </group>
                        )}

                        <OrbitControls 
                            makeDefault 
                            enabled={!isSeated} 
                            maxPolarAngle={Math.PI / 2.1} 
                            minDistance={2} 
                            maxDistance={20}
                        />
                    </GameSettingsContext.Provider>
                </SkinContext.Provider>
            </Canvas>

            {/* UI OVERLAYS */}
            <div className="absolute top-4 right-4 flex gap-2 pointer-events-auto">
                {!isSeated && (
                    <StylizedButton onClick={() => setIsEditMode(!isEditMode)} className="px-4 text-xs">
                        {isEditMode ? '完成布置' : '布置房间'}
                    </StylizedButton>
                )}
                <StylizedButton onClick={onExit} className="px-4 text-xs">退出 (EXIT)</StylizedButton>
            </div>

            {/* HUD / GAME UI INJECTION */}
            {isSeated && isGameActive && (
                <div className="absolute inset-0 pointer-events-none z-[200]">
                    <PlayerListHUD 
                        players={gameState.players} 
                        bankerId={gameState.bankerId} 
                        currentPlayerIndex={gameState.currentPlayerIndex} 
                        aiChatMessages={aiChatMessages} 
                        activeNotification={gameState.activeNotification}
                        thinkingPlayers={thinkingPlayers} 
                    />
                    {humanPlayer && (
                        <HumanHandHUD 
                            player={humanPlayer} 
                            isMyTurn={gameState.players[gameState.currentPlayerIndex]?.id === 0} 
                            onCardClick={onCardClick}
                            onDragPlay={onDragPlay}
                            onPlayConfirm={onPlayConfirm}
                            selectedCardId={gameState.selectedCardId} 
                            highlightedCardIds={interactionState.highlightedCardIds} 
                            cardMarkers={cardMarkers} 
                            oneClickPlay={oneClickPlay} 
                            canInteract={!interactionState.disabled} 
                            actionLabel={actionLabel} 
                        />
                    )}
                </div>
            )}
            
            {isSeated && !isGameActive && (
                <div className="absolute bottom-20 left-1/2 -translate-x-1/2 pointer-events-auto flex flex-col items-center gap-4">
                    <div className="text-white/70 text-sm bg-black/50 px-4 py-2 rounded">已入座</div>
                    <StylizedButton onClick={onStartGame} className="px-12 py-4 text-lg bg-[#3d0e0e] border-[#c5a059] text-[#ffd700]">
                        开局 (START)
                    </StylizedButton>
                </div>
            )}
        </div>
    );
};
