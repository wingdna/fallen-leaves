
import React, { useState } from 'react';
import { TUTORIAL_LEVELS } from '../../services/tutorialScenarios';
import { StylizedButton, HUANGHUALI_TEXTURE, ImperialWindow } from './Shared';

interface TutorialMenuProps {
    onSelectScenario: (scenario: any, recordMode: boolean) => void; 
    onClose: () => void;
}

export const TutorialMenu: React.FC<TutorialMenuProps> = ({ onSelectScenario, onClose }) => {
    const [isRecordMode, setIsRecordMode] = useState(false);

    return (
        <div className="fixed inset-0 z-[600] flex items-center justify-center bg-black/90 backdrop-blur-md animate-fade-in font-serif">
            <ImperialWindow title="拜师学艺" onClose={onClose} width="w-full max-w-lg" height="max-h-[85vh]">
                
                {/* List */}
                <div className="flex-1 overflow-y-auto p-6 space-y-4 relative z-10 custom-scrollbar bg-[#080605]">
                    {TUTORIAL_LEVELS.map((scenario, index) => (
                        <button
                            key={scenario.id}
                            onClick={() => onSelectScenario(scenario, isRecordMode)}
                            className="w-full text-left group relative overflow-hidden p-5 border border-[#3e2b22] bg-[#0a0807] hover:border-[#c5a059] transition-all duration-500 rounded-[2px] active:scale-[0.98] shadow-md hover:shadow-[0_0_20px_rgba(197,160,89,0.1)]"
                        >
                            {/* Inner Highlight */}
                            <div className="absolute inset-0 bg-gradient-to-r from-[#c5a059]/10 to-transparent translate-x-[-100%] group-hover:translate-x-0 transition-transform duration-500"></div>
                            
                            <div className="relative z-10 flex justify-between items-center">
                                <div>
                                    <div className="text-[#e6c278] font-bold text-lg mb-1 tracking-widest group-hover:text-[#ffd700] transition-colors drop-shadow-sm">
                                        {scenario.title}
                                    </div>
                                    <div className="text-[#8c6239] text-xs opacity-70 group-hover:opacity-100 transition-opacity font-medium tracking-wide">
                                        {scenario.description}
                                    </div>
                                </div>
                                <div className="text-[#3e2b22] group-hover:text-[#c5a059] text-4xl font-serif font-black transition-colors opacity-30 group-hover:opacity-100 group-hover:scale-110 transform duration-500">
                                    {(index + 1).toString().padStart(2, '0')}
                                </div>
                            </div>
                        </button>
                    ))}
                </div>

                {/* Footer Controls */}
                <div className="p-6 border-t border-[#3e2b22]/50 bg-[#0c0806] flex flex-col gap-4 shrink-0 relative z-20">
                    
                    <div className="flex items-center justify-between gap-4">
                        {/* Recording Toggle */}
                        <button 
                            onClick={() => setIsRecordMode(!isRecordMode)}
                            className={`flex items-center gap-3 px-4 py-3 rounded-[2px] border transition-all duration-300 ${isRecordMode ? 'bg-[#3d0e0e] border-red-500/50 shadow-[0_0_10px_rgba(220,38,38,0.2)]' : 'bg-[#0a0807] border-[#3e2b22] hover:bg-[#1a100a]'}`}
                        >
                            <div className={`w-4 h-4 rounded-full border transition-all duration-300 ${isRecordMode ? 'bg-red-500 border-red-300 shadow-[0_0_10px_red]' : 'bg-[#1a1a1a] border-[#555]'}`}></div>
                            <div className="flex flex-col items-start">
                                <span className={`text-xs font-bold tracking-widest ${isRecordMode ? 'text-red-400' : 'text-[#8c6239] group-hover:text-[#a0a0a0]'}`}>
                                    {isRecordMode ? '录课模式 (REC)' : '开启录课'}
                                </span>
                                <span className="text-[9px] text-[#555] scale-90 origin-left">生成语音讲解</span>
                            </div>
                        </button>

                        {/* Back Button using StylizedButton for consistency */}
                        {/* [FIX] Changed from '返回大厅' to '返回主页' */}
                        <StylizedButton onClick={onClose} className="flex-1 text-xs">
                            返回主页
                        </StylizedButton>
                    </div>

                    <div className="flex justify-center items-center gap-2 opacity-40 mt-2">
                        <div className="h-px w-12 bg-gradient-to-r from-transparent to-[#5c4033]"></div>
                        <p className="text-[#5c4033] text-[9px] tracking-[0.3em] font-serif">温故而知新</p>
                        <div className="h-px w-12 bg-gradient-to-l from-transparent to-[#5c4033]"></div>
                    </div>
                </div>
            </ImperialWindow>
        </div>
    );
};
