
import React from 'react';
import { TutorialStep } from '../../types';
import { TUTORIAL_LEVELS } from '../../services/tutorialScenarios';
import { HUANGHUALI_TEXTURE } from './Shared';

interface TutorialOverlayProps {
    step: TutorialStep | null | undefined;
    scenarioId?: string;
    onNext: () => void;
    isComplete?: boolean;
    onMenuAction?: (action: 'NEXT' | 'PRACTICE' | 'HOME' | 'SELECT', payload?: any) => void;
}

// 纹理材质定义
const CLOUD_PATTERN = `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M20 20 C 10 10 30 10 20 0 C 10 10 30 10 20 20' stroke='%233e2b22' fill='none' opacity='0.1'/%3E%3C/svg%3E")`;

// 导师头像 - Exported for reuse - [UPDATED] High Contrast for Small Icons
export const GrandpaAvatar = () => (
    <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-2xl">
        <defs>
            <radialGradient id="skinGrad" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#eecfa1" />
                <stop offset="100%" stopColor="#d2b48c" />
            </radialGradient>
            <linearGradient id="beardGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#fefefe" /> {/* Brighter White */}
                <stop offset="100%" stopColor="#dcdcdc" />
            </linearGradient>
        </defs>
        {/* Hat: Darker for contrast */}
        <path d="M15,30 Q50,0 85,30 L90,55 Q50,65 10,55 Z" fill="#0a0a0a" stroke="#222" strokeWidth="1" />
        <path d="M10,40 L0,35 L5,50 Z" fill="#0a0a0a" />
        <path d="M90,40 L100,35 L95,50 Z" fill="#0a0a0a" />
        {/* Gold Gem on Hat */}
        <circle cx="50" cy="25" r="5" fill="#ffd700" stroke="#b8860b" strokeWidth="1" />
        
        {/* Face */}
        <circle cx="50" cy="55" r="23" fill="url(#skinGrad)" />
        
        {/* Glasses: Thicker stroke */}
        <path d="M36,52 Q41,50 46,52" fill="none" stroke="#5c4033" strokeWidth="2" strokeLinecap="round" />
        <path d="M54,52 Q59,50 64,52" fill="none" stroke="#5c4033" strokeWidth="2" strokeLinecap="round" />
        <circle cx="41" cy="54" r="5.5" fill="rgba(255,255,255,0.2)" stroke="#3e2723" strokeWidth="2" />
        <line x1="46.5" y1="54" x2="53.5" y2="54" stroke="#3e2723" strokeWidth="2" />
        <circle cx="59" cy="54" r="5.5" fill="rgba(255,255,255,0.2)" stroke="#3e2723" strokeWidth="2" />
        
        {/* Beard */}
        <path d="M30,65 Q50,110 70,65 Q60,80 50,95 Q40,80 30,65" fill="url(#beardGrad)" filter="drop-shadow(0 2px 2px rgba(0,0,0,0.3))" />
        {/* Mouth */}
        <path d="M45,64 Q50,68 55,64" fill="none" stroke="#8b4513" strokeWidth="2" strokeLinecap="round" />
    </svg>
);

export const TutorialOverlay: React.FC<TutorialOverlayProps> = ({ step, scenarioId, onNext, isComplete, onMenuAction }) => {
    const isInteractive = !isComplete && step && (!step.waitForClick && !step.aiMoves);
    const isSettlementReview = step?.id === 'step_4_settlement_wait';
    const currentLevelIndex = TUTORIAL_LEVELS.findIndex(s => s.id === scenarioId);

    // [FIX] Refined message parser: 
    // 1. Replaced forced block splitting with continuous flow.
    // 2. Used calligraphy font for highlights without boxy backgrounds.
    // 3. Removed heavy text shadows.
    const parseMessage = (text: string) => {
        if (!text) return null;
        const parts = text.split(/【(.*?)】/g);
        return (
            <div className="leading-[2.5] tracking-[0.15em] text-lg md:text-xl text-[#e8e4d9] font-serif text-justify">
                {parts.map((part, i) => {
                    if (i % 2 === 1) {
                        // [TEXT BEAUTY] Ancient Highlight: Calligraphy + Gold + Size Up
                        return (
                            <span key={i} className="font-calligraphy text-2xl md:text-3xl text-[#ffd700] mx-1 align-text-bottom drop-shadow-[0_2px_0_rgba(0,0,0,0.5)]">
                                {part}
                            </span>
                        );
                    }
                    // [TEXT BEAUTY] Normal Text: Clean Serif, Light Shadow
                    const cleanPart = part.replace(/\n/g, ''); // Flatten newlines
                    return <span key={i} className="opacity-90 drop-shadow-sm">{cleanPart}</span>;
                })}
            </div>
        );
    };

    return (
        <div className={`fixed inset-0 z-[1000] flex flex-col items-center justify-center font-serif transition-all duration-500 pointer-events-none`}>
            
            <div className={`absolute inset-0 bg-black/30 transition-opacity duration-700 ${isInteractive || isSettlementReview ? 'opacity-0' : 'opacity-100 pointer-events-auto'}`}></div>

            {/* --- COMPLETION MENU (Lesson Finished) --- */}
            {isComplete && (
                <div className="relative z-50 pointer-events-auto animate-fade-in-up w-[95%] max-w-3xl h-[500px]">
                    <div className="relative h-full bg-[#0f0a08]/95 backdrop-blur-md border border-[#5c3a21] rounded-sm p-1 shadow-[0_30px_100px_black] overflow-hidden flex">
                        <div className="w-1/3 border-r border-[#3e2b22] bg-[#080504]/50 flex flex-col">
                            <div className="p-4 border-b border-[#3e2b22] bg-[#1a100a]/30"><h3 className="text-gilded font-bold tracking-[0.2em] text-sm text-center">课程目录</h3></div>
                            <div className="flex-1 overflow-y-auto custom-scrollbar p-2 space-y-1">
                                {TUTORIAL_LEVELS.map((level, idx) => {
                                    const isPassed = idx < currentLevelIndex;
                                    const isCurrent = idx === currentLevelIndex;
                                    const textColor = (isPassed || isCurrent) ? 'text-gilded' : 'text-stone-600';
                                    const iconColor = (isPassed || isCurrent) ? 'text-[#ffd700]' : 'text-stone-700';
                                    const bgClass = isCurrent ? 'bg-gradient-to-r from-[#ffd700]/10 to-transparent border-l-2 border-[#ffd700]' : 'border-l-2 border-transparent hover:bg-white/[0.05]';
                                    return (
                                        <button key={level.id} onClick={() => onMenuAction && onMenuAction('SELECT', level)} className={`w-full text-left p-3 rounded-sm flex items-start gap-3 transition-all ${bgClass} group cursor-pointer`}>
                                            <div className={`mt-1 text-[10px] ${iconColor} group-hover:scale-110 transition-transform`}>{isCurrent ? '◉' : (isPassed ? '●' : '○')}</div>
                                            <div className="flex flex-col flex-1 min-w-0"><span className={`text-xs font-bold leading-tight ${textColor} truncate group-hover:text-[#ffd700]`}>{level.title}</span><span className="text-[9px] text-stone-600 mt-1 line-clamp-1 group-hover:text-stone-500">{level.description}</span></div>
                                            <span className={`text-sm font-mono font-black opacity-30 ${textColor} group-hover:opacity-50`}>{idx + 1}</span>
                                        </button>
                                    );
                                })}
                            </div>
                        </div>
                        <div className="w-2/3 relative flex flex-col">
                            <div className="absolute inset-0 opacity-20 pointer-events-none mix-blend-overlay" style={{ backgroundImage: HUANGHUALI_TEXTURE }}></div>
                            <div className="absolute inset-0 opacity-5 pointer-events-none mix-blend-screen bg-[url('https://www.transparenttextures.com/patterns/stardust.png')]"></div>
                            <div className="flex-1 flex flex-col items-center justify-center p-8">
                                <div className="mb-8 flex flex-col items-center gap-2">
                                    <div className="w-16 h-16 rounded-full bg-[#8c1c0b] border-2 border-[#ffd700] flex items-center justify-center shadow-lg mb-2"><span className="text-[#ffd700] text-3xl font-black font-calligraphy">完</span></div>
                                    <h2 className="text-gilded text-4xl font-black tracking-[0.3em] font-calligraphy drop-shadow-md">课业修毕</h2>
                                    <div className="h-px w-24 bg-gradient-to-r from-transparent via-[#c5a059] to-transparent mt-2"></div>
                                </div>
                                <div className="text-[#e8e4d9] text-center mb-10 leading-loose text-sm font-sans opacity-90 tracking-wide">
                                    <p>恭喜少侠！此章兵法已然了然于胸。</p>
                                    <p>江湖路远，是继续深造，还是小试牛刀？</p>
                                    <p className="mt-4 text-[#c5a059] font-bold opacity-80">你也可以自主选择左侧目录中的课程，<br/>老夫一一为你倾囊相授。</p>
                                </div>
                                <div className="flex flex-col w-full max-w-xs gap-4">
                                    {/* [FIX] Button Visibility: Used solid text color #ffd700 instead of text-gilded class which conflicts with bg-gradient */}
                                    <button 
                                        onClick={() => onMenuAction && onMenuAction('NEXT')} 
                                        className="group relative w-full py-4 bg-gradient-to-r from-[#2d0a0a] via-[#5c1010] to-[#2d0a0a] border border-[#c5a059] text-[#ffd700] font-black tracking-[0.2em] shadow-lg hover:brightness-125 transition-all active:scale-[0.98]"
                                    >
                                        <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                                        <span className="relative z-10 flex items-center justify-center gap-2">
                                            <span>继续深造</span>
                                            <span className="text-xs opacity-60 font-mono">(NEXT)</span>
                                        </span>
                                    </button>
                                    
                                    <button onClick={() => onMenuAction && onMenuAction('PRACTICE')} className="w-full py-3 bg-[#1a1512]/80 border border-[#3e2b22] text-[#c5a059] font-bold tracking-[0.2em] hover:bg-[#2a201c] hover:border-[#8c6239] transition-all">小试牛刀</button>
                                    <button onClick={() => onMenuAction && onMenuAction('HOME')} className="w-full py-2 text-[#8c6239] text-xs hover:text-[#a0a0a0] transition-colors mt-2">返回主页</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* --- TEACHING BOARD (Ongoing) --- */}
            {!isComplete && step && (
                <div 
                    className={`absolute w-[92%] max-w-2xl transition-all duration-700 transform pointer-events-auto 
                    ${isInteractive ? 'scale-95 opacity-90 top-[8%] translate-y-4' : 
                      isSettlementReview ? 'scale-90 opacity-100 top-[5%] translate-y-0' : 'scale-100 opacity-100 top-[8%]'}
                    `}
                >
                    <div className="flex items-start gap-0 relative">
                        <div className="relative z-20 flex flex-col items-center -mr-6 mt-4">
                            <div className="w-24 h-24 rounded-full border-[3px] border-[#c5a059] bg-[#1a100a] shadow-[0_10px_30px_rgba(0,0,0,0.6)] overflow-hidden relative group">
                                <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_30%,rgba(255,255,255,0.1),transparent)] pointer-events-none z-10"></div>
                                <GrandpaAvatar />
                            </div>
                            <div className="bg-[#5c0b00] text-gilded text-[10px] px-3 py-1 rounded-[2px] border border-[#c5a059] -mt-3 shadow-md tracking-widest font-black relative z-30 transform -rotate-2">
                                授业恩师
                            </div>
                        </div>

                        <div className="flex-1 relative">
                            <div className={`border-[2px] border-[#5c3a21] rounded-sm shadow-[0_20px_60px_rgba(0,0,0,0.5),inset_0_0_40px_rgba(0,0,0,0.3)] relative overflow-hidden transition-colors duration-500 ${isSettlementReview ? 'bg-black/40 backdrop-blur-sm' : 'bg-black/80'}`}>
                                <div className="absolute inset-0 opacity-20 pointer-events-none mix-blend-overlay" style={{ backgroundImage: HUANGHUALI_TEXTURE }}></div>
                                <div className="absolute top-0 right-0 w-32 h-32 opacity-10 pointer-events-none bg-no-repeat" style={{ backgroundImage: CLOUD_PATTERN }}></div>
                                <div className="absolute bottom-0 left-0 w-32 h-32 opacity-10 pointer-events-none bg-no-repeat transform rotate-180" style={{ backgroundImage: CLOUD_PATTERN }}></div>

                                <div className="p-6 md:p-8 pl-10 relative z-10">
                                    <div className="flex justify-between items-start mb-4 border-b border-[#3e2b22]/50 pb-2">
                                        <div className="flex flex-col">
                                            <span className="text-[#8c6239] text-[9px] font-bold tracking-[0.4em] uppercase opacity-70">
                                                {isInteractive ? "PRACTICE" : "LESSON"}
                                            </span>
                                            <span className="text-gilded text-sm font-black tracking-[0.2em] mt-1">
                                                {isInteractive ? "请君试手" : "听师一言"}
                                            </span>
                                        </div>
                                        <div className="w-8 h-8 opacity-40 border border-[#8c1c0b] rounded-sm flex items-center justify-center rotate-12">
                                            <span className="text-[#8c1c0b] text-[8px] font-bold">教谕</span>
                                        </div>
                                    </div>

                                    {/* [FIX] Cleaned up text container, removed heavy borders/shadows */}
                                    <div className="pl-2">
                                        {parseMessage(step.message)}
                                    </div>

                                    {isInteractive && (
                                        <div className="mt-6 flex items-center gap-3 animate-pulse bg-[#2a1b15]/70 p-2 rounded border border-[#3e2b22]/50">
                                            <span className="text-xl">👇</span> 
                                            <span className="text-gilded text-xs font-bold tracking-wider">请操作手牌以继续 (Play Hand)</span>
                                        </div>
                                    )}

                                    {(step.waitForClick) && (
                                        <div className="mt-6 flex justify-end relative z-50">
                                            <button 
                                                onClick={onNext}
                                                className="group relative px-8 py-2 bg-[#8c1c0b] border border-[#c5a059] shadow-[0_4px_10px_rgba(0,0,0,0.5)] hover:shadow-[0_4px_15px_rgba(197,160,89,0.3)] transition-all active:translate-y-0.5 cursor-pointer"
                                            >
                                                <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/black-felt.png')] opacity-20 mix-blend-multiply"></div>
                                                <span className="relative z-10 text-gilded text-sm font-black tracking-[0.3em]">谨受教</span>
                                            </button>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};
