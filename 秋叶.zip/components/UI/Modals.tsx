
import React, { useState, useEffect } from 'react';
import { Card, ScoreResult, Player, KaiChongDetail, SupportedLanguage } from '../../types';
import { GameSettings } from '../../hooks/useGameSettings';
import CardComponent from '../Card';
import { TRANSLATIONS } from '../../constants'; 
import { useSkin } from '../../contexts/SkinContext';
import { upsertUserProfile } from '../../services/cloudService';
import { UIState } from '../../hooks/useUIState';
import { StylizedButton, ImperialWindow } from './Shared'; 

// Legacy Map - Fallback only
const KC_TYPE_MAP: Record<string, string> = {
    'TONG': '十同', 
    'BROTHER': '兄弟冲', 
    'SHUANG_LIN': '双胞胎', 
    'SHUN_LING': '顺领冲', 
    'DAN_CHONG': '单冲', 
    'JIAN_LING': '间领冲',
    'TE_DENG': '特等冲',
    'OTHER': '开冲'
};

// [VISUAL] Emerald Style for standard wins
const EMERALD_TEXT_CLASS = "text-[#34d399] drop-shadow-[0_0_3px_rgba(52,211,153,0.4)]";

const getFlagEmoji = (countryCode: string = 'CN') => {
    const codePoints = countryCode.toUpperCase().split('').map(char =>  127397 + char.charCodeAt(0));
    return String.fromCodePoint(...codePoints);
};

const AntiqueHandle = ({ isOpen }: { isOpen: boolean }) => (
    <div className="relative flex items-center justify-center w-12 h-6 md:w-16 md:h-8 group">
        <div className="absolute w-full h-[1px] bg-gradient-to-r from-transparent via-[#8c6239]/40 to-transparent"></div>
        <div className={`relative flex items-center justify-center w-6 h-6 md:w-8 md:h-8 rounded-full border border-[#c5a059]/30 bg-[#0c0806] shadow-[0_0_15px_rgba(0,0,0,0.8)] transition-all duration-700 ${isOpen ? 'scale-110 border-[#c5a059] bg-[#1a100a]' : 'group-hover:border-[#c5a059]/60'}`}>
            <svg viewBox="0 0 100 100" className={`w-3 h-3 md:w-4 md:h-4 text-[#c5a059] transition-transform duration-700 ${isOpen ? 'rotate-180' : ''}`}>
                <path d="M20,35 L50,65 L80,35" fill="none" stroke="currentColor" strokeWidth="10" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <div className={`absolute -inset-1 border border-[#c5a059]/20 rounded-full animate-pulse-slow ${isOpen ? 'opacity-100' : 'opacity-0'}`}></div>
        </div>
    </div>
);

const GildedArrow = () => (
    <div className="relative flex items-center justify-center w-8 h-8 md:w-10 md:h-10 opacity-60 group-hover:opacity-100 transition-opacity shrink-0">
        <div className="absolute inset-0 border-[1px] border-[#8c6239]/30 rounded-full scale-75"></div>
        <svg viewBox="0 0 100 100" className="w-4 h-4 md:w-5 md:h-5">
            <path d="M30,20 L70,50 L30,80" fill="none" stroke="#c5a059" strokeWidth="6" strokeLinecap="round" />
        </svg>
    </div>
);

const KaiChongVisualRow: React.FC<{ detail: KaiChongDetail, isBanker: boolean }> = React.memo(({ detail, isBanker }) => {
    const categoryName = detail.description || KC_TYPE_MAP[detail.matchType] || detail.matchType;
    const scoreVal = detail.score || 0;
    
    const scoreClass = scoreVal > 0 
        ? (isBanker ? 'text-gilded' : EMERALD_TEXT_CLASS) 
        : (scoreVal < 0 ? 'text-copper' : 'text-silver');

    return (
        <div className="relative group flex items-center gap-4 md:gap-6 py-5 px-6 md:px-10 bg-gradient-to-r from-transparent via-[#ffd700]/[0.02] to-transparent hover:via-[#ffd700]/[0.05] transition-all border-b border-white/[0.02]">
            <div className="absolute left-0 top-2 bottom-2 w-[3px] bg-gradient-to-b from-transparent via-[#ffdb7a]/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
            
            <div className="w-28 md:w-40 shrink-0 flex flex-col justify-center">
                <span className="text-sm md:text-base text-gilded font-black tracking-widest font-serif leading-none truncate" title={categoryName}>{categoryName}</span>
            </div>
            
            <div className="flex-1 flex items-center justify-center gap-3 md:gap-6 px-2 min-w-0">
                <div className="flex -space-x-4 hover:-space-x-1 transition-all duration-500 perspective-[500px] py-1">
                    {detail.sourceCards.map((c, i) => (
                        <div key={i} className="w-12 h-18 md:w-14 md:h-20 transform hover:-translate-y-2 hover:rotate-2 transition-transform duration-300 shrink-0 border border-white/10 rounded-[2px] bg-transparent shadow-none">
                            <CardComponent 
                                card={c} 
                                isHand={false} 
                                isSmall={true} 
                                isLocked 
                                isInverted={false} 
                                className="w-full h-full !shadow-none !border-black/20" 
                                textLayout="vertical" 
                            />
                        </div>
                    ))}
                </div>
                <GildedArrow />
                <div className="w-12 h-18 md:w-14 md:h-20 relative group shrink-0 perspective-[500px] mt-2">
                    <div className="w-full h-full border border-[#c5a059]/30 rounded-[2px] transform group-hover:scale-110 transition-transform bg-transparent shadow-none">
                        <CardComponent 
                            card={detail.matchedCard} 
                            isHand={false} 
                            isSmall={true} 
                            isLocked 
                            isInverted={true} 
                            className="w-full h-full !shadow-none !border-black/20" 
                            textLayout="vertical" 
                        />
                    </div>
                </div>
            </div>
            
            <div className="w-20 md:w-28 text-right shrink-0 flex justify-end">
                <span className={`font-mono text-xl md:text-2xl font-black ${scoreClass} drop-shadow-md`}>
                    {scoreVal > 0 ? '+' : ''}{scoreVal}
                </span>
            </div>
        </div>
    );
});

const SettlementDetailRow = React.memo(({ name, cards, score, remark, invertedIds = [], category, isBanker }: any) => {
    if ((!cards || cards.length === 0) && (!score || score === 0)) return null;
    
    const isSeYang = category === 'SE_YANG' || category === 'KC_SE_YANG' || category === 'DUO_JIN';
    
    let scoreColor = 'text-silver';
    if (score > 0) {
        if (isBanker || isSeYang) scoreColor = 'text-gilded';
        else scoreColor = EMERALD_TEXT_CLASS;
    } else if (score < 0) {
        scoreColor = 'text-copper';
    }

    return (
        <div className="group flex items-center gap-4 py-4 px-6 md:px-10 hover:bg-white/[0.03] transition-colors border-b border-white/[0.02] last:border-0 relative">
            <div className="w-28 md:w-40 shrink-0">
                <span className="text-xs md:text-sm text-gilded font-bold tracking-widest uppercase font-serif block truncate" title={name}>{name}</span>
                {remark && <div className="text-[9px] text-[#8c6239] mt-1 opacity-70 tracking-wide truncate font-medium">{remark}</div>}
            </div>
            
            <div className="flex-1 flex flex-wrap gap-2 items-center min-h-[56px]">
                {cards && cards.length > 0 ? (
                    cards.map((c: Card, i: number) => (
                        <div key={`${c.id}-${i}`} className="w-10 h-15 md:w-11 md:h-16 shrink-0 transition-all duration-300 group-hover:-translate-y-1 border border-white/10 bg-transparent rounded-[2px] shadow-none">
                            <CardComponent 
                                card={c} 
                                isHand={false} 
                                isSmall={true} 
                                isLocked 
                                isInverted={false} 
                                className="w-full h-full !shadow-none !border-black/20" 
                                textLayout="vertical" 
                            />
                        </div>
                    ))
                ) : (
                    <div className="h-px w-12 bg-white/10 ml-2"></div>
                )}
            </div>
            
            <div className="w-20 md:w-28 text-right shrink-0 flex justify-end">
                <span className={`font-mono text-xl font-black ${scoreColor}`}>
                    {score > 0 ? '+' : ''}{score || 0}
                </span>
            </div>
        </div>
    );
});

const ScorePill = ({ label, raw, settled, isLast, id, isBanker }: any) => {
    const isSeYang = label.includes('色') || label.includes('Pattern');
    
    let settledColor = 'text-silver';
    if (settled > 0) {
        if (isBanker || isSeYang) settledColor = 'text-gilded';
        else settledColor = EMERALD_TEXT_CLASS;
    } else if (settled < 0) {
        settledColor = 'text-copper';
    }

    return (
        <div id={id} className={`flex flex-col h-full px-2 md:px-4 py-2 min-w-[70px] md:min-w-[85px] relative group`}>
            {!isLast && <div className="absolute right-0 top-3 bottom-3 w-px bg-gradient-to-b from-transparent via-[#8c6239]/30 to-transparent"></div>}
            <div className="text-center pb-2 relative z-10">
                <span className="text-[9px] md:text-[10px] text-embossed font-black tracking-widest uppercase font-serif opacity-90 transition-colors">{label}</span>
            </div>
            <div className="flex flex-col justify-end flex-1 gap-2 relative z-10">
                <div className="h-6 flex items-center justify-center">
                    <span className={`font-mono text-xs md:text-sm font-bold ${raw !== 0 ? 'text-silver' : 'text-[#333]'}`}>{raw || 0}</span>
                </div>
                <div className="h-px w-full bg-gradient-to-r from-transparent via-[#8c6239]/20 to-transparent"></div>
                <div className="h-6 flex items-center justify-center">
                    <span className={`font-mono text-sm md:text-base font-black ${settledColor}`}>{settled > 0 ? '+' : ''}{settled || 0}</span>
                </div>
            </div>
        </div>
    );
};

export const ScoreModal = ({ results, onNextRound, onHome, bankerId, language, players, isTutorialMode }: any) => {
    const t = (key: string) => TRANSLATIONS[language as SupportedLanguage]?.[key] || TRANSLATIONS['en'][key];
    const [expandedIds, setExpandedIds] = useState<Set<number>>(new Set(results.map((r: any) => r.playerId)));
    const COIN_RATE = 10; 

    useEffect(() => {
        const humanRes = results.find((r: any) => r.playerId === 0);
        if (humanRes && humanRes.totalRoundChange !== 0) {
            const coinDelta = humanRes.totalRoundChange * COIN_RATE;
            upsertUserProfile({ coins: Math.max(0, (players[0].profile?.coins || 0) + coinDelta) });
        }
    }, []); 

    const headerButtons = !isTutorialMode ? (
        <div className="hidden md:flex gap-4">
            <StylizedButton onClick={onHome} className="w-36 border-[#5c3a21] text-[#8c6239] hover:text-[#a0a0a0] text-xs">
                返回主页
            </StylizedButton>
            <StylizedButton onClick={onNextRound} className="w-40 bg-[#3d0e0e] border-[#c5a059] text-[#ffd700] text-xs">
                下一局 ➔
            </StylizedButton>
        </div>
    ) : undefined;

    return (
        <div className="fixed inset-0 z-[500] bg-black/90 backdrop-blur-sm flex items-center justify-center p-2 md:p-8 font-serif animate-fade-in">
            <ImperialWindow 
                title="博弈總賬" 
                headerContent={headerButtons}
                onClose={!isTutorialMode ? onHome : undefined} 
                className="w-full md:max-w-[90vw] lg:max-w-7xl h-full max-h-[92vh]"
            >
                <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-4 md:space-y-6 custom-scrollbar bg-[#080605] relative">
                    <div className="absolute inset-0 pointer-events-none opacity-5 bg-[radial-gradient(circle_at_center,#fff_1px,transparent_1px)] [background-size:24px_24px] z-0"></div>
                    
                    {results.map((res: ScoreResult) => {
                        const player = players.find((p: any) => p.id === res.playerId);
                        const isExpanded = expandedIds.has(res.playerId);
                        const isWinner = res.totalRoundChange > 0;
                        const isLoser = res.totalRoundChange < 0;
                        const isBanker = res.playerId === bankerId;
                        const coinChange = res.totalRoundChange * COIN_RATE;
                        
                        const totalScoreColor = res.totalRoundChange > 0 
                            ? (isBanker ? 'text-gilded' : EMERALD_TEXT_CLASS) 
                            : (res.totalRoundChange < 0 ? 'text-copper' : 'text-silver');

                        return (
                            <div key={res.playerId} className={`relative flex flex-col bg-[#0e0a08] rounded-[4px] border transition-all duration-700 overflow-hidden z-10 ${isWinner ? 'border-[#c5a059]/40 shadow-[0_10px_40px_rgba(0,0,0,0.8),inset_0_0_20px_rgba(197,160,89,0.1)]' : 'border-[#3e2b22]/30 shadow-md'} ${isExpanded ? 'bg-[#120e0c]' : 'hover:bg-[#120e0c]'}`}>
                                <div className={`flex items-center p-4 md:p-5 cursor-pointer transition-colors duration-500 relative ${isExpanded ? 'bg-white/[0.02]' : ''}`} onClick={() => { const next = new Set(expandedIds); if (next.has(res.playerId)) next.delete(res.playerId); else next.add(res.playerId); setExpandedIds(next); }}>
                                    {isWinner && <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-emerald-600 to-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.6)]"></div>}
                                    {isLoser && <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-red-700 to-red-500 shadow-[0_0_15px_rgba(220,38,38,0.6)]"></div>}
                                    
                                    <div className="relative shrink-0 mr-5 md:mr-8 pl-3">
                                        <div className={`w-14 h-14 md:w-18 md:h-18 rounded-full p-0.5 ${isBanker ? 'bg-gradient-to-br from-[#8c1c0b] to-[#450a0a] ring-2 ring-[#ffd700] shadow-[0_0_25px_rgba(140,28,11,0.5)]' : 'bg-[#1a1a1a] ring-1 ring-[#5c3a21]'}`}>
                                            <img src={player?.profile?.avatar_url || `https://api.dicebear.com/9.x/miniavs/svg?seed=${player?.name}`} className="w-full h-full rounded-full object-cover filter contrast-110 saturate-0 hover:saturate-100 transition-all duration-700" />
                                            {isBanker && <div className="absolute -top-1 -right-1 bg-[#8c1c0b] text-[#ffd700] text-[9px] px-1.5 py-0.5 rounded-sm border border-[#d4af37] font-black z-20 shadow-md font-serif tracking-widest">莊</div>}
                                        </div>
                                    </div>
                                    <div className="w-24 md:w-40 shrink-0 flex flex-col justify-center">
                                        <span className={`text-sm md:text-lg font-black tracking-widest block truncate font-serif ${isWinner ? 'text-gilded' : 'text-silver'}`}>{player?.name}</span>
                                        <div className="flex items-center gap-2 mt-1">
                                            <span className="text-base leading-none filter drop-shadow-md">{getFlagEmoji(player?.profile?.country)}</span>
                                            <span className="text-[9px] text-[#8c6239] uppercase font-mono tracking-widest opacity-80">#{res.playerId.toString().padStart(3, '0')}</span>
                                            {res.penaltyAdjustment !== 0 && (<span className="text-[8px] bg-red-900/40 text-red-300 px-1 rounded border border-red-800/50">罚</span>)}
                                        </div>
                                    </div>
                                    
                                    <div className="flex-1 hidden md:flex items-stretch justify-center overflow-x-auto gap-2 px-4 hide-scrollbar">
                                        <ScorePill id={`score-pill-diao-${res.playerId}`} label="吊數" raw={res.diaoPointChange} settled={res.diaoSettled} isBanker={isBanker} />
                                        <ScorePill label="開注" raw={res.kaiZhuPointChange} settled={res.kaiZhuSettled} isBanker={isBanker} />
                                        <ScorePill label="敲門" raw={res.qiaoMenPointChange} settled={res.qiaoMenSettled} isBanker={isBanker} />
                                        <ScorePill label="色樣" raw={res.seYangPointChange} settled={res.seYangSettled} isBanker={isBanker} />
                                        <ScorePill label="開衝" raw={res.kaiChongPointChange} settled={res.kaiChongSettled} isLast isBanker={isBanker} />
                                    </div>
                                    <div className="flex-1 md:hidden"></div> 

                                    <div className="text-right w-24 md:w-32 shrink-0 mr-4 md:mr-6 flex flex-col justify-center items-end gap-1">
                                        <div className="flex flex-col items-end">
                                            <span className="text-[8px] text-[#8c6239] uppercase tracking-widest opacity-60">TOTAL</span>
                                            <span className={`text-2xl md:text-3xl font-black font-mono tracking-tighter ${totalScoreColor}`}>{res.totalRoundChange > 0 ? '+' : ''}{res.totalRoundChange}</span>
                                        </div>
                                        <div className={`text-xs font-bold flex items-center gap-1 ${coinChange > 0 ? 'text-gilded' : (coinChange < 0 ? 'text-copper' : 'text-silver')}`}><span>{coinChange > 0 ? '+' : ''}{coinChange}</span><span className="text-[9px] border rounded-full px-1 border-current opacity-70">文</span></div>
                                    </div>
                                    <div className="shrink-0"><AntiqueHandle isOpen={isExpanded} /></div>
                                </div>

                                <div className={`transition-all duration-700 ease-in-out ${isExpanded ? 'max-h-[1200px] opacity-100' : 'max-h-0 opacity-0'} bg-[#080605] relative`}>
                                    <div className="absolute inset-x-0 top-0 h-8 bg-gradient-to-b from-black/60 to-transparent pointer-events-none z-10"></div>
                                    <div className="h-px w-full bg-gradient-to-r from-transparent via-[#8c6239]/20 to-transparent"></div>
                                    
                                    <div className="flex flex-col py-6 relative z-0">
                                        <div className="md:hidden grid grid-cols-5 gap-1 px-4 mb-6 border-b border-[#3e2b22]/30 pb-4">
                                            <ScorePill id={`score-pill-diao-m-${res.playerId}`} label="吊數" raw={res.diaoPointChange} settled={res.diaoSettled} isBanker={isBanker} />
                                            <ScorePill label="開注" raw={res.kaiZhuPointChange} settled={res.kaiZhuSettled} isBanker={isBanker} />
                                            <ScorePill label="敲門" raw={res.qiaoMenPointChange} settled={res.qiaoMenSettled} isBanker={isBanker} />
                                            <ScorePill label="色樣" raw={res.seYangPointChange} settled={res.seYangSettled} isBanker={isBanker} />
                                            <ScorePill label="開衝" raw={res.kaiChongPointChange} settled={res.kaiChongSettled} isLast isBanker={isBanker} />
                                        </div>

                                        <SettlementDetailRow name="得桌牌组" cards={res.visibleTrickCards} remark={`共获 ${res.trickCount} 墩`} score={res.diaoSettled} isBanker={isBanker} category="DIAO" />
                                        {res.kaiChongDetails.length > 0 && (<div className="my-2 border-y border-[#3e2b22]/30 bg-white/[0.01]">{res.kaiChongDetails.map((kcd, i) => <KaiChongVisualRow key={i} detail={kcd} isBanker={isBanker} />)}</div>)}
                                        {res.patternDetails.map((pd, i) => <SettlementDetailRow key={i} name={pd.name} cards={pd.cards} score={pd.score} category={pd.category} isBanker={isBanker} />)}
                                        {res.penaltyAdjustment !== 0 && (
                                            <div className="my-6 mx-8 md:mx-16 p-4 md:p-6 bg-[#3d0e0e]/30 border border-red-900/40 rounded-sm flex flex-col md:flex-row justify-between items-center gap-4 relative overflow-hidden shadow-inner">
                                                <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/diagmonds-light.png')] opacity-10 mix-blend-overlay"></div>
                                                <div className="flex items-center gap-3 relative z-10"><div className="w-8 h-8 rounded-full border border-red-500/50 flex items-center justify-center text-red-500 font-black text-xs bg-black/40">罚</div><div className="flex flex-col"><span className="text-copper font-bold uppercase tracking-[0.2em] text-xs">违例包赔 / PENALTY</span><span className="text-red-300/60 text-[10px] mt-1">{res.penaltyReason}</span></div></div>
                                                <span className="font-mono text-3xl text-copper font-black drop-shadow-[0_0_10px_red] relative z-10">{res.penaltyAdjustment}</span>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>
                
                {!isTutorialMode && (
                    <div className="md:hidden p-4 border-t border-[#3e2b22]/50 bg-[#0c0806] flex justify-end gap-3 shrink-0 relative z-20">
                        <StylizedButton onClick={onHome} className="flex-1 border-[#5c3a21] text-[#8c6239] hover:text-[#a0a0a0]">返回主页</StylizedButton>
                        <StylizedButton onClick={onNextRound} className="flex-1 bg-[#3d0e0e] border-[#c5a059] text-gilded">下一局 ➔</StylizedButton>
                    </div>
                )}
            </ImperialWindow>
            {isTutorialMode && (
                <style>{`
                    @keyframes blinkPill { 0%, 100% { border-color: transparent; background: transparent; } 50% { border-color: #ffd700; background: rgba(255, 215, 0, 0.15); } }
                    #score-pill-diao-0, #score-pill-diao-1, #score-pill-diao-m-0, #score-pill-diao-m-1 {
                        transition: all 0.5s;
                        border: 2px solid transparent;
                        border-radius: 4px;
                        animation: blinkPill 1.5s infinite;
                    }
                `}</style>
            )}
        </div>
    );
};

export const SettingsModal: React.FC<{ onClose: () => void, onOpenAdmin: () => void, settings: GameSettings, ui: UIState, gameData: any }> = ({ onClose, onOpenAdmin, settings, ui, gameData }) => {
    const [activeTab, setActiveTab] = useState<'GENERAL' | 'GAMEPLAY' | 'MASTER' | 'THEME'>('GENERAL');
    const { skin, setSkinId, availableSkins } = useSkin();
    
    // [FIX] Update Tab Button Style to use solid gold color for active state ensuring visibility against dark patina background
    const renderTabButton = (id: 'GENERAL' | 'GAMEPLAY' | 'MASTER' | 'THEME', label: string) => (
        <button 
            onClick={() => setActiveTab(id)}
            className={`flex-1 py-4 text-[10px] md:text-xs font-bold tracking-[0.2em] transition-all relative whitespace-nowrap overflow-hidden group 
                ${activeTab === id 
                    ? 'text-[#ffd700] bg-black/40 border-b-2 border-[#ffd700] shadow-[0_4px_10px_rgba(0,0,0,0.5)]' 
                    : 'text-[#8c6239] hover:text-[#c5a059] hover:bg-white/[0.02]'}`}
        >
            <span className="relative z-10 drop-shadow-md">{label}</span>
            {activeTab === id && (
                <>
                    <div className="absolute bottom-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#ffd700] to-transparent opacity-80"></div>
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#ffd700]/5 pointer-events-none"></div>
                </>
            )}
        </button>
    );

    const ToggleRow = ({ label, value, onChange, desc }: any) => (
        <div className="flex items-center justify-between py-3 border-b border-[#3e2b22]/30 hover:bg-white/[0.02] transition-colors px-2 rounded-sm">
            <div className="flex flex-col">
                <span className="text-embossed text-xs font-bold tracking-wider">{label}</span>
                {desc && <span className="text-[10px] text-[#8c6239] mt-1">{desc}</span>}
            </div>
            <button 
                onClick={() => onChange(!value)}
                className={`w-12 h-6 rounded-full p-1 transition-all duration-500 relative shadow-inner border border-[#3e2b22] ${value ? 'bg-[#2a1b15]' : 'bg-[#0a0807]'}`}
            >
                <div className={`w-4 h-4 rounded-full shadow-md transition-all duration-500 transform ${value ? 'translate-x-6 bg-[#c5a059] shadow-[0_0_10px_#c5a059]' : 'translate-x-0 bg-[#5c4033]'}`}></div>
            </button>
        </div>
    );

    const SelectInput = ({ value, onChange, options }: any) => (
        <div className="relative group">
            <select 
                value={value} 
                onChange={onChange}
                className="appearance-none bg-[#0a0807] border border-[#3e2b22] text-[#c5a059] text-xs pl-4 pr-8 py-2 rounded-sm outline-none focus:border-[#c5a059] focus:shadow-[0_0_10px_rgba(197,160,89,0.2)] transition-all cursor-pointer w-full"
            >
                {options.map((opt: any) => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
            </select>
            <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-[#8c6239] text-[10px]">▼</div>
        </div>
    );

    return (
        <div className="fixed inset-0 z-[1200] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 font-serif animate-fade-in">
            <ImperialWindow title="系统设置" onClose={onClose} width="w-full max-w-lg" height="max-h-[85vh]">
                <div className="flex border-b border-[#3e2b22]/50 bg-[#0f0a08] shrink-0">
                    {renderTabButton('GENERAL', '常规')}
                    {renderTabButton('GAMEPLAY', '操控')}
                    {renderTabButton('THEME', '外观')}
                    {renderTabButton('MASTER', '智能')}
                </div>

                <div className="p-6 space-y-6 overflow-y-auto custom-scrollbar relative">
                    
                    {activeTab === 'GENERAL' && (
                        <div className="space-y-6 animate-fade-in">
                            <div className="space-y-2">
                                <span className="text-[#8c6239] text-[10px] font-bold tracking-widest uppercase">Language / 语言</span>
                                <SelectInput 
                                    value={settings.language} 
                                    onChange={(e: any) => settings.setLanguage(e.target.value)}
                                    options={[
                                        { value: "zh_CN", label: "简体中文" },
                                        { value: "zh_TW", label: "繁體中文" },
                                        { value: "en", label: "English" },
                                        { value: "ja", label: "日本語" },
                                        { value: "ko", label: "한국어" }
                                    ]}
                                />
                            </div>

                            <div className="space-y-2">
                                <span className="text-[#8c6239] text-[10px] font-bold tracking-widest uppercase">Graphics Quality</span>
                                <SelectInput 
                                    value={settings.graphicsQuality} 
                                    onChange={(e: any) => settings.setGraphicsQuality(e.target.value)}
                                    options={[
                                        { value: "HIGH", label: "高 (High) - PC推荐" },
                                        { value: "MEDIUM", label: "中 (Med) - 平衡" },
                                        { value: "LOW", label: "低 (Low) - 极速/省电" }
                                    ]}
                                />
                            </div>

                            <ToggleRow 
                                label="背景音效 (Audio)" 
                                desc="包含环境音、BGM与出牌音效"
                                value={!settings.isMuted} 
                                onChange={(val: boolean) => settings.setIsMuted(!val)} 
                            />
                        </div>
                    )}

                    {activeTab === 'GAMEPLAY' && (
                        <div className="space-y-4 animate-fade-in">
                            <ToggleRow label="风控警示 (Risk Alert)" desc="当操作可能违例(包赔)时弹出警告" value={settings.isRiskAlertOn} onChange={settings.setIsRiskAlertOn} />
                            <ToggleRow label="一键出牌 (One-Click Play)" desc="点击卡牌直接打出，无需二次确认" value={settings.oneClickPlay} onChange={settings.setOneClickPlay} />
                            <ToggleRow label="显示牌谱 (Suit History)" desc="记录各花色已出牌情况" value={settings.showSuitHistory} onChange={settings.setShowSuitHistory} />
                            
                            <div className="pt-4 border-t border-[#3e2b22]/30 space-y-2">
                                <span className="text-[#8c6239] text-[10px] font-bold tracking-widest uppercase">规则引擎 (Rule Engine)</span>
                                <div className="flex gap-3">
                                    <button onClick={() => settings.setRuleEngineVersion('V1_CLASSIC')} className={`flex-1 py-2 text-[10px] border rounded-sm transition-all ${settings.ruleEngineVersion === 'V1_CLASSIC' ? 'bg-[#c5a059] text-black border-[#c5a059] shadow-md' : 'bg-transparent text-[#8c6239] border-[#3e2b22] hover:border-[#c5a059]'}`}>V1 经典版</button>
                                    <button onClick={() => settings.setRuleEngineVersion('V2_HIGH_COURSE')} className={`flex-1 py-2 text-[10px] border rounded-sm transition-all ${settings.ruleEngineVersion === 'V2_HIGH_COURSE' ? 'bg-[#c5a059] text-black border-[#c5a059] shadow-md' : 'bg-transparent text-[#8c6239] border-[#3e2b22] hover:border-[#c5a059]'}`}>V2 高课程</button>
                                </div>
                                <p className="text-[9px] text-[#555] leading-relaxed">* V2 引擎基于《马吊高课程》古籍训练，包含更复杂的“漏庄”与“纵趣”判定。</p>
                            </div>
                        </div>
                    )}

                    {activeTab === 'THEME' && (
                        <div className="space-y-4 animate-fade-in">
                            <div className="grid grid-cols-2 gap-3">
                                {availableSkins.map(s => (
                                    <button 
                                        key={s.id}
                                        onClick={() => setSkinId(s.id)}
                                        className={`relative p-3 border text-left transition-all overflow-hidden group rounded-sm ${skin.id === s.id ? 'border-[#c5a059] bg-[#1a100a] shadow-[0_0_15px_rgba(197,160,89,0.2)]' : 'border-[#3e2b22] bg-[#0a0807] hover:border-[#8c6239]'}`}
                                    >
                                        <div className="flex items-center justify-between mb-2">
                                            <span className={`text-xs font-bold ${skin.id === s.id ? 'text-[#c5a059]' : 'text-[#8c6239] group-hover:text-[#a0a0a0]'}`}>{s.name}</span>
                                            {skin.id === s.id && <div className="w-2 h-2 bg-[#c5a059] rounded-full shadow-[0_0_5px_#c5a059]"></div>}
                                        </div>
                                        <div className="h-10 w-full rounded-sm shadow-inner relative overflow-hidden" style={{ background: s.layout.tableBaseColor }}>
                                            <div className="absolute inset-0 opacity-20 bg-gradient-to-br from-white to-transparent"></div>
                                        </div>
                                    </button>
                                ))}
                            </div>
                        </div>
                    )}

                    {activeTab === 'MASTER' && (
                        <div className="space-y-6 animate-fade-in">
                            <div className="bg-[#1a100a] p-4 rounded-sm border border-[#3e2b22] relative overflow-hidden">
                                <div className="absolute top-0 right-0 p-2 opacity-10 text-4xl">🎙️</div>
                                <p className="text-[10px] text-[#8c6239] leading-relaxed relative z-10">
                                    “马吊导师”会通过语音（TTS）为您讲解牌局。语音数据首次生成后将自动**录音并持久化**至本地，无需重复消耗流量。
                                </p>
                            </div>

                            <div className="space-y-2">
                                <span className="text-[#8c6239] text-[10px] font-bold tracking-widest uppercase">指导频率</span>
                                <SelectInput 
                                    value={settings.masterFrequency} 
                                    onChange={(e: any) => settings.setMasterFrequency(e.target.value)}
                                    options={[
                                        { value: "HIGH", label: "话唠 (High) - 频繁提示" },
                                        { value: "NORMAL", label: "适中 (Normal) - 关键时刻" },
                                        { value: "LOW", label: "高冷 (Low) - 仅限违例" }
                                    ]}
                                />
                            </div>
                            
                            <div className="pt-4 border-t border-[#3e2b22]/30">
                                <button onClick={onOpenAdmin} className="w-full py-3 bg-[#3d0e0e]/50 border border-[#5c1010] text-[#a0a0a0] hover:text-[#e6c278] hover:bg-[#3d0e0e] transition-colors text-xs font-bold tracking-[0.2em] flex items-center justify-center gap-2 rounded-sm shadow-inner group">
                                    <span className="group-hover:animate-pulse">后台管理</span>
                                    <span className="text-[9px] opacity-60 font-mono text-red-900 group-hover:text-red-500">(ADMIN)</span>
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            </ImperialWindow>
        </div>
    );
};
