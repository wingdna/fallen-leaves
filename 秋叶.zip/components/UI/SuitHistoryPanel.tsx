
import React, { useMemo } from 'react';
import { Card, Suit, CardRank } from '../../types';
import { HUANGHUALI_TEXTURE } from './Shared';

interface SuitHistoryPanelProps {
    recordedCards: Card[];
    visible: boolean;
}

const SUIT_LABELS: Record<Suit, string> = {
    [Suit.CASH]: '十',
    [Suit.STRINGS]: '貫',
    [Suit.COINS]: '索',
    [Suit.TEXTS]: '文'
};

// Define full ranges for display
const SUIT_RANGES: Record<Suit, number[]> = {
    [Suit.CASH]: [11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1],
    [Suit.STRINGS]: [9, 8, 7, 6, 5, 4, 3, 2, 1],
    [Suit.COINS]: [9, 8, 7, 6, 5, 4, 3, 2, 1],
    [Suit.TEXTS]: [11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1] // Wen range is 11 down to 1
};

export const SuitHistoryPanel: React.FC<SuitHistoryPanelProps> = ({ recordedCards, visible }) => {
    if (!visible) return null;

    const history = useMemo(() => {
        const map: Record<Suit, Set<number>> = {
            [Suit.CASH]: new Set(),
            [Suit.STRINGS]: new Set(),
            [Suit.COINS]: new Set(),
            [Suit.TEXTS]: new Set()
        };
        recordedCards.forEach(c => map[c.suit].add(c.value));
        return map;
    }, [recordedCards]);

    const renderSuitRow = (suit: Suit) => {
        const playedValues = history[suit];
        const allValues = SUIT_RANGES[suit];
        
        return (
            <div key={suit} className="flex items-center gap-2 mb-1.5 last:mb-0 relative">
                {/* Suit Seal */}
                <div className="w-4 h-4 flex items-center justify-center bg-[#1a0505] text-[#8c6239] text-[9px] font-serif font-black rounded-[1px] shadow-[inset_0_1px_2px_rgba(0,0,0,0.8)] border border-[#3e2b22]/50 opacity-80">
                    {SUIT_LABELS[suit]}
                </div>
                
                {/* Dots Track - High Density Zitan Inlay */}
                <div className="flex-1 flex gap-[2px] items-center justify-start bg-[#080202] px-1 py-0.5 rounded-[1px] shadow-[inset_0_1px_3px_black] border-b border-[#3e2b22]/20 h-4">
                    {allValues.map(val => {
                        const isPlayed = playedValues.has(val);
                        // Important cards get special colors
                        let dotColor = isPlayed ? 'bg-[#555]' : 'bg-[#1a1a1a]';
                        let glow = '';
                        
                        if (isPlayed) {
                            if (suit === Suit.CASH) {
                                if (val >= 9) { dotColor = 'bg-[#8c1c0b]'; glow = 'shadow-[0_0_2px_#ef4444]'; } 
                                else if (val === 1) { dotColor = 'bg-[#047857]'; glow = 'shadow-[0_0_2px_#10b981]'; } 
                                else dotColor = 'bg-[#c5a059]'; 
                            } else if (suit === Suit.TEXTS) {
                                if (val >= 10) { dotColor = 'bg-[#8c1c0b]'; glow = 'shadow-[0_0_2px_#ef4444]'; } 
                                else if (val === 1) { dotColor = 'bg-[#047857]'; glow = 'shadow-[0_0_2px_#10b981]'; } 
                                else dotColor = 'bg-[#c5a059]';
                            } else {
                                if (val >= 8) { dotColor = 'bg-[#8c1c0b]'; glow = 'shadow-[0_0_2px_#ef4444]'; } 
                                else if (val === 1) { dotColor = 'bg-[#047857]'; glow = 'shadow-[0_0_2px_#10b981]'; } 
                                else dotColor = 'bg-[#c5a059]';
                            }
                        }

                        return (
                            <div key={val} className={`w-1.5 h-1.5 rounded-full ${dotColor} ${glow} transition-all duration-500 ${isPlayed ? 'scale-110 opacity-100' : 'opacity-30'}`} title={val.toString()}></div>
                        );
                    })}
                </div>
            </div>
        );
    };

    return (
        // [VISUAL UPDATE] Adjusted Top offset to top-[8.5rem] (~136px) to sit below the new Music Mini-Bar
        <div className="absolute top-[8.5rem] left-4 z-[150] w-[180px] animate-fade-in pointer-events-none select-none scale-90 origin-top-left">
            {/* Embedded Zitan Block (Inset into wall) */}
            <div className="relative bg-[#0f0404] p-2 rounded-[2px] shadow-[inset_0_2px_5px_rgba(0,0,0,0.8),0_1px_0_rgba(255,255,255,0.05)] border-b border-white/5 overflow-hidden">
                
                {/* Internal Grain Texture */}
                <div className="absolute inset-0 opacity-20 mix-blend-overlay pointer-events-none" 
                     style={{ backgroundImage: HUANGHUALI_TEXTURE, backgroundSize: '100px 100px' }}></div>

                {/* Content */}
                <div className="flex flex-col relative z-10">
                    {([Suit.CASH, Suit.STRINGS, Suit.COINS, Suit.TEXTS] as Suit[]).map(renderSuitRow)}
                </div>
            </div>
        </div>
    );
};
