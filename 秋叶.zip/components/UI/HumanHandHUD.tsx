
import React, { useRef, useState, useEffect, useCallback } from 'react';
import CardComponent from '../Card';
import { Card } from '../../types';
import { useSkin } from '../../contexts/SkinContext';
import { useLayoutEngine } from '../../hooks/useLayoutEngine'; 

const DEFAULT_AVATAR = "https://api.dicebear.com/9.x/miniavs/svg?seed=Me";

export const HumanHandHUD = React.memo(({ player, isMyTurn, onCardClick, onDragPlay, onPlayConfirm, selectedCardId, highlightedCardIds, cardMarkers, oneClickPlay, canInteract, actionLabel }: any) => {
    const { skin } = useSkin();
    const layoutConfig = useLayoutEngine();
    const handConfig = layoutConfig.hand;
    
    const dragStateRef = useRef<{id: string, startX: number, startY: number, currentX: number, currentY: number} | null>(null);
    const [draggingId, setDraggingId] = useState<string | null>(null); 
    const [dragTransform, setDragTransform] = useState<{x: number, y: number} | null>(null);
    const [activeFocusId, setActiveFocusId] = useState<string | null>(null);
    const [windowWidth, setWindowWidth] = useState(typeof window !== 'undefined' ? window.innerWidth : 375);

    useEffect(() => {
        const handleResize = () => setWindowWidth(window.innerWidth);
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    const handleActionClick = useCallback(() => {
        if (!canInteract) return;
        if (selectedCardId) onPlayConfirm(selectedCardId);
        else if (highlightedCardIds?.size > 0) onPlayConfirm(Array.from(highlightedCardIds)[0]);
        else if (player?.hand.length > 0) onPlayConfirm(player.hand[0].id);
    }, [canInteract, selectedCardId, highlightedCardIds, player?.hand, onPlayConfirm]);

    const handleStart = (clientX: number, clientY: number, cardId: string) => {
        // [FIX]: Check if card is strictly disabled by tutorial highlights
        if (highlightedCardIds && highlightedCardIds.size > 0 && !highlightedCardIds.has(cardId)) return;
        
        if (!canInteract) return;
        dragStateRef.current = { id: cardId, startX: clientX, startY: clientY, currentX: clientX, currentY: clientY };
        if (handConfig.type !== 'fan') setActiveFocusId(cardId);
        else { setDraggingId(cardId); setDragTransform({ x: 0, y: 0 }); }
    };

    useEffect(() => {
        const handleMove = (e: MouseEvent | TouchEvent) => {
            if (!dragStateRef.current) return;
            let clientX = 0, clientY = 0;
            if ('touches' in e) { clientX = e.touches[0].clientX; clientY = e.touches[0].clientY; } 
            else { clientX = (e as MouseEvent).clientX; clientY = (e as MouseEvent).clientY; }
            dragStateRef.current.currentX = clientX;
            dragStateRef.current.currentY = clientY;

            if (handConfig.type !== 'fan') {
                const el = document.elementFromPoint(clientX, clientY);
                const hitId = el?.closest('[data-card-id]')?.getAttribute('data-card-id');
                if (hitId && hitId !== activeFocusId) setActiveFocusId(hitId);
            } else {
                setDragTransform({ x: clientX - dragStateRef.current.startX, y: clientY - dragStateRef.current.startY });
            }
        };
        const handleEnd = () => {
            if (dragStateRef.current) {
                const { id, startY, currentY } = dragStateRef.current;
                const targetId = (handConfig.type !== 'fan' && activeFocusId) ? activeFocusId : id;
                if (currentY - startY < -60) onDragPlay(targetId);
                else onCardClick(targetId);
                dragStateRef.current = null; setDraggingId(null); setDragTransform(null); setActiveFocusId(null);
            }
        };
        window.addEventListener('mousemove', handleMove);
        window.addEventListener('touchmove', handleMove, { passive: false });
        window.addEventListener('mouseup', handleEnd);
        window.addEventListener('touchend', handleEnd);
        return () => {
            window.removeEventListener('mousemove', handleMove); window.removeEventListener('touchmove', handleMove);
            window.removeEventListener('mouseup', handleEnd); window.removeEventListener('touchend', handleEnd);
        };
    }, [onDragPlay, onCardClick, activeFocusId, handConfig.type]);

    if (!player) return null;

    const handSize = player.hand.length;

    const getBasePosition = (i: number) => {
        const CARD_WIDTH_REM = handConfig.cardWidthRem;
        const PIXELS_PER_REM = 16;
        const CARD_WIDTH_PX = CARD_WIDTH_REM * PIXELS_PER_REM;
        
        if (handConfig.type === 'spread_center' || handConfig.type === 'spread_justify') {
            const factor = handConfig.overlapFactor ?? 0.2; 
            const step = CARD_WIDTH_PX * (1 - factor); 
            const totalWidth = (handSize - 1) * step + CARD_WIDTH_PX;
            const startX = -(totalWidth / 2) + (CARD_WIDTH_PX / 2);
            const xOffset = startX + i * step;
            
            return { x: xOffset, y: 0, rot: 0, zIndex: 100 + i, width: `${CARD_WIDTH_REM}rem`, marginLeft: `-${CARD_WIDTH_REM/2}rem`, bottom: handConfig.bottomOffset };
        }

        const radius = handConfig.arcRadius || 1000;
        const baseAngle = handConfig.maxFanAngle || 15;
        const dynamicMaxAngle = handSize > 4 ? baseAngle : (baseAngle * (handSize / 5));
        const angleStep = handSize > 1 ? (dynamicMaxAngle * 2) / (handSize - 1) : 0;
        const startAngle = -dynamicMaxAngle;
        const angle = startAngle + i * angleStep;
        
        const rad = (angle * Math.PI) / 180;
        const tx = Math.sin(rad) * radius;
        const ty = (1 - Math.cos(rad)) * radius;

        return { x: tx, y: ty, rot: angle, zIndex: 100 + i, width: `${CARD_WIDTH_REM}rem`, marginLeft: `-${CARD_WIDTH_REM/2}rem`, bottom: handConfig.bottomOffset };
    };

    const isActive = isMyTurn && canInteract;
    const hudPositionClass = layoutConfig.hud.Bottom?.style || "bottom-[200px] left-1/2 -translate-x-1/2";
    const isBaiLao = player.isBaiLaoRevealed || player.isSuspectedBaiLao;

    return (
        <div className="fixed inset-0 pointer-events-none z-[500] overflow-visible">
            
            <div className="absolute inset-0 pointer-events-none" style={{ transform: 'translateZ(-100px)' }}>
                <div 
                    className={`absolute ${hudPositionClass} z-[50] flex flex-col items-center pointer-events-auto transition-all duration-300 ${isActive ? 'cursor-pointer' : 'cursor-default grayscale-[0.8] opacity-80'}`}
                    onClick={isActive ? handleActionClick : undefined}
                    style={{ transformOrigin: 'center bottom' }}
                >
                    <div className={`relative flex items-center h-20 px-5 rounded-full border-[3px] transition-colors duration-300 ${isActive ? 'border-[#c5a059] bg-gradient-to-r from-[#2d0a0a] via-[#5c1010] to-[#0a0505] shadow-[0_30px_60px_rgba(0,0,0,0.9),0_0_20px_rgba(197,160,89,0.3)] active:scale-[0.98]' : 'border-white/10 bg-black/80 shadow-[0_10px_20px_rgba(0,0,0,0.4)]'}`}>
                        {isActive && <div className="absolute inset-0 rounded-full overflow-hidden"><div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover:animate-shine pointer-events-none"></div></div>}
                        <div className="relative shrink-0 mr-6">
                            <div className={`w-14 h-14 rounded-full border-2 overflow-hidden shadow-[0_0_15px_rgba(0,0,0,0.8)] relative z-10 bg-black transition-all duration-300 ${isActive ? 'border-[#c5a059]' : 'border-[#3e2b22]/40'}`}>
                                <img src={player.profile?.avatar_url || DEFAULT_AVATAR} className={`w-full h-full object-cover transition-all duration-300 ${isActive ? 'grayscale-0 contrast-125' : 'grayscale opacity-60'}`} />
                            </div>
                            <div className="absolute -top-1 -right-1 flex flex-col gap-0.5">
                                {player.isDealer && <div className="w-5 h-5 bg-[#8c1c0b] border border-[#c5a059] rounded-full flex items-center justify-center z-20 shadow-md"><span className="text-[9px] text-[#ffd700] font-serif font-black">庄</span></div>}
                                {isBaiLao && <div className="w-5 h-5 bg-[#047857] border border-[#34d399] rounded-full flex items-center justify-center z-20 shadow-md"><span className="text-[9px] text-[#e8e4d9] font-serif font-black">百</span></div>}
                            </div>
                        </div>
                        <div className="pr-4 flex flex-col justify-center min-w-[120px] items-center">
                            <span className={`font-calligraphy transition-colors duration-300 text-center drop-shadow-[0_4px_6px_rgba(0,0,0,0.8)] select-none text-4xl md:text-5xl tracking-[0.4em] ${isActive ? 'text-[#ffdb7a]' : 'text-[#8c6239]'}`}>{isActive ? (actionLabel || "发牌") : "静思"}</span>
                        </div>
                    </div>
                    <div className={`absolute top-full left-1/2 -translate-x-1/2 w-[2px] transition-all duration-500 ${isActive ? 'h-10 bg-gradient-to-b from-[#c5a059] to-transparent opacity-40 mt-2' : 'h-0 opacity-0'}`}></div>
                </div>
            </div>

            {/* Hand Container */}
            <div className={`absolute left-1/2 w-full flex justify-center items-end pointer-events-none transition-opacity duration-300 ${isActive ? 'opacity-85 hover:opacity-100' : 'opacity-100'}`} 
                 style={{ transform: 'translateX(-50%)', bottom: '0px', height: '0px', zIndex: 400 }}>
                {player.hand.map((card: Card, i: number) => {
                    const pos = getBasePosition(i);
                    const markers = cardMarkers?.[card.id] || { isMature: false, isForbidden: false };
                    
                    const isSuggested = highlightedCardIds?.has(card.id);
                    // [FIX]: Determine dimming logic: If highlights exist AND card is NOT highlighted, it is disabled.
                    const isDimmed = highlightedCardIds && highlightedCardIds.size > 0 && !isSuggested;
                    
                    const isVisuallySelected = selectedCardId === card.id || draggingId === card.id;
                    const liftY = isVisuallySelected ? -70 : 0; 
                    const finalZIndex = isVisuallySelected ? 1000 : pos.zIndex;

                    // [VISUAL FIX]: Apply explicit filter to wrapper to force grayscale visual
                    const dimStyle = isDimmed ? { filter: 'grayscale(100%) brightness(0.4) opacity(0.6)' } : {};

                    return (
                        <div key={card.id} data-card-id={card.id}
                             className={`absolute pointer-events-auto transition-all duration-300 ease-out ${isDimmed ? 'cursor-not-allowed' : 'cursor-pointer'}`} 
                             style={{ 
                                left: '50%', bottom: pos.bottom, width: pos.width, marginLeft: pos.marginLeft,
                                transformOrigin: 'center bottom',
                                transform: `translate3d(${pos.x}px, ${pos.y + liftY}px, 0px) rotateZ(${pos.rot}deg) rotateX(${handConfig.tiltX}deg) scale(${isVisuallySelected ? 1.25 : 1})`,
                                zIndex: finalZIndex,
                                ...dimStyle // Apply grayscale filter
                             }}
                             onMouseDown={(e) => !isDimmed && handleStart(e.clientX, e.clientY, card.id)}
                             onTouchStart={(e) => !isDimmed && handleStart(e.touches[0].clientX, e.touches[0].clientY, card.id)}
                        >
                            <CardComponent 
                                card={card} 
                                isHand 
                                isSelected={isVisuallySelected} 
                                suitStatus={markers.isMature ? 'SAFE' : (markers.isForbidden ? 'FORBIDDEN' : 'NEUTRAL')} 
                                isSuggested={isSuggested}
                                isDisabled={isDimmed} // [FIX]: Pass disabled state to Card component for grayscale effect
                                className="w-full h-full" 
                            />
                        </div>
                    );
                })}
            </div>
        </div>
    );
});
