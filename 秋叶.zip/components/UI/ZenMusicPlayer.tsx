
import React, { useState, useEffect, useRef } from 'react';
import { audioManager } from '../../services/audioManager';
import { ZEN_PLAYLIST, getReplacementTrack, ZenTrack } from '../../services/audioAssets';
import { HUANGHUALI_TEXTURE, StylizedButton } from './Shared';
import { sysEvents } from '../../services/eventBus';

export const ZenMusicPlayer: React.FC = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [currentTrackId, setCurrentTrackId] = useState<string | null>(null);
    const [isPlaying, setIsPlaying] = useState(false);
    const [loadingTrackId, setLoadingTrackId] = useState<string | null>(null);
    const [failedTrackIds, setFailedTrackIds] = useState<Set<string>>(new Set());
    
    // Dynamic Playlist State
    const [playlist, setPlaylist] = useState<ZenTrack[]>(ZEN_PLAYLIST);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const currentTrack = playlist.find(t => t.id === currentTrackId) || playlist[0];

    // Initial check
    useEffect(() => {
        if (playlist.length > 0 && !currentTrackId) {
            setCurrentTrackId(playlist[0].id);
        }
    }, [playlist]);

    // Subscribe to Audio Errors - Auto Remove & Refill Logic
    useEffect(() => {
        const unbind = sysEvents.on('AUDIO_ERROR', (payload) => {
            const failedUrl = payload.url;
            // Match by URL since ID might be dynamic
            const track = playlist.find(t => failedUrl.includes(t.url) || t.url === failedUrl);
            
            if (track) {
                console.warn(`[ZenPlayer] Track failed: ${track.name}, Auto-Removing...`);
                setFailedTrackIds(prev => new Set(prev).add(track.id));
                setLoadingTrackId(null);
                
                // 1. Remove failed track
                setPlaylist(prevPlaylist => {
                    const filtered = prevPlaylist.filter(t => t.id !== track.id);
                    
                    // 2. Refill with new track from pool
                    const currentUrls = new Set(filtered.map(t => t.url));
                    const replacement = getReplacementTrack(currentUrls);
                    if (replacement) {
                        console.log(`[ZenPlayer] Auto-added replacement: ${replacement.name}`);
                        filtered.push(replacement);
                    }
                    return filtered;
                });

                // 3. Play Next Track if current one failed
                if (currentTrackId === track.id) {
                    setIsPlaying(false);
                    // Use timeout to allow state update
                    setTimeout(() => {
                        handleNext(); 
                    }, 500);
                }
            }
        });
        return () => unbind();
    }, [playlist, currentTrackId]);

    const playTrack = (track: ZenTrack) => {
        if (failedTrackIds.has(track.id)) return;
        
        setLoadingTrackId(track.id);
        setCurrentTrackId(track.id);
        setIsPlaying(true);
        audioManager.switchMusic(track.url);
        
        // Optimistic clear loading after delay
        setTimeout(() => {
            setLoadingTrackId(curr => curr === track.id ? null : curr);
        }, 800);
    };

    const handleTogglePlay = async (track?: ZenTrack) => {
        const target = track || currentTrack;
        if (!target) return;

        if (currentTrackId === target.id) {
            // Toggle Play/Pause
            if (isPlaying) {
                audioManager.pauseBGM();
                setIsPlaying(false);
            } else {
                audioManager.resumeBGM();
                setIsPlaying(true);
            }
        } else {
            // Switch Track
            playTrack(target);
        }
    };

    const handleNext = () => {
        setPlaylist(currentList => {
            if (currentList.length === 0) return [];
            
            // Re-find index in case playlist updated
            let idx = currentList.findIndex(t => t.id === currentTrackId);
            if (idx === -1) idx = 0; // Fallback
            
            let attempts = 0;
            let nextIdx = (idx + 1) % currentList.length;
            
            // Skip failed tracks logic (though they should be removed)
            while (failedTrackIds.has(currentList[nextIdx].id) && attempts < currentList.length) {
                nextIdx = (nextIdx + 1) % currentList.length;
                attempts++;
            }
            
            if (attempts < currentList.length) {
                playTrack(currentList[nextIdx]);
            }
            return currentList;
        });
    };

    const handleDelete = (trackId: string, e: React.MouseEvent) => {
        e.stopPropagation();
        
        // If deleting current track, play next first
        if (currentTrackId === trackId) {
            handleNext();
        }

        const newPlaylist = playlist.filter(t => t.id !== trackId);
        
        // Pass current playlist URLs to prevent duplicate content
        const currentUrls = new Set<string>(newPlaylist.map(t => t.url));
        const replacement = getReplacementTrack(currentUrls);
        
        if (replacement) {
            newPlaylist.push(replacement);
        }

        setPlaylist(newPlaylist);
        // Clean up failed set if deleting a failed track
        if (failedTrackIds.has(trackId)) {
            setFailedTrackIds(prev => {
                const next = new Set(prev);
                next.delete(trackId);
                return next;
            });
        }
    };

    const handleUploadClick = () => {
        fileInputRef.current?.click();
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        if (!file.type.startsWith('audio/')) {
            alert("仅支持音频文件 (Only audio files allowed)");
            return;
        }

        // Create Blob URL (Local Only, Safe)
        const objectUrl = URL.createObjectURL(file);
        
        const newTrack: ZenTrack = {
            id: `custom_${Date.now()}`,
            name: `📂 ${file.name.substring(0, 15)}...`,
            desc: '本地上传 (Local Upload)',
            url: objectUrl,
            isCustom: true,
            region: 'NATURE'
        };

        // Add to top and play immediately
        setPlaylist(prev => [newTrack, ...prev]);
        playTrack(newTrack);
        
        // Reset input
        e.target.value = '';
    };

    return (
        <div className="fixed top-[4.5rem] left-4 z-[1100] flex flex-col items-start font-serif scale-90 origin-top-left select-none">
            
            {/* 1. The Mini Player Bar (Zitan Embedded Style) */}
            <div className="relative w-48 h-10 rounded-[2px] overflow-hidden flex items-center bg-[#0f0404] shadow-[inset_0_2px_5px_rgba(0,0,0,0.8),0_1px_0_rgba(255,255,255,0.05)] border-b border-white/5 group transition-all duration-300 hover:bg-[#1a0505]">
                
                {/* Texture */}
                <div className="absolute inset-0 opacity-20 pointer-events-none mix-blend-overlay" style={{ backgroundImage: HUANGHUALI_TEXTURE, backgroundSize: '100px 100px' }}></div>

                {/* Play/Pause Button */}
                <button 
                    onClick={() => handleTogglePlay()} 
                    className="w-10 h-full flex items-center justify-center border-r border-[#3e2b22]/30 hover:bg-[#3e2b22] transition-colors relative z-10"
                    title={isPlaying ? "暂停 (Pause)" : "播放 (Play)"}
                >
                    {loadingTrackId ? (
                        <div className="w-3 h-3 border border-t-transparent border-[#c5a059] rounded-full animate-spin"></div>
                    ) : (
                        <span className={`text-[12px] ${isPlaying ? 'text-[#c5a059] animate-pulse' : 'text-[#8c6239]'}`}>
                            {isPlaying ? '❚❚' : '▶'}
                        </span>
                    )}
                </button>

                {/* Track Info (Click to open list) */}
                <div 
                    onClick={() => setIsOpen(!isOpen)}
                    className="flex-1 px-3 flex items-center gap-2 cursor-pointer h-full relative z-10 overflow-hidden"
                >
                    <div className="flex flex-col justify-center min-w-0">
                        <span className={`text-[10px] ${failedTrackIds.has(currentTrackId || '') ? 'text-red-500' : 'text-[#8c6239] group-hover:text-[#e6c278]'} transition-colors truncate font-bold tracking-wide block leading-none`}>
                            {failedTrackIds.has(currentTrackId || '') ? "加载失败 (自动切换中...)" : (currentTrack?.name || "选择曲目")}
                        </span>
                    </div>
                </div>

                {/* Playlist Toggle Icon */}
                <button 
                    onClick={() => setIsOpen(!isOpen)}
                    className={`w-8 h-full flex items-center justify-center hover:text-[#c5a059] transition-colors relative z-10 ${isOpen ? 'text-[#c5a059] bg-[#3e2b22]/50' : 'text-[#555]'}`}
                >
                    <span className="text-[8px]">▼</span>
                </button>
            </div>

            {/* 2. Expanded Playlist Panel (Dropdown) */}
            <div className={`
                absolute top-full mt-1 left-0 w-64 bg-[#0a0807]/95 backdrop-blur-xl border border-[#3e2b22] rounded-sm overflow-hidden transition-all duration-300 origin-top shadow-[0_20px_50px_rgba(0,0,0,0.9)] flex flex-col z-[1200]
                ${isOpen ? 'opacity-100 scale-100 translate-y-0 pointer-events-auto' : 'opacity-0 scale-95 -translate-y-2 pointer-events-none'}
            `}>
                <div className="absolute inset-0 opacity-10 pointer-events-none mix-blend-overlay" style={{ backgroundImage: HUANGHUALI_TEXTURE }}></div>
                
                {/* List Header */}
                <div className="p-2 border-b border-[#3e2b22]/50 bg-[#15100e] flex justify-between items-center shrink-0">
                    <div className="text-[#c5a059] text-[10px] font-bold tracking-[0.1em] flex items-center gap-1">
                        <span>🎐</span> 听松·梵音
                    </div>
                    <button 
                        onClick={handleUploadClick}
                        className="text-[9px] text-[#8c6239] hover:text-[#c5a059] border border-[#3e2b22] px-1.5 py-0.5 rounded hover:border-[#c5a059] transition-colors flex items-center gap-1"
                        title="上传本地音频 (无版权风险)"
                    >
                        <span>+</span> 本地
                    </button>
                    <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="audio/*" className="hidden" />
                </div>

                {/* List Area */}
                <div className="flex-1 overflow-y-auto custom-scrollbar p-1 max-h-[220px] bg-[#0c0806]">
                    {playlist.map((track) => {
                        const isActive = currentTrackId === track.id;
                        const isFailed = failedTrackIds.has(track.id);

                        return (
                            <div 
                                key={track.id}
                                onClick={() => !isFailed && handleTogglePlay(track)}
                                className={`
                                    relative flex items-center justify-between p-1.5 rounded-sm transition-all group overflow-hidden cursor-pointer mb-[1px]
                                    ${isActive ? 'bg-[#1a100a] border-l-2 border-[#c5a059]' : 'hover:bg-[#1a100a]/50 border-l-2 border-transparent'}
                                    ${isFailed ? 'opacity-50 grayscale' : ''}
                                `}
                            >
                                <div className="flex-1 min-w-0 pr-2">
                                    <div className="flex items-center gap-2">
                                        <span className={`text-[10px] font-bold truncate ${isFailed ? 'text-red-500' : (isActive ? 'text-[#e6c278]' : 'text-[#8c6239] group-hover:text-[#a0a0a0]')} transition-colors`}>
                                            {isFailed ? `❌ ${track.name}` : track.name}
                                        </span>
                                    </div>
                                    {!isFailed && (
                                        <div className="text-[8px] text-[#555] truncate group-hover:text-[#777]">{track.desc}</div>
                                    )}
                                </div>

                                {/* Delete / Remove Button */}
                                <button 
                                    onClick={(e) => handleDelete(track.id, e)}
                                    className={`w-5 h-5 flex items-center justify-center text-[9px] rounded hover:bg-[#3e2b22] hover:text-red-400 text-[#444] transition-all opacity-0 group-hover:opacity-100`}
                                    title="移除并补充新曲 (Remove & Refill)"
                                >
                                    ✕
                                </button>
                            </div>
                        );
                    })}
                </div>
            </div>

        </div>
    );
};
