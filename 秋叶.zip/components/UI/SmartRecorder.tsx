
import React, { useState, useEffect } from 'react';
import { StylizedButton, HUANGHUALI_TEXTURE } from './Shared';

// Interface matching the hook return type
export interface RecorderState {
    isRecording: boolean;
    isPaused: boolean;
    timer: number;
    config: any;
    updateConfig: (cfg: any) => void;
    startRecording: () => Promise<void>;
    stopRecording: () => void;
    pauseRecording: () => void;
    resumeRecording: () => void;
    prepareStream: () => Promise<boolean>;
    error: string | null;
}

interface SmartRecorderSetupProps {
    onClose: () => void;
    recorder: RecorderState;
}

export const SmartRecorderOverlay: React.FC<{ recorder: RecorderState }> = ({ recorder }) => {
    if (!recorder.isRecording && !recorder.isPaused) return null;

    const formatTime = (seconds: number) => {
        const m = Math.floor(seconds / 60);
        const s = seconds % 60;
        return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    };

    return (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[1300] flex items-center gap-4 px-6 py-3 bg-[#0a0807]/90 border border-[#3e2b22] rounded-full shadow-[0_10px_30px_rgba(0,0,0,0.8)] animate-fade-in-down backdrop-blur-md">
            <div className={`w-3 h-3 rounded-full ${recorder.isPaused ? 'bg-yellow-500 animate-none' : 'bg-red-500 animate-pulse'}`}></div>
            <span className="text-[#e8e4d9] font-mono font-bold text-lg tracking-widest">{formatTime(recorder.timer)}</span>
            
            <div className="h-6 w-px bg-white/20 mx-2"></div>
            
            {recorder.isPaused ? (
                <button onClick={recorder.resumeRecording} className="text-[#c5a059] hover:text-white text-xs font-bold uppercase tracking-wider">RESUME</button>
            ) : (
                <button onClick={recorder.pauseRecording} className="text-[#c5a059] hover:text-white text-xs font-bold uppercase tracking-wider">PAUSE</button>
            )}
            
            <button onClick={recorder.stopRecording} className="w-8 h-8 flex items-center justify-center bg-red-900/50 hover:bg-red-700/50 rounded-full border border-red-500/30 transition-colors">
                <div className="w-3 h-3 bg-white rounded-sm"></div>
            </button>
        </div>
    );
};

export const SmartRecorderSetup: React.FC<SmartRecorderSetupProps> = ({ onClose, recorder }) => {
    const { config, updateConfig, prepareStream, startRecording, error } = recorder;
    const [startDelay, setStartDelay] = useState(0); 
    const [countingDown, setCountingDown] = useState(false);
    const [countDownVal, setCountDownVal] = useState(0);

    const handleStart = async () => {
        const streamSuccess = await prepareStream();
        if (!streamSuccess) return;

        if (startDelay > 0) {
            setCountingDown(true);
            setCountDownVal(startDelay);
            
            const intv = setInterval(() => {
                setCountDownVal(prev => {
                    if (prev <= 1) {
                        clearInterval(intv);
                        setCountingDown(false);
                        startRecording();
                        onClose();
                        return 0;
                    }
                    return prev - 1;
                });
            }, 1000);
        } else {
            await startRecording();
            onClose();
        }
    };

    if (countingDown) {
        return (
            <div className="fixed inset-0 z-[1300] flex items-center justify-center bg-black/40 backdrop-blur-[2px] animate-fade-in font-serif">
                <div className="text-[#c5a059] text-9xl font-black drop-shadow-[0_0_50px_rgba(197,160,89,0.8)] animate-pulse">
                    {countDownVal}
                </div>
            </div>
        );
    }

    return (
        <div className="fixed inset-0 z-[1200] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 font-serif animate-fade-in">
            <div className="relative w-full max-w-lg bg-[#15100e] border border-[#3e2b22] rounded-sm shadow-[0_0_100px_black] flex flex-col overflow-hidden">
                
                <div className="flex justify-between items-center p-6 border-b border-[#3e2b22] bg-[#0c0806]">
                    <h2 className="text-[#c5a059] text-xl font-bold tracking-[0.3em] flex items-center gap-2">
                        <span className="text-red-500 animate-pulse">●</span> 智能录像配置
                    </h2>
                    <button onClick={onClose} className="text-[#8c6239] hover:text-[#c5a059] transition-colors text-lg">✕</button>
                </div>

                <div className="absolute inset-0 z-[-1] opacity-10 pointer-events-none mix-blend-overlay" style={{ backgroundImage: HUANGHUALI_TEXTURE }}></div>

                <div className="p-8 space-y-6">
                    {error && (
                        <div className="bg-red-900/20 border border-red-500/30 p-3 text-red-400 text-xs rounded-sm mb-4">
                            {error}
                        </div>
                    )}

                    <div className="grid grid-cols-2 gap-6">
                        <div className="space-y-2">
                            <label className="text-[#8c6239] text-[10px] font-bold tracking-wider uppercase">分辨率 (Resolution)</label>
                            <select 
                                value={config.resolution} 
                                onChange={(e) => updateConfig({ resolution: e.target.value as any })}
                                className="w-full bg-[#0a0807] border border-[#3e2b22] text-[#c5a059] text-xs px-3 py-2 rounded-sm outline-none focus:border-[#c5a059]"
                            >
                                <option value="720p">720p (流畅)</option>
                                <option value="1080p">1080p (高清)</option>
                                <option value="4k">4K (影院)</option>
                            </select>
                        </div>
                        <div className="space-y-2">
                            <label className="text-[#8c6239] text-[10px] font-bold tracking-wider uppercase">帧率 (FPS)</label>
                            <div className="flex bg-[#0a0807] border border-[#3e2b22] rounded-sm p-1">
                                {[30, 60].map(fps => (
                                    <button 
                                        key={fps}
                                        onClick={() => updateConfig({ fps })}
                                        className={`flex-1 py-1 text-xs font-bold transition-all ${config.fps === fps ? 'bg-[#3e2b22] text-[#c5a059]' : 'text-[#555]'}`}
                                    >
                                        {fps}
                                    </button>
                                ))}
                            </div>
                        </div>
                    </div>

                    <div className="space-y-2">
                        <label className="text-[#8c6239] text-[10px] font-bold tracking-wider uppercase">自动停止条件</label>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="flex items-center gap-2 bg-[#0a0807] border border-[#3e2b22] px-3 py-2 rounded-sm">
                                <input 
                                    type="number" 
                                    value={config.timeLimit || ''} 
                                    onChange={(e) => updateConfig({ timeLimit: parseInt(e.target.value) || 0 })}
                                    placeholder="∞"
                                    className="w-12 bg-transparent text-[#c5a059] text-xs outline-none text-right placeholder-gray-700"
                                />
                                <span className="text-[#555] text-xs">分钟</span>
                            </div>
                            <div className="flex items-center gap-2 bg-[#0a0807] border border-[#3e2b22] px-3 py-2 rounded-sm opacity-50 cursor-not-allowed" title="暂不支持局数限制">
                                <input 
                                    disabled
                                    type="number" 
                                    placeholder="∞"
                                    className="w-12 bg-transparent text-[#555] text-xs outline-none text-right"
                                />
                                <span className="text-[#555] text-xs">局数</span>
                            </div>
                        </div>
                        <p className="text-[9px] text-[#555] pt-1">* 设为 0 表示不限制时长。</p>
                    </div>

                    <StylizedButton onClick={handleStart} className="w-full py-4 text-lg">
                        开始录制
                    </StylizedButton>
                </div>
            </div>
        </div>
    );
};
