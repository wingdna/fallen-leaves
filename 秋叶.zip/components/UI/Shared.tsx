
import React from 'react';

// --- 升级版黄花梨纹理 (Deep Huanghuali) ---
// 模拟鬼脸纹与包浆层
export const HUANGHUALI_TEXTURE = `
    linear-gradient(115deg, rgba(255,255,255,0.03) 0%, transparent 40%, rgba(255,255,255,0.02) 100%),
    radial-gradient(circle at 30% 20%, rgba(100,50,0,0.1) 0%, transparent 20%), 
    repeating-linear-gradient(45deg, rgba(92,58,33,0.1) 0px, rgba(43,24,16,0.1) 2px, transparent 4px, transparent 12px)
`;

// --- [NEW] 极致御制通用窗口容器 (Extreme Patina Edition) ---
export const ImperialWindow: React.FC<{ 
    children: React.ReactNode, 
    title?: string, 
    onClose?: () => void, 
    className?: string,
    width?: string,
    height?: string,
    headerContent?: React.ReactNode 
}> = ({ children, title, onClose, className = "", width = "max-w-4xl", height = "auto", headerContent }) => {
    return (
        <div className={`relative ${width} ${height} flex flex-col rounded-sm shadow-[0_50px_100px_-10px_rgba(0,0,0,0.9)] overflow-hidden group ${className}`}>
            
            {/* --- 1. 物理材质层 (Physical Material Stack) --- */}
            
            {/* L1: 底漆 (Deep Base) - 极深黑褐 */}
            <div className="absolute inset-0 bg-[#080504] z-0"></div>
            
            {/* L2: 内透光 (Subsurface Glow) - 模拟光线穿透厚漆层 */}
            <div className="absolute inset-0 z-0 bg-[radial-gradient(circle_at_50%_0%,#2a1d15_0%,transparent_70%)] opacity-80"></div>
            
            {/* L3: 纹理 (Grain) - 隐约可见的木纹 */}
            <div className="absolute inset-0 z-0 opacity-20 pointer-events-none mix-blend-overlay" 
                 style={{ backgroundImage: HUANGHUALI_TEXTURE, backgroundSize: '200px 200px' }}></div>
            
            {/* L4: 流光 (Gloss Flow) - 模拟曲面反光 */}
            <div className="absolute inset-0 z-0 bg-gradient-to-tr from-transparent via-white/[0.03] to-transparent pointer-events-none"></div>
            
            {/* L5: 岁月包浆 (Vignette) - 边缘极深 */}
            <div className="absolute inset-0 z-0 shadow-[inset_0_0_80px_rgba(0,0,0,0.95)] pointer-events-none"></div>

            {/* --- 2. 装饰边框 (Decorative Frame) --- */}
            <div className="absolute inset-0 border-[1px] border-[#3e2b22]/50 pointer-events-none z-50 mix-blend-screen"></div>
            <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-[#8c6239]/60 to-transparent z-50"></div>
            <div className="absolute bottom-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-[#8c6239]/60 to-transparent z-50"></div>

            {/* --- 3. 标题栏 (Header) --- */}
            {(title || onClose || headerContent) && (
                <div className="relative z-40 flex items-center justify-between px-6 md:px-8 py-5 border-b border-[#3e2b22]/30 bg-black/20 shrink-0 backdrop-blur-sm">
                    <div className="flex items-center gap-4 relative z-10">
                        {/* 装饰锚点 */}
                        <div className="w-1.5 h-1.5 bg-[#ffd700] rotate-45 opacity-80 shadow-[0_0_5px_#ffd700]"></div>
                        
                        {/* [TEXT BEAUTY] Gilded Title */}
                        <h2 className="text-xl md:text-2xl font-black tracking-[0.3em] font-serif text-[#ffd700] relative drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
                            {title}
                        </h2>
                    </div>

                    {/* Header Actions */}
                    {headerContent && (
                        <div className="flex-1 flex justify-end items-center gap-4 px-8 relative z-10">
                            {headerContent}
                        </div>
                    )}

                    {onClose && (
                        <button 
                            onClick={onClose}
                            className="w-8 h-8 flex items-center justify-center text-[#8c6239] hover:text-[#ffd700] transition-colors duration-300 relative z-10 hover:rotate-90 transform"
                        >
                            <span className="text-xl font-serif">✕</span>
                        </button>
                    )}
                </div>
            )}

            {/* --- 4. 内容区域 (Content) --- */}
            <div className="relative z-10 flex-1 overflow-auto flex flex-col scrollbar-hide" style={{ scrollbarWidth: 'none' }}>
                <style>{` .scrollbar-hide::-webkit-scrollbar { display: none; } `}</style>
                {children}
            </div>
        </div>
    );
};

export const StylizedButton = ({ onClick, children, className = "", disabled, active }: { onClick: () => void, children?: React.ReactNode, className?: string, disabled?: boolean, active?: boolean }) => (
    <button 
        onClick={onClick}
        disabled={disabled}
        className={`
            relative overflow-hidden group
            /* 基础尺寸 */
            h-12 md:h-14 min-w-[200px]
            
            /* 字体设置 */
            font-serif font-black tracking-[0.25em] md:tracking-[0.4em] text-xs md:text-sm
            
            /* Flex 布局 */
            flex items-center justify-center whitespace-nowrap
            
            /* 基础过渡 */
            transition-all duration-500 ease-out

            /* 1. 禁用状态 */
            ${disabled ? 'opacity-40 cursor-not-allowed bg-[#1a1a1a] border-[#333] text-[#555]' : ''}

            /* 2. 默认状态 (未选中): 御制黑漆 (Imperial Black Lacquer) - 深邃黑底 + 古铜金边 */
            ${!disabled && !active ? `
                bg-[#080402] 
                border border-[#3e2b22]
                text-[#8c6239]
                shadow-[inset_0_0_20px_rgba(0,0,0,1),0_4px_10px_rgba(0,0,0,0.8)]
                hover:bg-[#150a08] 
                hover:text-[#c5a059]
                hover:border-[#5c3a21]
                hover:shadow-[inset_0_0_25px_rgba(0,0,0,0.8),0_0_15px_rgba(197,160,89,0.1)]
            ` : ''}

            /* 3. 激活/选中状态: 御制明黄 (Imperial Yellow) - 田黄石/鎏金质感 */
            ${active ? `
                bg-gradient-to-b from-[#ffdb7a] to-[#d4af37]
                border border-[#ffe082]
                text-[#2b1810] /* 深褐色文字，确保高对比度 */
                shadow-[inset_0_2px_5px_rgba(255,255,255,0.4),0_0_20px_rgba(212,175,55,0.4)]
                scale-[1.02]
            ` : ''}

            /* 交互反馈 */
            ${!disabled ? 'active:scale-[0.98]' : ''}

            ${className}
        `}
    >
        {/* 文字阴影处理: 亮色背景(Active)不需要浮雕阴影，暗色背景(Inactive)需要 */}
        <style>{`
            .text-shadow-embossed { text-shadow: 0 -1px 0 rgba(0,0,0,1), 0 1px 0 rgba(255,255,255,0.1); }
        `}</style>

        {/* 材质层 1: 黑漆隐纹 (Black Lacquer Grain) - 仅在未选中时显现 */}
        <div className={`absolute inset-0 z-0 pointer-events-none opacity-20 mix-blend-overlay transition-opacity duration-500 ${active ? 'opacity-0' : 'opacity-20'}`} 
             style={{ backgroundImage: `repeating-linear-gradient(75deg, #222 0, #111 1px, transparent 1px, transparent 4px)` }}></div>

        {/* 材质层 2: 金石纹理 (Gold Stone Texture) - 仅在选中时显现 */}
        <div className={`absolute inset-0 z-0 transition-opacity duration-700 pointer-events-none mix-blend-soft-light opacity-40
            ${active ? 'opacity-40' : 'opacity-0'}`} 
             style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.8' numOctaves='3'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.5'/%3E%3C/svg%3E")` }}></div>
        
        {/* 包浆反光 (Patina Gloss Sweep) */}
        <div className={`absolute inset-0 z-1 pointer-events-none bg-gradient-to-tr from-transparent via-white/[0.2] to-transparent -translate-x-[150%] transition-transform duration-[1000ms] ease-in-out
            ${!disabled && 'group-hover:translate-x-[150%]'}
        `}></div>

        {/* 边框高光 (Rim Light) */}
        <div className={`absolute inset-0 border border-white/10 rounded-sm pointer-events-none transition-opacity duration-300 ${active ? 'opacity-50' : 'opacity-0 group-hover:opacity-30'}`}></div>

        <span className={`relative z-10 flex flex-col items-center leading-none gap-1 ${!active ? 'text-shadow-embossed' : 'drop-shadow-sm'}`}>
            {children}
        </span>
    </button>
);

export const MaXianglanSeal = () => (
    <div className="w-10 h-10 md:w-11 md:h-11 border-2 border-[#5c0b00] bg-[#8c1c0b] rounded-sm shadow-[0_15px_30px_rgba(0,0,0,1)] grid grid-cols-2 grid-rows-2 p-0.5 box-border relative opacity-60 hover:opacity-100 transition-all scale-100 hover:scale-110 grayscale-[0.3] hover:grayscale-0">
        <div className="absolute inset-0 opacity-40 bg-[url('https://www.transparenttextures.com/patterns/black-felt.png')] mix-blend-multiply pointer-events-none z-10"></div>
        <div className="flex items-center justify-center border-b border-r border-[#e8e4d9]/20 relative z-0"><span className="text-[#e8e4d9] font-black text-xs transform scale-x-90 font-serif">蘭</span></div>
        <div className="flex items-center justify-center border-b border-[#e8e4d9]/20 relative z-0"><span className="text-[#e8e4d9] font-black text-xs transform scale-x-90 font-serif">馬</span></div>
        <div className="flex items-center justify-center border-r border-[#e8e4d9]/20 relative z-0"><span className="text-[#e8e4d9] font-black text-xs transform scale-x-90 font-serif">印</span></div>
        <div className="flex items-center justify-center relative z-0"><span className="text-[#e8e4d9] font-black text-xs transform scale-x-90 font-serif">湘</span></div>
    </div>
);
