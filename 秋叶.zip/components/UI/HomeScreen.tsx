
// ... existing imports
import React, { useMemo, useState } from 'react';
import { UserProfile } from '../../types';
import { ISkin } from '../../types/skin';
import { StylizedButton, MaXianglanSeal, HUANGHUALI_TEXTURE } from './Shared';
import { useGameSettings } from '../../hooks/useGameSettings';
import { TutorialMenu } from './TutorialMenu';
import { TUTORIAL_LEVELS } from '../../services/tutorialScenarios';

// ... (Keep RealisticMoon, AncientArtisticPavilion, PlumBlossomZenTop, PlumFlowerNode, PetalStorm unchanged) ...
// (Omitting definitions to save space, preserving context)

const RealisticMoon = () => (
    <div className="absolute top-[6%] right-[8%] w-[15vw] h-[15vw] pointer-events-none z-0">
        <div className="absolute inset-[-180%] rounded-full bg-blue-100/10 blur-[120px] animate-pulse-slow-opacity"></div>
        <div className="absolute inset-[-40%] rounded-full bg-white/5 blur-[40px] animate-spin-slow opacity-60" style={{ backgroundImage: 'conic-gradient(from 0deg, transparent, rgba(255,255,255,0.05), transparent)' }}></div>
        <div className="w-full h-full rounded-full bg-gradient-to-br from-[#ffffff] via-[#e2e8f0] to-[#94a3b8] shadow-[inset_-10px_-10px_40px_rgba(0,0,0,0.4),0_0_100px_rgba(255,255,255,0.15)] border border-white/20 relative overflow-hidden">
            <div className="absolute inset-0 opacity-20 mix-blend-multiply" style={{ backgroundImage: 'radial-gradient(circle at 40% 40%, #1e293b 0%, transparent 60%), radial-gradient(circle at 70% 60%, #1e293b 0%, transparent 40%)' }}></div>
            <div className="absolute inset-0 opacity-[0.03] bg-[url('https://www.transparenttextures.com/patterns/p6.png')]"></div>
        </div>
    </div>
);

const AncientArtisticPavilion = () => (
    <div className="absolute bottom-[-5%] left-[-3%] w-[60vw] h-[60vh] z-10 pointer-events-none">
        <div className="absolute left-[10%] bottom-[20%] w-[130%] h-[130%] bg-[radial-gradient(circle,rgba(255,100,20,0.15)_0%,transparent_75%)] blur-[150px] mix-blend-screen animate-window-breathe"></div>
        <svg viewBox="0 0 1000 800" className="w-full h-full overflow-visible">
            <defs>
                <filter id="atmosphericBlur">
                    <feGaussianBlur stdDeviation="5" />
                    <feColorMatrix type="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 0.85 0" />
                </filter>
                <filter id="windowGlowBloom">
                    <feGaussianBlur stdDeviation="20" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                </filter>
                <filter id="flickerShadow">
                    <feGaussianBlur stdDeviation="12" />
                </filter>
                <radialGradient id="windowGrad" cx="50%" cy="50%" r="50%">
                    <stop offset="0%" stopColor="#ff9f43" />
                    <stop offset="70%" stopColor="#e67e22" />
                    <stop offset="100%" stopColor="#8c1c0b" />
                </radialGradient>
            </defs>
            <g filter="url(#atmosphericBlur)">
                <path d="M0,700 L0,350 L320,420 L320,750 Z" fill="#020100" />
                <path d="M-60,380 Q180,50 450,420 L450,460 Q180,120 -60,420 Z" fill="#050302" />
            </g>
            <g transform="translate(40, 410)">
                <path d="M0,0 L260,55 L260,260 L0,230 Z" fill="url(#windowGrad)" opacity="0.55" filter="url(#windowGlowBloom)" className="animate-window-breathe" />
                <g filter="url(#flickerShadow)" className="mix-blend-multiply opacity-70 animate-candle-flicker-shadow">
                    <ellipse cx="70" cy="180" rx="16" ry="26" fill="#000" />
                    <ellipse cx="140" cy="210" rx="18" ry="30" fill="#000" />
                    <ellipse cx="210" cy="190" rx="16" ry="26" fill="#000" />
                    <rect x="50" y="220" width="180" height="8" fill="#000" />
                </g>
                <g stroke="#0f0a05" strokeWidth="2.5" opacity="0.9">
                    {[0, 52, 104, 156, 208, 260].map(x => (
                        <line key={x} x1={x} y1={x * 0.21} x2={x} y2={230 + x * 0.11} />
                    ))}
                    <line x1="0" y1="115" x2="260" y2="140" />
                </g>
                <path d="M-3,-3 L263,53 L263,263 L-3,233 Z" fill="none" stroke="#020100" strokeWidth="10" />
            </g>
        </svg>
    </div>
);

const PlumBlossomZenTop = () => (
    <div className="absolute top-0 left-0 w-full h-full pointer-events-none z-20 overflow-visible">
        <div className="absolute top-[-8%] right-[-12%] w-[90vw] h-[70vh] animate-branch-sway origin-top-right">
            <svg viewBox="0 0 1000 600" className="w-full h-full drop-shadow-[0_30px_50px_rgba(0,0,0,0.95)]">
                <defs>
                    <linearGradient id="branchGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                        <stop offset="0%" stopColor="#0a0806" />
                        <stop offset="40%" stopColor="#1a1410" />
                        <stop offset="100%" stopColor="#050403" />
                    </linearGradient>
                    <filter id="petalInk">
                        <feTurbulence type="fractalNoise" baseFrequency="0.05" numOctaves="2" result="noise" />
                        <feDisplacementMap in="SourceGraphic" in2="noise" scale="2" />
                    </filter>
                </defs>
                <g opacity="0.98">
                    <path d="M1000,30 Q700,70 500,280 T300,580" fill="none" stroke="url(#branchGrad)" strokeWidth="32" strokeLinecap="round" />
                    <path d="M1000,28 Q702,68 502,278" fill="none" stroke="rgba(255,255,255,0.12)" strokeWidth="1.5" strokeLinecap="round" />
                    <path d="M680,100 Q550,60 400,160" fill="none" stroke="url(#branchGrad)" strokeWidth="12" strokeLinecap="round" />
                    <path d="M520,260 Q400,350 300,480" fill="none" stroke="url(#branchGrad)" strokeWidth="8" strokeLinecap="round" />
                </g>
                <PlumFlowerNode x={680} y={100} r={28} />
                <PlumFlowerNode x={550} y={180} r={22} />
                <PlumFlowerNode x={400} y={160} r={18} />
                <PlumFlowerNode x={320} y={540} r={30} />
                <PlumFlowerNode x={450} y={400} r={20} />
                <PlumFlowerNode x={850} y={60} r={24} />
            </svg>
        </div>
    </div>
);

const PlumFlowerNode = ({ x, y, r }: { x: number, y: number, r: number }) => (
    <g transform={`translate(${x}, ${y})`} filter="url(#petalInk)">
        <defs>
            <radialGradient id={`petalGrad-${x}-${y}`} cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#c0392b" />
                <stop offset="80%" stopColor="#7f1d1d" />
                <stop offset="100%" stopColor="#450a0a" />
            </radialGradient>
        </defs>
        {[0, 72, 144, 216, 288].map((angle) => (
            <path 
                key={angle} 
                d={`M0,0 Q${r*1.4},-${r*0.8} ${r*1.8},0 T0,${r*0.9} Z`} 
                fill={`url(#petalGrad-${x}-${y})`} 
                transform={`rotate(${angle})`} 
                opacity="0.95"
            />
        ))}
        <circle cx="0" cy="0" r={r*0.35} fill="#1a0000" />
        <g opacity="0.7">
            {[0, 45, 90, 135, 180, 225, 270, 315].map(a => (
                <line key={a} x1="0" y1="0" x2={r*0.3} y2="0" stroke="#ffcc00" strokeWidth="0.5" transform={`rotate(${a})`} />
            ))}
        </g>
        <circle cx="0" cy="0" r={r*0.1} fill="#ffd700" />
    </g>
);

const PetalStorm = () => {
    const petals = useMemo(() => Array.from({ length: 22 }).map((_, i) => ({
        id: i,
        left: Math.random() * 100 + '%',
        top: -20 + Math.random() * 40 + '%',
        delay: Math.random() * 25 + 's',
        size: 15 + Math.random() * 30 + 'px', 
        duration: 25 + Math.random() * 25 + 's',
        rotation: Math.random() * 360
    })), []);

    return (
        <div className="absolute inset-0 pointer-events-none z-30">
            {petals.map(p => (
                <div key={p.id} className="absolute animate-petal" style={{
                    left: p.left, top: p.top, width: p.size, height: p.size,
                    animationDelay: p.delay, animationDuration: p.duration
                }}>
                    <svg viewBox="0 0 50 50" className="w-full h-full opacity-30 filter drop-shadow-[0_4px_8px_black]" style={{ transform: `rotate(${p.rotation}deg)` }}>
                        <path d="M25,5 C35,5 45,15 40,35 Q25,45 10,35 C5,15 15,5 25,5 Z" fill={Math.random() > 0.4 ? "#8c1c0b" : "#2d1b1b"} />
                    </svg>
                </div>
            ))}
        </div>
    );
};

interface HomeScreenProps {
    userProfile?: UserProfile;
    skin: ISkin;
    availableSkins: ISkin[];
    setSkinId: (id: string) => void;
    onStartGame: (recordMode: boolean) => void;
    onStartTutorial?: (scenario: any, recordMode: boolean) => void;
    onEnterRoom?: () => void; 
    onNetBattle: () => void;
    onSignOut: () => void;
    t: (key: string) => string;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({ 
    userProfile, skin, availableSkins, setSkinId, 
    onStartGame, onStartTutorial, onNetBattle, onEnterRoom, t 
}) => {
    const { isMobileDevice } = useGameSettings();
    const [showTutorialMenu, setShowTutorialMenu] = useState(false);
    const [isRecordMode, setIsRecordMode] = useState(false);

    const poemLines = [
        "落葉蕭蕭舞亭台", "飛鳥啾啾鬧市街",
        "佛前紅袖斬華髮", "镜中花容攏玉釵",
        "寒夜圍爐花入梦", "暑窗簾卷月沉海",
        "無憂白鶴眠如醉", "有情青竹痴難改",
        "云中仙娥多別離", "塵世兒女少歡愛",
        "断肠总为得失苦", "何如诀别归去来"
    ];

    const columns = useMemo(() => {
        if (isMobileDevice) {
            const pairs = [];
            for (let i = 0; i < poemLines.length; i += 2) {
                pairs.push([poemLines[i], poemLines[i+1]]);
            }
            return pairs;
        }
        return poemLines.map(line => [line]);
    }, [isMobileDevice, poemLines]);

    return (
        <div className="fixed inset-0 z-[300] flex text-[#c5a059] font-serif overflow-hidden transition-all duration-1000 bg-[#010204]">
            {/* 深度渐变暗场 */}
            <div className="absolute inset-0 bg-[#020305]"></div>
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,#0f172a_0%,transparent_60%),radial-gradient(circle_at_20%_80%,#1a0505_0%,transparent_50%)] opacity-60"></div>
            
            <div className={`absolute z-[1] flex flex-row-reverse pointer-events-none opacity-[0.12] overflow-hidden transition-all duration-1000 ${isMobileDevice ? 'right-4 top-8 gap-4' : 'right-16 top-20 gap-10'}`}>
                {columns.map((group, groupIdx) => (
                    <div 
                        key={groupIdx} 
                        className="flex flex-col items-center animate-fade-in" 
                        style={{ 
                            writingMode: 'vertical-rl', 
                            textOrientation: 'upright',
                            animationDelay: `${groupIdx * 0.15}s`
                        }}
                    >
                        {group.map((line, lineIdx) => (
                            <div 
                                key={lineIdx} 
                                className="text-ink-shadow font-calligraphy leading-none mb-12 text-[#2d3748]"
                                style={{ 
                                    fontSize: isMobileDevice ? '3.2vh' : '4vh', 
                                    letterSpacing: '0.4em'
                                }}
                            >
                                {line}
                            </div>
                        ))}
                    </div>
                ))}
            </div>

            <RealisticMoon />
            <AncientArtisticPavilion />
            <PlumBlossomZenTop />
            <PetalStorm />

            {/* 标题区域 */}
            <div className={`absolute z-40 flex flex-col items-start gap-4 ${isMobileDevice ? 'top-10 left-10 scale-90' : 'top-16 left-20'}`}>
                <div className="flex flex-col items-center gap-12">
                    <div className="flex flex-col items-center font-calligraphy text-8xl md:text-9xl font-black text-gilded select-none group"
                         style={{ filter: 'drop-shadow(0 0 30px rgba(197,160,89,0.3))' }}>
                        <span className="drop-shadow-[0_4px_10px_rgba(0,0,0,1)] transition-transform duration-700 group-hover:scale-105">馬</span>
                        <span className="drop-shadow-[0_4px_10px_rgba(0,0,0,1)] transition-transform duration-700 delay-100 group-hover:scale-105">弔</span>
                    </div>
                    <div className="animate-pulse-slow-opacity"><MaXianglanSeal /></div>
                </div>
            </div>

            {/* 操作按钮区 */}
            <div className="absolute inset-x-0 bottom-0 z-50 flex flex-col items-center pb-16 pointer-events-none">
                <div className="flex flex-col gap-4 items-center pointer-events-auto mb-12">
                    {userProfile && (
                        <div className="flex items-center gap-3 px-6 py-2 bg-black/40 border border-[#c5a059]/30 rounded-full backdrop-blur-md mb-2">
                            <span className="text-gilded text-xs font-bold tracking-widest">{userProfile.username}</span>
                            <div className="h-4 w-px bg-white/20"></div>
                            <span className="text-[#ffd700] font-mono font-bold tracking-wider">{userProfile.coins?.toLocaleString() ?? 0}</span>
                            <span className="text-[10px] border border-[#ffd700]/50 rounded-full px-1.5 text-[#ffd700]/80">文</span>
                        </div>
                    )}

                    <StylizedButton onClick={() => onStartGame(isRecordMode)} className="w-72 md:w-[420px] shadow-[0_20px_50px_rgba(0,0,0,0.8)]">
                        {userProfile ? "继续博弈 (RESUME GAME)" : "进入江湖 (ENTER GAME)"}
                    </StylizedButton>
                    
                    {onStartTutorial && (
                        <StylizedButton onClick={() => setShowTutorialMenu(true)} className="w-72 md:w-[420px] shadow-[0_20px_50px_rgba(0,0,0,0.8)]">
                            拜师学艺 (TUTORIAL)
                        </StylizedButton>
                    )}

                    {onEnterRoom && (
                        <StylizedButton onClick={onEnterRoom} className="w-72 md:w-[420px] shadow-[0_20px_50px_rgba(0,0,0,0.8)]">
                            菊间小筑 (PRIVATE ROOM)
                        </StylizedButton>
                    )}
                    
                    {!userProfile && (
                        <StylizedButton onClick={onNetBattle} className="w-72 md:w-[420px] shadow-[0_20px_50px_rgba(0,0,0,0.8)]">
                            因缘小聚 (MATCHMAKING)
                        </StylizedButton>
                    )}
                </div>

                <div className="pointer-events-auto flex items-center gap-4">
                    <div className="flex gap-4 p-5 bg-black/60 backdrop-blur-3xl rounded-full border border-white/10 shadow-2xl scale-90 md:scale-100">
                        {availableSkins.map((s: any) => {
                            const isActive = skin.id === s.id;
                            return (
                                <button
                                    key={s.id}
                                    onClick={() => setSkinId(s.id)}
                                    title={s.name}
                                    className={`
                                        w-8 h-8 md:w-10 md:h-10 rounded-full border-2 transition-all duration-700 relative group overflow-hidden
                                        ${isActive ? 'scale-125 border-[#c5a059] shadow-[0_0_20px_rgba(197,160,89,0.4)] z-10' : 'border-[#3e2b22] opacity-40 hover:opacity-100 hover:scale-110'}
                                    `}
                                    style={{ background: '#0a0807' }}
                                >
                                    <div className={`absolute inset-0 transition-opacity duration-1000 ${isActive ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}
                                         style={{ backgroundImage: HUANGHUALI_TEXTURE, backgroundSize: '100% 100%' }}></div>
                                </button>
                            );
                        })}
                    </div>

                    <button 
                        onClick={() => setIsRecordMode(!isRecordMode)}
                        className={`h-12 w-12 rounded-full border-2 flex items-center justify-center transition-all shadow-xl bg-black/60 backdrop-blur-3xl ${isRecordMode ? 'border-red-500 shadow-[0_0_15px_rgba(220,38,38,0.5)]' : 'border-[#3e2b22] opacity-80'}`}
                        title="战局录制 (30分钟)"
                    >
                        <div className={`w-4 h-4 rounded-sm transition-colors ${isRecordMode ? 'bg-red-500 animate-pulse' : 'bg-[#555]'}`}></div>
                    </button>
                </div>
            </div>

            <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(circle_at_center,transparent_30%,rgba(0,0,0,0.4)_100%)] z-[5]"></div>
            
            {showTutorialMenu && onStartTutorial && (
                <TutorialMenu 
                    onSelectScenario={(s, record) => { setShowTutorialMenu(false); onStartTutorial(s, record); }}
                    onClose={() => setShowTutorialMenu(false)} 
                />
            )}

            <style>{`
                @keyframes petalFall { 0% { transform: translate(0, 0) rotateX(0) rotateY(0) rotateZ(0); opacity: 0; } 10% { opacity: 0.6; } 90% { opacity: 0.2; } 100% { transform: translate(-800px, 1200px) rotateX(1200deg) rotateY(600deg) rotateZ(300deg); opacity: 0; } }
                .animate-petal { animation: petalFall 35s linear infinite; }
                @keyframes windowBreathe { 0%, 100% { opacity: 0.52; filter: blur(18px) brightness(1); } 50% { opacity: 0.58; filter: blur(20px) brightness(1.08); } }
                .animate-window-breathe { animation: windowBreathe 15s ease-in-out infinite; }
                @keyframes candleFlickerShadow { 0%, 100% { transform: scale(1) translate(0,0); opacity: 0.7; } 33% { transform: scale(1.01, 0.99) translate(1px, 0px); opacity: 0.65; } 66% { transform: scale(0.99, 1.01) translate(0px, 1px); opacity: 0.75; } }
                .animate-candle-flicker-shadow { animation: candleFlickerShadow 10s ease-in-out infinite; }
                @keyframes branchSway { 0%, 100% { transform: rotate(0deg) scale(1); } 50% { transform: rotate(0.4deg) scale(1.005); } }
                .animate-branch-sway { animation: branchSway 25s ease-in-out infinite; }
                .animate-pulse-slow-opacity { animation: pulseOpacity 12s ease-in-out infinite; }
                @keyframes pulseOpacity { 0%, 100% { opacity: 0.65; } 50% { opacity: 0.85; } }
                @keyframes spinSlow { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
                .animate-spin-slow { animation: spinSlow 120s linear infinite; }
            `}</style>
        </div>
    );
};
