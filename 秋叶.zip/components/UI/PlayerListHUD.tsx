
import React, { useState, useEffect } from 'react';
import { Player, PlayerType, ScoreNotification } from '../../types';
import { useSkin } from '../../contexts/SkinContext';
import { useLayoutEngine } from '../../hooks/useLayoutEngine';

const getDiaoStatus = (trickPile: any[]) => {
    if (!trickPile || !Array.isArray(trickPile)) return { text: "-", color: "bg-black/20", textColor: "text-white/20" };
    const trickCount = trickPile.filter(t => t.round <= 8 && !t.isKaiChong && t.isFaceUp).length;
    // [VISUAL] Updated colors: Zheng Ben = White, De Diao = Green, Chi Jiao = Red
    if (trickCount < 2) return { text: "赤脚", color: "bg-[#5c0b00]", textColor: "text-[#ff9999]", border: "border-red-800" }; 
    if (trickCount === 2) return { text: "正本", color: "bg-[#2a2a2a]", textColor: "text-white", border: "border-white/40" }; 
    return { text: "得吊", color: "bg-[#064e3b]", textColor: "text-[#4ade80]", border: "border-emerald-500" }; 
};

const truncateName = (name: string) => {
    if (!name) return "Player";
    return name.length > 5 ? name.substring(0, 4) + '.' : name;
};

const DEFAULT_AVATAR = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Crect width='100' height='100' fill='%23333'/%3E%3Ccircle cx='50' cy='40' r='20' fill='%23666'/%3E%3Cpath d='M20 90 Q50 60 80 90' fill='%23666'/%3E%3C/svg%3E";

const ScoreToast = ({ notification, playerPosClass, players }: { notification: ScoreNotification, playerPosClass: string, players: Player[] }) => {
    const [isVisible, setIsVisible] = useState(true);
    const player = players.find(p => p.id === notification.playerId);
    const playerName = player ? truncateName(player.name) : '';

    useEffect(() => {
        setIsVisible(true);
        const timer = setTimeout(() => setIsVisible(false), 2800);
        return () => clearTimeout(timer);
    }, [notification.id]);

    if (!isVisible) return null;

    const isCritical = notification.type === 'CRITICAL'; 
    const isPattern = notification.type === 'PATTERN';
    const animClass = isCritical ? "animate-bounce-in-fwd" : "animate-fade-in-up"; 

    // Visual styles based on type
    let bgClass = 'bg-[#0f172a]/95 border-[#94a3b8]';
    let textClass = 'text-gilded'; // Use Gilded for critical
    let scoreClass = 'text-[#4ade80]';
    
    if (isCritical) {
        bgClass = 'bg-gradient-to-r from-[#8c1c0b] to-[#5c0b00] border-[#ffd700] shadow-[0_0_40px_rgba(255,215,0,0.6)]';
        textClass = 'text-gilded drop-shadow-md';
        scoreClass = 'text-gilded';
    } else if (isPattern) {
        bgClass = 'bg-[#2a1b15]/95 border-[#c5a059] shadow-[0_0_20px_rgba(197,160,89,0.3)]';
        textClass = 'text-silver';
        scoreClass = 'text-[#86efac]';
    }

    return (
        <div className={`absolute z-[600] pointer-events-none transition-opacity duration-300 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-56 ${isVisible ? 'opacity-100' : 'opacity-0'}`}>
            <div key={notification.id} className={`${animClass} flex flex-col items-center justify-center`}>
                <div className={`relative px-5 py-3 rounded-sm border-2 backdrop-blur-md flex flex-col items-center ${bgClass}`}>
                    
                    <div className="absolute -top-3 left-3 bg-black/80 border border-[#c5a059] px-2 py-0.5 rounded-sm shadow-md">
                        <span className="text-[9px] text-[#c5a059] font-bold font-serif">{playerName}</span>
                    </div>

                    <span className={`${textClass} font-calligraphy text-2xl font-black tracking-widest whitespace-nowrap mt-1`}>
                        {notification.text}
                    </span>
                    
                    {notification.score !== 0 && (
                        <div className="flex items-center gap-2 mt-1">
                            <div className="h-px w-8 bg-white/20"></div>
                            <span className={`text-xl font-black font-mono ${scoreClass} drop-shadow-md`}>
                                {notification.score > 0 ? '+' : ''}{notification.score}
                            </span>
                            <div className="h-px w-8 bg-white/20"></div>
                        </div>
                    )}

                    {isCritical && (
                        <>
                            <div className="absolute -top-1 -right-1 w-2 h-2 bg-[#ffd700] rotate-45 animate-ping"></div>
                            <div className="absolute -bottom-1 -left-1 w-2 h-2 bg-[#ffd700] rotate-45 animate-ping delay-100"></div>
                        </>
                    )}
                </div>
            </div>
        </div>
    );
};

export const PlayerListHUD = React.memo(({ players, bankerId, currentPlayerIndex, aiChatMessages, activeNotification, thinkingPlayers = new Set() }: { players: Player[], bankerId: number, currentPlayerIndex: number, aiChatMessages: Record<number, string | null>, activeNotification: ScoreNotification | null, thinkingPlayers?: Set<number> }) => {
    const { skin } = useSkin();
    const layoutConfig = useLayoutEngine(); 
    
    return (
        <div className="fixed inset-0 pointer-events-none z-[200]">
            {players.map((player) => {
                const isHuman = player.type === PlayerType.HUMAN;
                const isMyTurn = players[currentPlayerIndex]?.id === player.id;
                const isBanker = player.id === bankerId;
                const isBaiLao = player.isBaiLaoRevealed || player.isSuspectedBaiLao;
                const isThinking = thinkingPlayers.has(player.id);
                
                const profile = player.profile;
                const avatarUrl = profile?.avatar_url || `https://api.dicebear.com/9.x/miniavs/svg?seed=${player.name}&backgroundColor=transparent`;
                const diaoStatus = getDiaoStatus(player.trickPile);
                const chatMsg = aiChatMessages[player.id];
                const hasNotification = activeNotification && activeNotification.playerId === player.id;
                const hudConfig = layoutConfig.hud[player.position as keyof typeof layoutConfig.hud];
                const posClass = hudConfig ? hudConfig.style : 'hidden';
                const remainingCards = player.hand.length;
                
                if (isHuman) {
                    if (hasNotification && activeNotification) {
                         const humanPos = layoutConfig.hud.Bottom?.style || "bottom-[180px] left-1/2 -translate-x-1/2";
                         return <div key={player.id} className={`absolute flex flex-col items-center pointer-events-none transition-all duration-500 ${humanPos}`}>
                             <ScoreToast notification={activeNotification} playerPosClass={humanPos} players={players} />
                         </div>;
                    }
                    return null;
                }

                return (
                    <div key={player.id} className={`absolute flex flex-col items-center pointer-events-auto transition-all duration-500 ${posClass}`}>
                        {hasNotification && activeNotification && <ScoreToast notification={activeNotification} playerPosClass={posClass} players={players} />}
                        <div className="transform scale-[1.25] relative">
                            {isThinking && (
                                <div className="absolute inset-[-4px] rounded-full border border-[#c5a059]/60 animate-ping-slow z-0"></div>
                            )}
                            
                            {/* Avatar Container with Internal Overlays */}
                            <div className={`overflow-hidden ${skin.hud.avatarContainerClass(isMyTurn, isBanker, isBaiLao || false)} relative group`}>
                                <img src={avatarUrl} className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-1000 ease-out" alt={player.name} onError={(e) => { (e.target as HTMLImageElement).src = DEFAULT_AVATAR; }}/>
                                <div className="absolute inset-0 bg-[radial-gradient(circle,transparent_40%,rgba(0,0,0,0.8)_100%)] pointer-events-none"></div>
                                
                                {/* 1. LEFT SIDE: Card Count (Embedded Overlay) */}
                                {remainingCards > 0 && (
                                    <div className="absolute top-0 bottom-0 left-0 w-[35%] bg-gradient-to-r from-black/80 to-transparent flex items-center justify-start pl-1.5 md:pl-2">
                                        <div className="flex flex-col items-center">
                                            <span className="text-white/90 text-[10px] md:text-xs font-mono font-bold leading-none drop-shadow-md">{remainingCards}</span>
                                            <div className="w-3 h-0.5 bg-white/30 rounded-full mt-[1px]"></div>
                                        </div>
                                    </div>
                                )}

                                {/* 2. RIGHT SIDE: Identity OR Diao Status (Embedded Overlay) */}
                                {/* If Banker: Show "Zhuang". If Peasant: Show Diao Status. BaiLao stacks if needed. */}
                                <div className="absolute top-0 bottom-0 right-0 w-[35%] bg-gradient-to-l from-black/80 to-transparent flex flex-col items-end justify-center pr-1.5 md:pr-2 gap-1">
                                    {isBanker ? (
                                        <div className="text-[#ffd700] text-[9px] md:text-[10px] font-black font-serif writing-vertical-rl bg-[#8c1c0b]/80 border border-[#d4af37]/50 rounded-[1px] px-[1px] py-1 shadow-sm leading-none opacity-90">
                                            庄
                                        </div>
                                    ) : (
                                        // Peasant Status: Chi Jiao / Zheng Ben / De Diao
                                        <div className={`${diaoStatus.textColor} text-[9px] md:text-[10px] font-black font-serif writing-vertical-rl ${diaoStatus.color} border ${diaoStatus.border} rounded-[1px] px-[1px] py-1 shadow-sm leading-none opacity-90`}>
                                            {diaoStatus.text}
                                        </div>
                                    )}
                                    
                                    {isBaiLao && (
                                        <div className="text-[#ecfdf5] text-[9px] md:text-[10px] font-black font-serif writing-vertical-rl bg-[#047857]/80 border border-[#34d399]/50 rounded-[1px] px-[1px] py-1 shadow-sm leading-none opacity-90">
                                            百
                                        </div>
                                    )}
                                </div>

                                <div className="absolute bottom-0 inset-x-0 flex flex-col z-10">
                                    {/* [TEXT BEAUTY] Embossed Name */}
                                    <div className="text-[8px] md:text-[10px] text-center text-embossed font-bold font-serif tracking-widest truncate px-1 pb-[2px]">{truncateName(profile?.username || player.name)}</div>
                                    {/* Small Diao Status Bar (Bottom Strip) - Still useful for quick color read */}
                                    <div className={`h-1 w-full bg-[#000]/50 backdrop-blur-sm relative`}>
                                        <div className={`absolute inset-0 ${diaoStatus.color} opacity-50`}></div>
                                    </div>
                                </div>
                            </div>
                            
                            {isThinking && (
                                <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 z-30">
                                    <div className="bg-[#1a0f0a] border border-[#c5a059] text-[#c5a059] text-[8px] px-1.5 rounded-full whitespace-nowrap animate-pulse">
                                        ...
                                    </div>
                                </div>
                            )}
                        </div>
                        
                        {chatMsg && (
                            <div className="absolute top-full left-1/2 -translate-x-1/2 mt-3 w-32 md:w-40 z-[300] animate-fade-in-up">
                                <div className="bg-[#e8e4d9] text-[#2b1810] p-2 rounded-[2px] text-[10px] md:text-xs font-serif shadow-[0_4px_15px_rgba(0,0,0,0.5)] border border-[#8c6239]/30 text-center relative leading-relaxed tracking-wide">
                                    <div className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-3 h-3 bg-[#e8e4d9] transform rotate-45 border-l border-t border-[#8c6239]/30"></div>
                                    {chatMsg}
                                </div>
                            </div>
                        )}
                    </div>
                );
            })}
        </div>
    );
});
