
import React, { useState, useEffect } from 'react';
import { StylizedButton, HUANGHUALI_TEXTURE, ImperialWindow } from './Shared';
import { AvatarViewer } from '../Visuals/AvatarViewer';

// ... (PRESET_OUTFITS constant remains unchanged) ...
// Avaturn 或 Ready Player Me 的子域名
const EDITOR_URL = "https://madiao.avaturn.dev"; 

// --- 预设衣柜配置 (PRESET WARDROBE CONFIG) ---
interface Outfit {
    id: string;
    name: string;
    desc: string;
    url: string;
    themeColor: string;
    category: 'HANFU' | 'KIMONO' | 'HANBOK' | 'CUSTOM';
    gender: 'MALE' | 'FEMALE';
    price: number; // 0 = Free
}

const PRESET_OUTFITS: Outfit[] = [
    // --- 汉服 (HANFU) ---
    {
        id: 'hanfu_m_scholar',
        name: '青衫布衣',
        desc: '落魄书生，两袖清风。(明制道袍)',
        url: 'https://models.readyplayer.me/63c5a772f4357e626e27b233.glb',
        themeColor: '#2b3e5c',
        category: 'HANFU', gender: 'MALE', price: 0
    },
    {
        id: 'hanfu_m_official',
        name: '朱红官袍',
        desc: '七品芝麻官，初入仕途。(圆领袍)',
        url: 'https://models.readyplayer.me/63a6e73a256c703d38379208.glb', 
        themeColor: '#8c1c0b',
        category: 'HANFU', gender: 'MALE', price: 500
    },
    {
        id: 'hanfu_m_feiyu',
        name: '飞鱼服',
        desc: '锦衣卫御赐，威风凛凛。(曳撒)',
        url: 'https://models.readyplayer.me/63c5a772f4357e626e27b233.glb', // Placeholder
        themeColor: '#d4af37',
        category: 'HANFU', gender: 'MALE', price: 2000
    },
    {
        id: 'hanfu_f_mamian',
        name: '马面裙',
        desc: '云锦织金，端庄大气。(明制)',
        url: 'https://models.readyplayer.me/63c5a783f4357e626e27b236.glb',
        themeColor: '#8c1c0b',
        category: 'HANFU', gender: 'FEMALE', price: 0
    },
    {
        id: 'hanfu_f_yunjian',
        name: '云肩凤袍',
        desc: '命妇礼服，富贵逼人。',
        url: 'https://models.readyplayer.me/63a6e6e2256c703d38379201.glb',
        themeColor: '#c5a059',
        category: 'HANFU', gender: 'FEMALE', price: 1500
    },

    // --- 和服 (KIMONO) ---
    {
        id: 'kimono_m_haori',
        name: '纹付羽织袴',
        desc: '武家正装，严肃庄重。',
        url: 'https://models.readyplayer.me/63a6e73a256c703d38379208.glb', // Placeholder
        themeColor: '#1a1a1a',
        category: 'KIMONO', gender: 'MALE', price: 500
    },
    {
        id: 'kimono_f_shiromuku',
        name: '白无垢',
        desc: '纯白礼服，神圣无暇。',
        url: 'https://models.readyplayer.me/63a6e6e2256c703d38379201.glb', // Placeholder
        themeColor: '#f0f0f0',
        category: 'KIMONO', gender: 'FEMALE', price: 2000
    },

    // --- 韩服 (HANBOK) ---
    {
        id: 'hanbok_m_dapo',
        name: '多宝袍',
        desc: '朝鲜士大夫便服。',
        url: 'https://models.readyplayer.me/63c5a772f4357e626e27b233.glb', // Placeholder
        themeColor: '#2e5c3e',
        category: 'HANBOK', gender: 'MALE', price: 500
    },
    {
        id: 'hanbok_f_dangyi',
        name: '唐衣',
        desc: '宫廷尚宫礼服。',
        url: 'https://models.readyplayer.me/63c5a783f4357e626e27b236.glb', // Placeholder
        themeColor: '#10b981',
        category: 'HANBOK', gender: 'FEMALE', price: 800
    }
];

interface WardrobeModalProps {
    onClose: () => void;
    onSaveAvatar: (url: string) => void;
    currentAvatarUrl?: string;
    userCoins: number;
    onSpendCoins: (amount: number) => boolean;
}

export const WardrobeModal: React.FC<WardrobeModalProps> = ({ onClose, onSaveAvatar, currentAvatarUrl, userCoins, onSpendCoins }) => {
    // ... (Keep existing logic state) ...
    const [isEditing, setIsEditing] = useState(false);
    const [previewUrl, setPreviewUrl] = useState(currentAvatarUrl);
    const [activeFilter, setActiveFilter] = useState<'ALL' | 'HANFU' | 'KIMONO' | 'HANBOK' | 'CUSTOM'>('ALL');
    const [activeGender, setActiveGender] = useState<'ALL' | 'MALE' | 'FEMALE'>('ALL');
    const [ownedIds, setOwnedIds] = useState<Set<string>>(() => {
        try { return new Set(JSON.parse(localStorage.getItem('madiao_owned_outfits') || '[]')); } catch { return new Set(); }
    });
    const [customOutfits, setCustomOutfits] = useState<Outfit[]>(() => {
        try { return JSON.parse(localStorage.getItem('madiao_custom_wardrobe') || '[]'); } catch { return []; }
    });
    const [editingId, setEditingId] = useState<string | null>(null);
    const [editName, setEditName] = useState('');
    const [isAddingCustom, setIsAddingCustom] = useState(false);
    const [customUrlInput, setCustomUrlInput] = useState('');

    useEffect(() => { localStorage.setItem('madiao_custom_wardrobe', JSON.stringify(customOutfits)); }, [customOutfits]);

    useEffect(() => {
        const receiveMessage = (event: any) => {
            if (event.origin.includes('avaturn.dev')) { 
                try {
                    const data = typeof event.data === 'string' ? JSON.parse(event.data) : event.data;
                    if (data.source === 'avaturn' && data.eventName === 'v2.avatar.exported') {
                        const url = data.data.url;
                        setPreviewUrl(url);
                        onSaveAvatar(url);
                        setIsEditing(false);
                    }
                } catch(e) { console.error("Avatar parse error", e); }
            }
        };
        window.addEventListener('message', receiveMessage);
        return () => window.removeEventListener('message', receiveMessage);
    }, [onSaveAvatar]);

    const handleCustomSubmit = () => {
        if (!customUrlInput) return;
        const url = customUrlInput.trim();
        const newOutfit: Outfit = { id: `custom_${Date.now()}`, name: `自定义模型 ${customOutfits.length + 1}`, desc: '外部导入的模型', url: url, themeColor: '#5c3a21', category: 'CUSTOM', gender: 'MALE', price: 0 };
        setCustomOutfits(prev => [...prev, newOutfit]); setPreviewUrl(url); setIsAddingCustom(false); setCustomUrlInput(''); setActiveFilter('CUSTOM');
    };

    const handleDeleteCustom = (id: string, e: React.MouseEvent) => {
        e.stopPropagation();
        if (confirm('确定要删除这个自定义模型吗？')) {
            const outfitToDelete = customOutfits.find(o => o.id === id);
            setCustomOutfits(prev => prev.filter(o => o.id !== id));
            if (previewUrl === outfitToDelete?.url) setPreviewUrl(undefined);
        }
    };

    const handleStartRename = (outfit: Outfit, e: React.MouseEvent) => { e.stopPropagation(); setEditingId(outfit.id); setEditName(outfit.name); };
    const handleSaveName = (e?: React.FormEvent) => { e?.preventDefault(); if (editingId && editName.trim()) { setCustomOutfits(prev => prev.map(o => o.id === editingId ? { ...o, name: editName.trim() } : o)); setEditingId(null); } };
    const handlePurchase = (item: Outfit) => { if (onSpendCoins(item.price)) { const newOwned = new Set(ownedIds).add(item.id); setOwnedIds(newOwned); localStorage.setItem('madiao_owned_outfits', JSON.stringify(Array.from(newOwned))); setPreviewUrl(item.url); } else { alert("文钱不足！请多赢几局再来。"); } };

    const allOutfits = [...PRESET_OUTFITS, ...customOutfits];
    const filteredOutfits = allOutfits.filter(item => {
        if (activeFilter !== 'ALL' && item.category !== activeFilter) return false;
        if (activeGender !== 'ALL' && item.gender !== activeGender) return false;
        return true;
    });
    const selectedOutfit = allOutfits.find(p => p.url === previewUrl);
    const isSelectedOwned = selectedOutfit ? (selectedOutfit.price === 0 || ownedIds.has(selectedOutfit.id) || selectedOutfit.category === 'CUSTOM') : true;

    return (
        <div className="fixed inset-0 z-[1200] bg-black/95 flex items-center justify-center animate-fade-in font-serif">
            <ImperialWindow title="尚衣局" onClose={onClose} width="w-full max-w-6xl" height="h-[90vh]">
                <div className="flex h-full">
                    {/* LEFT: 3D PREVIEW / EDITOR */}
                    <div className="flex-1 relative bg-[#0a0807] border-r border-[#3e2b22]">
                        {isEditing ? (
                            <iframe src={EDITOR_URL} className="w-full h-full border-none" allow="camera *; microphone *" />
                        ) : (
                            <div className="w-full h-full relative group">
                                <AvatarViewer key={previewUrl} avatarUrl={previewUrl} />
                                
                                <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-4 pointer-events-auto transition-opacity opacity-0 group-hover:opacity-100 duration-500">
                                    <StylizedButton onClick={() => setIsEditing(true)} className="px-8 shadow-xl">
                                        {previewUrl ? "拍照捏脸" : "创建角色"}
                                    </StylizedButton>
                                </div>

                                <div className="absolute top-6 right-6 flex items-center gap-2 bg-black/60 px-4 py-2 rounded-sm border border-[#ffd700]/30 backdrop-blur-md shadow-lg">
                                    <span className="text-[#ffd700] font-mono font-bold text-lg drop-shadow-[0_0_10px_gold]">{userCoins.toLocaleString()}</span>
                                    <span className="text-[10px] text-[#ffd700]/80 tracking-widest border border-[#ffd700]/50 rounded-full px-1">文</span>
                                </div>
                            </div>
                        )}
                    </div>

                    {/* RIGHT: UI PANEL */}
                    <div className="w-96 bg-[#0c0806] flex flex-col relative">
                        <div className="absolute inset-0 opacity-10 pointer-events-none mix-blend-overlay" style={{ backgroundImage: HUANGHUALI_TEXTURE }}></div>
                        
                        <div className="p-6 border-b border-[#3e2b22] bg-[#1a100a]/30 shrink-0 space-y-4">
                            <div className="flex gap-1 overflow-x-auto hide-scrollbar pb-1">
                                {['ALL', 'HANFU', 'KIMONO', 'HANBOK', 'CUSTOM'].map(cat => (
                                    <button
                                        key={cat}
                                        onClick={() => setActiveFilter(cat as any)}
                                        className={`px-3 py-1.5 text-[10px] border rounded-sm whitespace-nowrap transition-all tracking-wider ${activeFilter === cat ? 'bg-[#c5a059] text-black border-[#c5a059] font-bold shadow-[0_0_10px_rgba(197,160,89,0.3)]' : 'text-[#8c6239] border-[#3e2b22] hover:border-[#c5a059] hover:text-[#c5a059]'}`}
                                    >
                                        {cat === 'ALL' ? '全部' : (cat === 'HANFU' ? '汉服' : (cat === 'KIMONO' ? '和服' : (cat === 'HANBOK' ? '韩服' : '自定义')))}
                                    </button>
                                ))}
                            </div>
                            <div className="flex gap-2">
                                {['ALL', 'MALE', 'FEMALE'].map(g => (
                                    <button
                                        key={g}
                                        onClick={() => setActiveGender(g as any)}
                                        className={`flex-1 py-1 text-[10px] border rounded-sm transition-all tracking-wide ${activeGender === g ? 'bg-[#3e2b22] text-[#e8e4d9] border-[#5c3a21] shadow-inner' : 'text-[#555] border-transparent hover:text-[#8c6239]'}`}
                                    >
                                        {g === 'ALL' ? '所有' : (g === 'MALE' ? '男装' : '女装')}
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div className="flex-1 p-4 space-y-3 overflow-y-auto custom-scrollbar relative z-10">
                            {filteredOutfits.map(outfit => {
                                const isActive = previewUrl === outfit.url;
                                const isOwned = outfit.price === 0 || ownedIds.has(outfit.id) || outfit.category === 'CUSTOM';
                                const isCustom = outfit.category === 'CUSTOM';
                                const isEditingThis = editingId === outfit.id;
                                
                                return (
                                    <div
                                        key={outfit.id}
                                        onClick={() => isOwned && setPreviewUrl(outfit.url)}
                                        className={`
                                            w-full relative group flex items-center gap-3 p-2 border transition-all duration-300 rounded-sm cursor-pointer overflow-hidden
                                            ${isActive ? 'bg-[#1a100a] border-[#c5a059] shadow-[inset_0_0_20px_rgba(197,160,89,0.1)]' : 'bg-[#0a0807] border-[#3e2b22] hover:border-[#8c6239] hover:bg-[#120e0c]'}
                                            ${!isOwned ? 'opacity-80 grayscale-[0.3]' : ''}
                                        `}
                                    >
                                        <div className="w-12 h-12 shrink-0 border border-white/10 relative overflow-hidden bg-black/40">
                                            <div className="absolute inset-0 opacity-50" style={{ background: outfit.themeColor }}></div>
                                            <div className="absolute inset-0 flex items-center justify-center text-white/30 text-xs font-bold font-serif">
                                                {outfit.category[0]}
                                            </div>
                                            {isActive && <div className="absolute inset-0 flex items-center justify-center text-[#ffd700] text-lg font-bold bg-black/40 shadow-[inset_0_0_10px_gold]">✔</div>}
                                        </div>
                                        
                                        <div className="flex flex-col items-start text-left min-w-0 flex-1">
                                            <div className="flex justify-between w-full items-center">
                                                {isEditingThis ? (
                                                    <form onSubmit={handleSaveName} className="flex-1 mr-2" onClick={e => e.stopPropagation()}>
                                                        <input autoFocus type="text" value={editName} onChange={e => setEditName(e.target.value)} onBlur={() => handleSaveName()} className="w-full bg-black border border-[#c5a059] text-[#e8e4d9] text-xs px-1 py-0.5 outline-none" />
                                                    </form>
                                                ) : (
                                                    <span className={`text-xs font-bold truncate ${isActive ? 'text-[#c5a059]' : 'text-[#a0a0a0] group-hover:text-[#e8e4d9]'}`}>{outfit.name}</span>
                                                )}
                                                
                                                {!isOwned ? (
                                                    <div className="flex items-center gap-1 bg-black/40 px-1.5 py-0.5 rounded border border-[#ffd700]/20">
                                                        <span className="text-[#ffd700] text-[10px] font-mono">{outfit.price}</span>
                                                    </div>
                                                ) : isCustom && !isEditingThis && (
                                                    <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                                        <button onClick={(e) => handleStartRename(outfit, e)} className="text-[#8c6239] hover:text-[#c5a059] text-[10px]">✎</button>
                                                        <button onClick={(e) => handleDeleteCustom(outfit.id, e)} className="text-[#8c6239] hover:text-red-500 text-[10px]">✕</button>
                                                    </div>
                                                )}
                                            </div>
                                            <span className="text-[9px] text-[#555] truncate w-full group-hover:text-[#888] transition-colors mt-0.5">{outfit.desc}</span>
                                        </div>

                                        {!isOwned && (
                                            <div onClick={(e) => { e.stopPropagation(); handlePurchase(outfit); }} className="absolute inset-0 bg-black/70 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-[1px]">
                                                <span className="bg-gradient-to-r from-[#8c1c0b] to-[#5c0b00] border border-[#ffd700]/30 text-[#ffd700] text-xs font-bold px-3 py-1 rounded-sm shadow-lg hover:brightness-125 transform hover:scale-105 transition-all">购买</span>
                                            </div>
                                        )}
                                    </div>
                                );
                            })}

                            <div className="pt-4 border-t border-[#3e2b22]/30">
                                <button onClick={() => setIsAddingCustom(!isAddingCustom)} className={`w-full py-2 border border-dashed border-[#5c3a21] text-[#8c6239] hover:text-[#c5a059] hover:border-[#c5a059] text-[10px] tracking-widest transition-all ${isAddingCustom ? 'bg-[#1a100a] border-[#c5a059]' : ''}`}>+ 添加自定义模型链接</button>
                                {isAddingCustom && (
                                    <div className="bg-[#1a100a] p-3 border border-[#3e2b22] animate-fade-in-down mt-2">
                                        <div className="text-[9px] text-[#8c6239] mb-2">输入 .glb 或 .gltf 模型地址:</div>
                                        <input type="text" value={customUrlInput} onChange={e => setCustomUrlInput(e.target.value)} placeholder="https://..." className="w-full bg-[#0a0807] border border-[#3e2b22] text-[#e8e4d9] text-[10px] p-2 mb-2 outline-none focus:border-[#c5a059]" />
                                        <div className="flex gap-2">
                                            <button onClick={() => setIsAddingCustom(false)} className="flex-1 py-1 text-[10px] border border-[#3e2b22] text-[#555] hover:text-[#a0a0a0]">取消</button>
                                            <button onClick={handleCustomSubmit} className="flex-1 py-1 text-[10px] bg-[#3d0e0e] text-[#c5a059] border border-[#5c1010] hover:bg-[#5c1010]">确认加载</button>
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>

                        <div className="p-6 border-t border-[#3e2b22] bg-[#0c0806] shrink-0 relative z-20">
                            {selectedOutfit && !isSelectedOwned ? (
                                <StylizedButton onClick={() => handlePurchase(selectedOutfit)} className="w-full">
                                    购买并穿戴 ({selectedOutfit.price} 文)
                                </StylizedButton>
                            ) : (
                                <StylizedButton onClick={() => { if (previewUrl) onSaveAvatar(previewUrl); onClose(); }} className="w-full">
                                    {previewUrl ? "保存并返回" : "返回牌局"}
                                </StylizedButton>
                            )}
                        </div>
                    </div>
                </div>
            </ImperialWindow>
        </div>
    );
};
