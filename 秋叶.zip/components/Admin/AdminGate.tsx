
// @ARCHITECT_LOCK: ADMIN & AUDIO VAULT
// -------------------------------------------------------------------------
// 🛡️ SECURITY LEVEL: HIGH
// This component manages the binary audio database and system logs.
// It contains a custom PCM decoder implementation.
// DO NOT REFACTOR without understanding Int16Array audio processing.
// -------------------------------------------------------------------------

import React, { useState, useEffect, useRef } from 'react';
import { fetchAllMatchLogs, deleteMatchLog, getSupabaseConfig, initSupabase, AdminLogEntry } from '../../services/cloudService';
import { generateAllTutorialAudio } from '../../services/geminiService';
import { ImperialWindow, StylizedButton, HUANGHUALI_TEXTURE } from '../UI/Shared'; 
import { audioPersistence, TTSCacheEntry } from '../../services/audioPersistence';
import { telemetry, LogEntry } from '../../services/telemetryService'; // NEW

interface AdminGateProps {
    onExit: () => void;
}

export const AdminGate: React.FC<AdminGateProps> = ({ onExit }) => {
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [errorMsg, setErrorMsg] = useState('');
    const [activeTab, setActiveTab] = useState<'LOGS' | 'AUDIO' | 'TELEMETRY'>('LOGS'); // ADDED TELEMETRY

    // Dashboard State
    const [logs, setLogs] = useState<AdminLogEntry[]>([]);
    const [loading, setLoading] = useState(false);
    const [dbUrl, setDbUrl] = useState('');
    const [dbKey, setDbKey] = useState('');
    const [configStatus, setConfigStatus] = useState('');
    
    // Telemetry State
    const [systemLogs, setSystemLogs] = useState<LogEntry[]>([]);

    // Audio Gen State
    const [isGeneratingAudio, setIsGeneratingAudio] = useState(false);
    const [audioProgress, setAudioProgress] = useState({ current: 0, total: 0, msg: '' });
    const [audioClips, setAudioClips] = useState<TTSCacheEntry[]>([]);
    const [refreshTrigger, setRefreshTrigger] = useState(0);
    const [playingKey, setPlayingKey] = useState<string | null>(null);

    // Audio Context Ref
    const audioCtxRef = useRef<AudioContext | null>(null);

    useEffect(() => {
        const config = getSupabaseConfig();
        setDbUrl(config.url);
        setDbKey(config.key);

        return () => {
            // Cleanup audio context on unmount
            if (audioCtxRef.current) {
                audioCtxRef.current.close();
                audioCtxRef.current = null;
            }
        };
    }, []);

    // Refresh Audio List when tab changes or triggered
    useEffect(() => {
        if (isAuthenticated) {
            if (activeTab === 'AUDIO') loadAudioClips();
            if (activeTab === 'TELEMETRY') setSystemLogs(telemetry.getLogs());
        }
    }, [isAuthenticated, activeTab, refreshTrigger]);

    // [FIXED] Dedicated PCM Player for Admin Preview
    // Does not rely on global AudioManager to avoid state conflicts
    const playClip = async (key: string, arrayBuffer: ArrayBuffer) => {
        if (playingKey) return; // Prevent double play
        setPlayingKey(key);
        
        try {
            // Initialize Context if not exists
            if (!audioCtxRef.current || audioCtxRef.current.state === 'closed') {
                const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
                audioCtxRef.current = new AudioCtx({ sampleRate: 24000 }); // Gemini Standard: 24kHz
            } else if (audioCtxRef.current.state === 'suspended') {
                await audioCtxRef.current.resume();
            }

            const ctx = audioCtxRef.current;
            
            // Raw PCM (Int16 Little Endian) -> Float32 AudioBuffer
            const dataInt16 = new Int16Array(arrayBuffer.slice(0));
            const buffer = ctx.createBuffer(1, dataInt16.length, 24000);
            const channelData = buffer.getChannelData(0);
            
            // Normalize Int16 (-32768..32767) to Float32 (-1.0..1.0)
            for (let i = 0; i < dataInt16.length; i++) {
                channelData[i] = dataInt16[i] / 32768.0;
            }
            
            const source = ctx.createBufferSource();
            source.buffer = buffer;
            source.connect(ctx.destination);
            
            source.onended = () => {
                setPlayingKey(null);
                // Keep context open for reuse
            };
            
            source.start(0);
        } catch (e) {
            console.error("PCM Playback Failed:", e);
            alert("Playback Error: " + e);
            setPlayingKey(null);
        }
    };

    const handleLogin = (e: React.FormEvent) => {
        e.preventDefault();
        if (username === 'Lhy' && password === 'Lhy147258') {
            setIsAuthenticated(true);
            setErrorMsg('');
            loadData();
        } else {
            setErrorMsg("Invalid Administrator Credentials");
        }
    };

    const handleConfigSave = () => {
        if (initSupabase(dbUrl, dbKey)) {
            setConfigStatus("Connection Successful (MemFire/Supabase)");
            loadData();
        } else {
            setConfigStatus("Connection Failed");
        }
    };

    const loadData = async () => {
        setLoading(true);
        const data = await fetchAllMatchLogs();
        setLogs(data);
        setLoading(false);
    };

    const loadAudioClips = async () => {
        const clips = await audioPersistence.getAllEntries();
        // Sort by timestamp desc
        setAudioClips(clips.sort((a, b) => b.timestamp - a.timestamp));
    };

    const handleDeleteLog = async (id: string) => {
        if (confirm("Are you sure you want to delete this record?")) {
            const success = await deleteMatchLog(id);
            if (success) setLogs(prev => prev.filter(l => l.id !== id));
        }
    };

    const handleDeleteAudio = async (key: string) => {
        if (confirm(`Delete audio "${key}"?`)) {
            await audioPersistence.deleteKey(key);
            setRefreshTrigger(p => p + 1);
        }
    };

    const handleClearAudio = async () => {
        if (confirm("DANGER: Wipe ALL cached audio?")) {
            await audioPersistence.clearStore();
            setRefreshTrigger(p => p + 1);
        }
    };

    const handleGenerateAudio = async () => {
        if (!confirm("Start generating TTS for all tutorial steps? (Costs API Quota)")) return;
        
        setIsGeneratingAudio(true);
        try {
            // The generator now saves to persistence directly
            const jsonStr = await generateAllTutorialAudio((curr, tot, msg) => {
                setAudioProgress({ current: curr, total: tot, msg });
            });
            
            alert("Generation Complete. Audio saved to Local Vault.");
            setRefreshTrigger(p => p + 1);
        } catch (e: any) {
            alert("Generation failed: " + e.message);
        } finally {
            setIsGeneratingAudio(false);
        }
    };

    const handleExportAudio = async () => {
        const entries = await audioPersistence.getAllEntries();
        // Convert ArrayBuffers to Base64 for JSON storage
        const exportObj: Record<string, string> = {};
        const totalBytes = entries.reduce((acc, curr) => acc + curr.data.byteLength, 0);
        
        console.log(`Exporting ${entries.length} clips (${(totalBytes/1024/1024).toFixed(2)} MB)...`);
        
        for (const entry of entries) {
            // normalize key just in case
            const cleanKey = entry.key.replace('Zephyr:', '').replace('Charon:', ''); // simple normalization if needed
            // But we should probably keep full keys to avoid collision
            
            // Convert ArrayBuffer to Base64
            let binary = '';
            const bytes = new Uint8Array(entry.data);
            const len = bytes.byteLength;
            for (let i = 0; i < len; i++) {
                binary += String.fromCharCode(bytes[i]);
            }
            exportObj[cleanKey] = btoa(binary);
        }

        const jsonStr = JSON.stringify(exportObj, null, 2);
        const blob = new Blob([jsonStr], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `madiao_audio_manifest_${Date.now()}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    };

    const handleImportAudio = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = async (evt) => {
            try {
                const json = JSON.parse(evt.target?.result as string);
                const entries: TTSCacheEntry[] = [];
                
                Object.entries(json).forEach(([k, v]) => {
                    const normalizedKey = k.trim().replace(/[.,/#!$%^&*;:{}=\-_`~()]/g, "").toLowerCase();
                    const fullKey = `Zephyr:${normalizedKey}`;
                    
                    const binaryString = atob(v as string);
                    const len = binaryString.length;
                    const bytes = new Uint8Array(len);
                    for (let i = 0; i < len; i++) {
                        bytes[i] = binaryString.charCodeAt(i);
                    }
                    
                    entries.push({
                        key: fullKey,
                        data: bytes.buffer,
                        timestamp: Date.now()
                    });
                });

                const count = await audioPersistence.importBatch(entries);
                alert(`Imported ${count} clips successfully.`);
                setRefreshTrigger(p => p + 1);
            } catch (err) {
                alert("Import failed: Invalid JSON");
            }
        };
        reader.readAsText(file);
    };

    // Telemetry Export
    const handleExportLogs = () => {
        const jsonStr = JSON.stringify(systemLogs, null, 2);
        const blob = new Blob([jsonStr], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `madiao_telemetry_${Date.now()}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    };

    if (!isAuthenticated) {
        return (
            <div className="fixed inset-0 z-[999] bg-[#050202] flex items-center justify-center font-serif text-[#c5a059] backdrop-blur-md">
                <ImperialWindow title="后台管理系统 (ADMIN)" onClose={onExit} width="w-full max-w-md" height="auto">
                    <div className="p-8 space-y-6 flex flex-col items-center">
                        <div className="text-4xl animate-pulse text-[#c5a059] drop-shadow-md">🛡️</div>
                        <p className="text-xs text-[#8c6239] tracking-widest text-center">系统重地 · 闲人免进</p>
                        
                        <form onSubmit={handleLogin} className="w-full space-y-5">
                            <input type="text" value={username} onChange={e => setUsername(e.target.value)} className="w-full bg-[#0a0806] border border-[#3e2b22] text-[#e6c278] px-4 py-3 focus:border-[#c5a059] outline-none rounded-sm" placeholder="Admin ID" />
                            <input type="password" value={password} onChange={e => setPassword(e.target.value)} className="w-full bg-[#0a0806] border border-[#3e2b22] text-[#e6c278] px-4 py-3 focus:border-[#c5a059] outline-none rounded-sm" placeholder="Passkey" />
                            {errorMsg && <div className="text-red-500 text-xs text-center border border-red-900/30 bg-red-900/10 p-2 rounded">{errorMsg}</div>}
                            <StylizedButton onClick={() => {}} className="w-full py-4 text-sm font-black tracking-widest mt-4">AUTHENTICATE</StylizedButton>
                        </form>
                    </div>
                </ImperialWindow>
            </div>
        );
    }

    return (
        <div className="fixed inset-0 z-[999] bg-[#0c0c0c] text-[#a0a0a0] font-sans flex flex-col overflow-hidden">
            {/* Header */}
            <div className="h-16 bg-[#15100e] border-b border-[#3e2b22] flex items-center justify-between px-6 shrink-0 relative overflow-hidden">
                <div className="absolute inset-0 opacity-10 pointer-events-none mix-blend-overlay" style={{ backgroundImage: HUANGHUALI_TEXTURE }}></div>
                <div className="flex items-center gap-6 relative z-10">
                    <h1 className="text-xl text-[#c5a059] font-serif tracking-widest font-bold drop-shadow-md">MA DIAO ADMIN</h1>
                    <div className="flex gap-1">
                        <button onClick={() => setActiveTab('LOGS')} className={`px-4 py-1 text-xs uppercase tracking-wider rounded-sm transition-all ${activeTab === 'LOGS' ? 'bg-[#3e2b22] text-[#c5a059]' : 'text-[#555] hover:text-[#a0a0a0]'}`}>Matches</button>
                        <button onClick={() => setActiveTab('AUDIO')} className={`px-4 py-1 text-xs uppercase tracking-wider rounded-sm transition-all ${activeTab === 'AUDIO' ? 'bg-[#3e2b22] text-[#c5a059]' : 'text-[#555] hover:text-[#a0a0a0]'}`}>Audio Vault</button>
                        <button onClick={() => setActiveTab('TELEMETRY')} className={`px-4 py-1 text-xs uppercase tracking-wider rounded-sm transition-all ${activeTab === 'TELEMETRY' ? 'bg-[#3e2b22] text-[#c5a059]' : 'text-[#555] hover:text-[#a0a0a0]'}`}>Blackbox</button>
                    </div>
                </div>
                <div className="flex gap-4 relative z-10">
                    <button onClick={activeTab === 'LOGS' ? loadData : () => setRefreshTrigger(p=>p+1)} className="text-xs uppercase hover:text-[#ffd700] flex items-center gap-1 transition-colors"><span>↻</span> Refresh</button>
                    <button onClick={onExit} className="text-xs uppercase hover:text-[#ffd700] border border-[#3e2b22] px-4 py-1.5 rounded-sm hover:bg-[#2a1d15] transition-all font-bold">Exit</button>
                </div>
            </div>

            <div className="flex flex-1 overflow-hidden relative">
                <div className="absolute inset-0 bg-[#050302] z-0"></div>
                
                {/* --- TAB CONTENT: MATCH LOGS --- */}
                {activeTab === 'LOGS' && (
                    <>
                        <div className="w-80 bg-[#0f0a08] border-r border-[#3e2b22] p-6 flex flex-col gap-6 overflow-y-auto relative z-10">
                            <div>
                                <h3 className="text-[10px] uppercase tracking-widest text-[#c5a059] mb-4 font-bold border-b border-[#3e2b22] pb-2">Database Connection</h3>
                                <div className="space-y-3">
                                    <input type="text" placeholder="API URL" value={dbUrl} onChange={e => setDbUrl(e.target.value)} className="w-full bg-[#0a0806] border border-[#3e2b22] px-3 py-2 text-xs rounded-sm focus:border-[#c5a059] outline-none text-[#e6c278]" />
                                    <input type="password" placeholder="Anon Key" value={dbKey} onChange={e => setDbKey(e.target.value)} className="w-full bg-[#0a0806] border border-[#3e2b22] px-3 py-2 text-xs rounded-sm focus:border-[#c5a059] outline-none text-[#e6c278]" />
                                    <StylizedButton onClick={handleConfigSave} className="w-full h-9 text-xs">Update Connection</StylizedButton>
                                    {configStatus && <div className="text-[10px] text-green-500 mt-2 text-center">{configStatus}</div>}
                                </div>
                            </div>
                        </div>
                        <div className="flex-1 bg-[#080605] p-8 overflow-y-auto relative z-10 custom-scrollbar">
                            <h2 className="text-2xl text-[#e6c278] mb-6 font-serif font-bold tracking-wider">Match Logs</h2>
                            {loading ? <div className="text-center py-20 text-[#8c6239] animate-pulse">Loading...</div> : (
                                <div className="border border-[#3e2b22] rounded-sm overflow-hidden bg-[#0c0806]">
                                    <table className="w-full text-left text-sm">
                                        <thead className="bg-[#1a100a] text-[#8c6239] font-serif border-b border-[#3e2b22]">
                                            <tr><th className="p-4">Timestamp</th><th className="p-4">Match ID</th><th className="p-4">Winner</th><th className="p-4 text-right">Actions</th></tr>
                                        </thead>
                                        <tbody className="divide-y divide-[#1a100a]">
                                            {logs.map(log => (
                                                <tr key={log.id} className="hover:bg-[#15100e] transition-colors">
                                                    <td className="p-4 text-[#a0a0a0] font-mono text-xs">{new Date(log.timestamp).toLocaleString()}</td>
                                                    <td className="p-4 font-mono text-xs text-[#555]">{log.id.substring(0, 8)}...</td>
                                                    <td className="p-4 text-[#c5a059] font-bold">{log.data.results.find((r:any)=>r.isWinner)?.playerId ?? 'Draw'}</td>
                                                    <td className="p-4 text-right"><button onClick={() => handleDeleteLog(log.id)} className="text-red-900 hover:text-red-500 text-[10px] px-2 py-1 border border-red-900/30 rounded uppercase font-bold">Delete</button></td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            )}
                        </div>
                    </>
                )}

                {/* --- TAB CONTENT: AUDIO VAULT --- */}
                {activeTab === 'AUDIO' && (
                    <div className="flex-1 flex flex-col relative z-10 overflow-hidden">
                        {/* Audio Toolbar */}
                        <div className="h-14 bg-[#0f0a08] border-b border-[#3e2b22] flex items-center px-6 gap-4 shrink-0">
                            {isGeneratingAudio ? (
                                <div className="flex items-center gap-4 flex-1">
                                    <div className="text-[#c5a059] text-xs font-bold animate-pulse">Generating: {audioProgress.current}/{audioProgress.total}</div>
                                    <div className="flex-1 bg-black h-2 rounded-full overflow-hidden border border-[#3e2b22]">
                                        <div className="h-full bg-[#c5a059] transition-all duration-300" style={{ width: `${(audioProgress.current / (audioProgress.total || 1)) * 100}%` }}></div>
                                    </div>
                                    <div className="text-[9px] text-[#555] truncate max-w-xs">{audioProgress.msg}</div>
                                </div>
                            ) : (
                                <>
                                    <StylizedButton onClick={handleGenerateAudio} className="px-4 h-8 text-[10px] bg-[#3d0e0e] border-[#5c1010]">⚡ Generate Missing</StylizedButton>
                                    <StylizedButton onClick={handleExportAudio} className="px-4 h-8 text-[10px]">⬇ Export JSON</StylizedButton>
                                    <div className="relative">
                                        <StylizedButton onClick={()=>{}} className="px-4 h-8 text-[10px]">⬆ Import JSON</StylizedButton>
                                        <input type="file" accept=".json" onChange={handleImportAudio} className="absolute inset-0 opacity-0 cursor-pointer z-10" />
                                    </div>
                                    <div className="w-px h-6 bg-[#3e2b22] mx-2"></div>
                                    <button onClick={handleClearAudio} className="text-red-900 hover:text-red-500 text-[10px] font-bold uppercase">Wipe All</button>
                                </>
                            )}
                            <div className="ml-auto text-xs text-[#555] font-mono">{audioClips.length} Clips / {(audioClips.reduce((a,c)=>a+c.data.byteLength,0)/1024/1024).toFixed(2)} MB</div>
                        </div>

                        {/* Audio List */}
                        <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                {audioClips.map((clip) => {
                                    const isPlaying = playingKey === clip.key;
                                    return (
                                        <div key={clip.key} className={`bg-[#0a0807] border transition-all duration-300 p-3 rounded-sm flex items-center gap-3 group ${isPlaying ? 'border-[#c5a059] shadow-[0_0_15px_rgba(197,160,89,0.3)]' : 'border-[#3e2b22] hover:border-[#8c6239]'}`}>
                                            <div 
                                                className={`w-10 h-10 flex items-center justify-center rounded-full border cursor-pointer transition-all duration-300 ${isPlaying ? 'bg-[#c5a059] border-[#c5a059] scale-110' : 'bg-[#1a100a] border-[#3e2b22] group-hover:border-[#c5a059]'}`} 
                                                onClick={() => playClip(clip.key, clip.data)}
                                            >
                                                <span className={`text-xs ${isPlaying ? 'text-black animate-pulse' : 'text-[#c5a059]'}`}>{isPlaying ? '❚❚' : '▶'}</span>
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <div className="text-[#e6c278] text-xs font-bold truncate" title={clip.key}>{clip.key.replace('Zephyr:', '')}</div>
                                                <div className="text-[#555] text-[9px] font-mono flex justify-between">
                                                    <span>{(clip.data.byteLength / 1024).toFixed(1)} KB</span>
                                                    <span>{new Date(clip.timestamp).toLocaleTimeString()}</span>
                                                </div>
                                            </div>
                                            <button onClick={() => handleDeleteAudio(clip.key)} className="text-[#3e2b22] hover:text-red-500 px-2 transition-colors">✕</button>
                                        </div>
                                    );
                                })}
                                {audioClips.length === 0 && (
                                    <div className="col-span-full py-20 text-center text-[#555] italic">Audio Vault is empty. Generate or Import data.</div>
                                )}
                            </div>
                        </div>
                    </div>
                )}

                {/* --- TAB CONTENT: TELEMETRY (BLACKBOX) --- */}
                {activeTab === 'TELEMETRY' && (
                    <div className="flex-1 flex flex-col relative z-10 overflow-hidden">
                        <div className="h-14 bg-[#0f0a08] border-b border-[#3e2b22] flex items-center px-6 gap-4 shrink-0 justify-between">
                            <h2 className="text-[#e6c278] font-bold tracking-widest text-xs uppercase">System Blackbox (Local)</h2>
                            <div className="flex gap-2">
                                <StylizedButton onClick={handleExportLogs} className="px-4 h-8 text-[10px]">⬇ Export Logs</StylizedButton>
                                <button onClick={() => { telemetry.clearLogs(); setSystemLogs([]); }} className="text-red-900 hover:text-red-500 text-[10px] font-bold uppercase border border-red-900/30 px-3 py-1 rounded">Clear</button>
                            </div>
                        </div>
                        <div className="flex-1 overflow-y-auto p-4 custom-scrollbar bg-[#050302]">
                            <div className="font-mono text-[10px] space-y-1">
                                {systemLogs.length === 0 && <div className="text-[#555] text-center mt-10">No logs recorded.</div>}
                                {systemLogs.map(log => {
                                    let color = 'text-[#888]';
                                    if (log.level === 'ERROR' || log.level === 'FATAL') color = 'text-red-400';
                                    if (log.level === 'WARN') color = 'text-yellow-500';
                                    if (log.category === 'PERFORMANCE') color = 'text-purple-400';

                                    return (
                                        <div key={log.id} className="flex gap-2 border-b border-[#222] py-1 hover:bg-[#111]">
                                            <span className="text-[#444] shrink-0 w-24">{new Date(log.timestamp).toLocaleTimeString()}</span>
                                            <span className={`font-bold w-12 shrink-0 ${color}`}>{log.level}</span>
                                            <span className="text-[#555] w-20 shrink-0">[{log.category}]</span>
                                            <span className="text-[#ccc] flex-1 break-all">{log.message}</span>
                                            {log.metadata && (
                                                <span className="text-[#444] text-[9px] max-w-xs truncate">{JSON.stringify(log.metadata)}</span>
                                            )}
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};
