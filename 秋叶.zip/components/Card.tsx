
import React, { useMemo } from 'react';
import { Card as CardType, Suit, SuitStatus, LeadingEffectType, CardRank, CardColor } from '../types';
import { useSkin } from '../contexts/SkinContext';
import { useGameSettings } from '../hooks/useGameSettings';
import { ID_BAN_WEN, ID_KONG_WEN } from '../constants';

// 强化纸张纹理 (High Cost Filter)
const PAPER_URI = "data:image/svg+xml,%3Csvg viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='paper'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.4' numOctaves='3'/%3E%3CfeDiffuseLighting in='noise' lighting-color='%23fff' surfaceScale='2'%3E%3CfeDistantLight azimuth='45' elevation='60'/%3E%3C/feDiffuseLighting%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23paper)' opacity='0.12'/%3E%3C/svg%3E";

// --- COLOR CONFIG ---

const SUIT_SYMBOL_COLORS = {
    [Suit.CASH]:    '#1a1a1a', // ♠ Black
    [Suit.STRINGS]: '#dc2626', // ♥ Red
    [Suit.COINS]:   '#d97706', // ♣ Yellow/Amber
    [Suit.TEXTS]:   '#7c3aed'  // ♦ Purple
};

const RANK_COLORS = {
    [CardColor.RED]:   '#b91c1c', // 朱红
    [CardColor.GREEN]: '#15803d', // 翠绿
    [CardColor.BLACK]: '#0f172a'  // 墨黑
};

const SUIT_SYMBOLS = {
    [Suit.CASH]:    '♠',
    [Suit.STRINGS]: '♥',
    [Suit.COINS]:   '♣',
    [Suit.TEXTS]:   '♦'
};

interface LanternGlowConfig {
    color?: string;
    secondaryColor?: string; 
    intensity?: number;
}

interface CardProps {
  card: CardType;
  onClick?: (event: React.MouseEvent<HTMLDivElement>) => void;
  onTouchStart?: (event: React.TouchEvent<HTMLDivElement>) => void;
  isSelected?: boolean;
  isSmall?: boolean;
  isTrick?: boolean;
  isHand?: boolean;
  isFaceDown?: boolean;
  isInverted?: boolean; 
  isRotated?: boolean; 
  isBanker?: boolean; 
  isBaiLao?: boolean; 
  isSuspectedBaiLao?: boolean;
  isMature?: boolean; 
  isForbidden?: boolean; 
  isDraggable?: boolean;
  isSuggested?: boolean; 
  isDisabled?: boolean;
  isLocked?: boolean; 
  isWinner?: boolean; 
  leadingEffect?: LeadingEffectType; 
  domId?: string; 
  className?: string;
  style?: React.CSSProperties;
  suitStatus?: SuitStatus;
  textLayout?: 'vertical' | 'horizontal'; 
  textRotation?: number; 
  lanternGlow?: LanternGlowConfig | null;
  riskLevel?: 'WARNING' | 'PENALTY'; 
}

// --- ICONS (Scalable SVG) ---

const JadeBiIcon = ({ color, isEmpty = false, uid }: { color: string, isEmpty?: boolean, uid: string }) => {
    const gradId = `jadeGrad-${uid}`;
    return (
        <svg viewBox="0 0 100 100" className="w-full h-full overflow-visible drop-shadow-sm">
            <defs>
                <radialGradient id={gradId} cx="30%" cy="30%" r="80%">
                    <stop offset="0%" stopColor={color} stopOpacity="0.9" />
                    <stop offset="100%" stopColor={color} stopOpacity="1" />
                </radialGradient>
            </defs>
            <circle cx="50" cy="50" r={isEmpty ? "42" : "46"} fill={`url(#${gradId})`} stroke={color} strokeWidth="1.5" />
            <circle cx="50" cy="50" r={isEmpty ? "28" : "20"} fill="#fbf9f6" stroke={color} strokeWidth="1.5" opacity="0.95" /> 
            {!isEmpty && <circle cx="50" cy="50" r="10" fill={color} opacity="0.3" />}
            {isEmpty && <circle cx="50" cy="50" r="35" fill="none" stroke={color} strokeWidth="1.5" strokeDasharray="3 3" opacity="0.6" />}
        </svg>
    );
};

// [UPDATED] ZenBambooIcon: FULL SIZE MAHJONG STYLE
const ZenBambooIcon = ({ color, uid, isCompact = false }: { color: string, uid: string, isCompact?: boolean }) => {
    const gradId = `bambooGrad-${uid}`;
    const highlightId = `bambooHigh-${uid}`;
    
    // Geometry Constants - Maximized for visibility
    const Y_TOP = isCompact ? 3 : 8;
    const Y_BOT = isCompact ? 97 : 92;
    
    const WIDTH = isCompact ? 42 : 36; 
    const X_L = 50 - WIDTH/2;
    const X_R = 50 + WIDTH/2;

    return (
        <svg viewBox="0 0 100 100" className="w-full h-full overflow-visible drop-shadow-sm">
            <defs>
                <linearGradient id={gradId} x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor={color} stopOpacity="0.9" />
                    <stop offset="40%" stopColor={color} stopOpacity="1" />
                    <stop offset="60%" stopColor={color} stopOpacity="1" />
                    <stop offset="100%" stopColor={color} stopOpacity="0.8" />
                </linearGradient>
                <linearGradient id={highlightId} x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#ffffff" stopOpacity="0.1" />
                    <stop offset="30%" stopColor="#ffffff" stopOpacity="0.4" />
                    <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
                </linearGradient>
            </defs>
            
            <path 
                d={`M${X_L},${Y_TOP} L${X_R},${Y_TOP} L${X_R},${Y_BOT} L${X_L},${Y_BOT} Z`} 
                fill={`url(#${gradId})`} 
                stroke={color} 
                strokeWidth="3.5" 
                rx="3"
            />
            
            <path d={`M${X_L + 6},${Y_TOP + 2} L${X_L + 12},${Y_TOP + 2} L${X_L + 12},${Y_BOT - 2} L${X_L + 6},${Y_BOT - 2} Z`} fill={`url(#${highlightId})`} opacity="0.6" />

            <g transform="translate(0, 50)">
                <path d={`M${X_L - 2},0 Q50,5 ${X_R + 2},0`} stroke="rgba(255,255,255,0.7)" strokeWidth="2.5" fill="none" />
                <path d={`M${X_L - 2},0 Q50,-3 ${X_R + 2},0`} stroke={color} strokeWidth="1.5" strokeOpacity="0.5" fill="none" />
                <circle cx={X_L + 8} cy="-10" r="1.2" fill="rgba(255,255,255,0.4)" />
                <circle cx={X_R - 8} cy="8" r="1.2" fill="rgba(255,255,255,0.4)" />
            </g>

            <path d={`M${X_L},${Y_TOP} Q50,${Y_TOP - 3} ${X_R},${Y_TOP}`} stroke={color} strokeWidth="1.5" fill="none" opacity="0.6" />
            <path d={`M${X_L},${Y_BOT} Q50,${Y_BOT + 3} ${X_R},${Y_BOT}`} stroke={color} strokeWidth="1.5" fill="none" opacity="0.6" />
        </svg>
    );
};

const SparrowIcon = ({ uid }: { uid: string }) => {
    return (
        <svg viewBox="0 0 100 100" className="w-full h-full overflow-visible drop-shadow-md">
            <defs>
                <radialGradient id={`birdBody-${uid}`} cx="50%" cy="50%" r="60%">
                    <stop offset="0%" stopColor="#10b981" /> 
                    <stop offset="100%" stopColor="#047857" />
                </radialGradient>
                <linearGradient id={`birdWing-${uid}`} x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#ef4444" /> 
                    <stop offset="100%" stopColor="#991b1b" />
                </linearGradient>
                <linearGradient id={`birdTail-${uid}`} x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="#3b82f6" /> 
                    <stop offset="100%" stopColor="#10b981" />
                </linearGradient>
            </defs>

            <g transform="translate(50, 75)">
                <path d="M0,0 Q-20,15 -30,-10" stroke={`url(#birdTail-${uid})`} strokeWidth="3" fill="none" />
                <path d="M0,0 Q0,20 0,-15" stroke={`url(#birdTail-${uid})`} strokeWidth="3" fill="none" />
                <path d="M0,0 Q20,15 30,-10" stroke={`url(#birdTail-${uid})`} strokeWidth="3" fill="none" />
            </g>

            <path d="M40,75 L35,85" stroke="#d97706" strokeWidth="2" strokeLinecap="round" />
            <path d="M60,75 L65,85" stroke="#d97706" strokeWidth="2" strokeLinecap="round" />

            <ellipse cx="50" cy="55" rx="20" ry="25" fill={`url(#birdBody-${uid})`} />
            <ellipse cx="50" cy="55" rx="12" ry="18" fill="#ecfdf5" opacity="0.8" />

            <path d="M30,45 Q20,60 30,70" fill="none" stroke={`url(#birdWing-${uid})`} strokeWidth="4" strokeLinecap="round" />
            <path d="M70,45 Q80,60 70,70" fill="none" stroke={`url(#birdWing-${uid})`} strokeWidth="4" strokeLinecap="round" />

            <circle cx="50" cy="30" r="14" fill={`url(#birdBody-${uid})`} />
            
            <circle cx="45" cy="28" r="2" fill="white" />
            <circle cx="45" cy="28" r="0.8" fill="black" />
            <circle cx="55" cy="28" r="2" fill="white" />
            <circle cx="55" cy="28" r="0.8" fill="black" />

            <path d="M48,35 L52,35 L50,42 Z" fill="#fbbf24" stroke="#d97706" strokeWidth="0.5" />
            <path d="M50,16 L45,22 L50,20 L55,22 Z" fill="#ef4444" />
        </svg>
    );
};

const RedPlumIcon = ({ uid }: { uid: string }) => (
    <svg viewBox="0 0 100 100" className="w-full h-full overflow-visible drop-shadow-md">
        <path d="M50,95 Q40,60 10,50 T20,10" fill="none" stroke="#3e2723" strokeWidth="8" strokeLinecap="round" />
        <path d="M50,65 Q70,55 90,30" fill="none" stroke="#3e2723" strokeWidth="5" strokeLinecap="round" />
        {[{x:20,y:20,s:1.6}, {x:85,y:30,s:1.3}, {x:40,y:45,s:1.1}, {x:20,y:70,s:0.9}].map((p, i) => (
            <g key={i} transform={`translate(${p.x}, ${p.y}) scale(${p.s})`}>
                <circle r="9" fill="#e11d48" stroke="#881337" strokeWidth="1" />
                <circle r="3.5" fill="#fbbf24" />
            </g>
        ))}
    </svg>
);

const MahjongLayout = ({ suit, value, mainColor, isSmall, cardId, uid }: { suit: Suit, value: number, mainColor: string, isSmall: boolean, cardId?: string, uid: string }) => {
    
    if (cardId === ID_BAN_WEN) {
        return <div className="w-[90%] h-[90%] animate-pulse-slow"><RedPlumIcon uid={uid} /></div>;
    }
    if (cardId === ID_KONG_WEN) {
        return <div className="w-[85%] h-[85%]"><JadeBiIcon color={mainColor} isEmpty={true} uid={uid} /></div>;
    }

    if (suit === Suit.COINS && value === 1) {
        return <div className="w-[90%] h-[90%]"><SparrowIcon uid={uid} /></div>;
    }

    const count = suit === Suit.TEXTS ? (10 - value) : value; 
    
    const isCompact = (count === 8 || count === 9) && suit === Suit.COINS;
    const renderItem = (i: number) => (
        suit === Suit.TEXTS 
            ? <JadeBiIcon color={mainColor} uid={`${uid}-${i}`} />
            : <ZenBambooIcon color={mainColor} uid={`${uid}-${i}`} isCompact={isCompact} />
    );

    const renderLayout = () => {
        switch (count) {
            case 1: 
                return <div className="w-[85%] h-[85%] flex items-center justify-center">{renderItem(0)}</div>;
            case 2: 
                return (
                    <div className="flex flex-col h-full justify-evenly items-center w-[55%]">
                        <div className="w-full h-[45%] flex items-center justify-center">{renderItem(0)}</div>
                        <div className="w-full h-[45%] flex items-center justify-center">{renderItem(1)}</div>
                    </div>
                );
            case 3: 
                return (
                    <div className="w-full h-full relative p-[2%]">
                        <div className="absolute top-[5%] left-1/2 -translate-x-1/2 w-[38%] h-[38%]">{renderItem(0)}</div>
                        <div className="absolute bottom-[5%] left-[5%] w-[38%] h-[38%]">{renderItem(1)}</div>
                        <div className="absolute bottom-[5%] right-[5%] w-[38%] h-[38%]">{renderItem(2)}</div>
                    </div>
                );
            case 4: 
                if (suit === Suit.COINS) {
                    return (
                        <div className="w-full h-full relative p-[2%]">
                            <div className="absolute top-[8%] left-[10%] w-[38%] h-[38%]">{renderItem(0)}</div>
                            <div className="absolute top-[8%] right-[10%] w-[38%] h-[38%]">{renderItem(1)}</div>
                            <div className="absolute bottom-[8%] left-[10%] w-[38%] h-[38%]">{renderItem(2)}</div>
                            <div className="absolute bottom-[8%] right-[10%] w-[38%] h-[38%]">{renderItem(3)}</div>
                        </div>
                    );
                }
                return (
                    <div className="w-[80%] h-[85%] grid grid-cols-2 gap-x-2 gap-y-2 place-items-center">
                        {[0,1,2,3].map(i => <div key={i} className="w-[75%] h-[85%]">{renderItem(i)}</div>)}
                    </div>
                );
            case 5: 
                return (
                    <div className="w-[90%] h-[95%] flex flex-col justify-between items-center py-[2%]">
                        <div className="flex justify-between w-full h-[30%] px-[12%]"><div className="w-[45%]">{renderItem(0)}</div><div className="w-[45%]">{renderItem(1)}</div></div>
                        <div className="w-[40%] h-[30%]">{renderItem(2)}</div>
                        <div className="flex justify-between w-full h-[30%] px-[12%]"><div className="w-[45%]">{renderItem(3)}</div><div className="w-[45%]">{renderItem(4)}</div></div>
                    </div>
                );
            case 6: 
                if (suit === Suit.COINS) {
                    return (
                        <div className="w-[90%] h-[96%] flex flex-col justify-between items-center py-[2%]">
                            <div className="flex justify-between w-full h-[30%] px-[15%]"><div className="w-[45%]">{renderItem(0)}</div><div className="w-[45%]">{renderItem(1)}</div></div>
                            <div className="flex justify-between w-full h-[30%] px-[15%]"><div className="w-[45%]">{renderItem(2)}</div><div className="w-[45%]">{renderItem(3)}</div></div>
                            <div className="flex justify-between w-full h-[30%] px-[15%]"><div className="w-[45%]">{renderItem(4)}</div><div className="w-[45%]">{renderItem(5)}</div></div>
                        </div>
                    );
                }
                return (
                    <div className="w-[80%] h-[92%] grid grid-cols-2 gap-x-2 gap-y-1 place-items-center">
                        {[0,1,2,3,4,5].map(i => <div key={i} className="w-[70%] h-[85%]">{renderItem(i)}</div>)}
                    </div>
                );
            case 7:
                if (suit === Suit.COINS) {
                    return (
                        <div className="w-[90%] h-[96%] flex flex-col justify-between items-center py-[2%]">
                            <div className="flex justify-between w-full h-[28%] px-[15%]"><div className="w-[45%]">{renderItem(0)}</div><div className="w-[45%]">{renderItem(1)}</div></div>
                            <div className="flex justify-between w-full h-[28%] px-[15%]"><div className="w-[45%]">{renderItem(2)}</div><div className="w-[45%]">{renderItem(3)}</div></div>
                            <div className="flex justify-between w-full h-[28%] px-[5%]"><div className="w-[32%]">{renderItem(4)}</div><div className="w-[32%]">{renderItem(5)}</div><div className="w-[32%]">{renderItem(6)}</div></div>
                        </div>
                    );
                }
                return (
                    <div className="w-[95%] h-[96%] flex flex-col justify-between items-center py-[1%]">
                        <div className="flex justify-evenly w-[60%] h-[22%]"><div className="w-[42%]">{renderItem(0)}</div><div className="w-[42%]">{renderItem(1)}</div></div>
                        <div className="flex justify-between w-full h-[22%] px-[10%]"><div className="w-[28%]">{renderItem(2)}</div><div className="w-[28%]">{renderItem(3)}</div><div className="w-[28%]">{renderItem(4)}</div></div>
                        <div className="flex justify-evenly w-[60%] h-[22%]"><div className="w-[42%]">{renderItem(5)}</div><div className="w-[42%]">{renderItem(6)}</div></div>
                    </div>
                );
            case 8: 
                if (suit === Suit.COINS) {
                    const renderSlanted = (idx: number, slant: number) => (
                        <div key={idx} className="w-[24%] h-[100%] flex items-center justify-center" style={{ transform: `rotate(${slant}deg)` }}>
                            {renderItem(idx)}
                        </div>
                    );
                    return (
                        <div className="w-[98%] h-[92%] flex flex-col justify-between items-center py-1">
                            <div className="w-full h-[45%] flex justify-between px-0">
                                {renderSlanted(0, 20)} {renderSlanted(1, -20)} {renderSlanted(2, 20)} {renderSlanted(3, -20)}
                            </div>
                            <div className="w-full h-[45%] flex justify-between px-0">
                                {renderSlanted(4, 20)} {renderSlanted(5, -20)} {renderSlanted(6, 20)} {renderSlanted(7, -20)}
                            </div>
                        </div>
                    );
                }
                return (
                    <div className="w-[85%] h-[98%] grid grid-cols-2 gap-x-1 gap-y-[1px] place-items-center">
                        {[0,1,2,3,4,5,6,7].map(i => <div key={i} className="w-[60%] h-[85%] flex items-center justify-center">{renderItem(i)}</div>)}
                    </div>
                );
            case 9: 
                if (suit === Suit.COINS) {
                    return (
                        <div className="w-[98%] h-[98%] grid grid-cols-3 gap-0 place-items-center content-stretch">
                            {[0,1,2,3,4,5,6,7,8].map(i => <div key={i} className="w-full h-full flex items-center justify-center px-[2px]">{renderItem(i)}</div>)}
                        </div>
                    );
                }
                return (
                    <div className="w-[98%] h-[95%] grid grid-cols-3 gap-[1px] place-items-center">
                        {[0,1,2,3,4,5,6,7,8].map(i => <div key={i} className="w-[65%] h-[85%] flex items-center justify-center">{renderItem(i)}</div>)}
                    </div>
                );
            default: return null;
        }
    };

    return (
        <div className="w-full h-full flex items-center justify-center">
            {renderLayout()}
        </div>
    );
};

const getPokerDisplay = (val: number) => val.toString();

const CardBase: React.FC<CardProps> = (props) => {
  const { card, onClick, style, domId, textRotation = 0, isRotated = false, isLocked, suitStatus, riskLevel } = props;
  const { skin } = useSkin();
  const { graphicsQuality } = useGameSettings(); 
  
  const uid = useMemo(() => `c${Math.random().toString(36).substr(2, 9)}`, []);
  
  // Use Vertical text if explicitly requested OR naturally not rotated (for Cash/Strings)
  // [FIX] Support explicit vertical layout override for small cards
  const isVerticalText = props.textLayout ? props.textLayout === 'vertical' : !isRotated; 

  if (!card) return null;

  // --- STYLES ---
  const containerClass = useMemo(() => skin.card.getContainerClass(props).replace('rounded-[2px]', 'rounded-[6px]'), [skin, props]);
  
  // 1. RANK COLOR
  const rankHexColor = props.isInverted ? '#d4af37' : RANK_COLORS[card.color];
  const rankColorClass = useMemo(() => skin.card.getMainColorClass(card.color, props.isInverted), [skin, card.color, props.isInverted]);
  
  // 2. SUIT COLOR
  const symbolHexColor = props.isInverted ? '#d4af37' : SUIT_SYMBOL_COLORS[card.suit];
  const suitSymbol = SUIT_SYMBOLS[card.suit];

  const rotationStyle = useMemo(() => textRotation ? { transform: `rotate(${textRotation}deg)` } : {}, [textRotation]);
  const effectiveRisk = riskLevel || (props.isForbidden ? 'PENALTY' : null);
  const riskBorderClass = effectiveRisk === 'PENALTY' ? '!border-red-600/90 !shadow-[0_0_15px_rgba(220,38,38,0.6)]' : (effectiveRisk === 'WARNING' ? '!border-amber-500/90 !shadow-[0_0_15px_rgba(245,158,11,0.6)]' : '');

  const THICKNESS_PX = props.isSmall ? 1 : 4; 
  let edgeColor = '#c9c1ac';
  if (skin.id === 'imperial') edgeColor = '#1c1815'; 

  const engravedTextStyle = useMemo(() => ({
      ...(textRotation ? { transform: `rotate(${textRotation}deg)` } : {}),
      textShadow: graphicsQuality === 'HIGH' && !props.isInverted ? '0 0.5px 0px rgba(255,255,255,0.4)' : 'none',
      mixBlendMode: props.isInverted || props.isSmall ? 'normal' : 'multiply'
  }), [graphicsQuality, props.isInverted, textRotation, props.isSmall]);

  // Background with Texture
  const faceBgStyle = useMemo(() => {
      if (props.isInverted) return { background: 'linear-gradient(145deg, #1a1614, #0d0908)' };
      
      let baseGradient = 'linear-gradient(145deg, #fbf9f6, #efebe6)';
      if (card.color === CardColor.RED) baseGradient = 'linear-gradient(145deg, #fffafa, #fceceb)';
      if (card.color === CardColor.GREEN) baseGradient = 'linear-gradient(145deg, #f2fdf6, #eaf7f0)';
      
      return { background: baseGradient };
  }, [props.isInverted, card.color]);
  
  const enableTexture = skin.id === 'imperial' && !props.isInverted && !props.isFaceDown && (graphicsQuality === 'HIGH' || !props.isSmall);
  const textureOverlay = enableTexture ? `url("${PAPER_URI}")` : 'none';

  const finalStyle: React.CSSProperties = useMemo(() => ({ 
      transformStyle: props.isSmall ? 'flat' : 'preserve-3d', 
      willChange: props.isHand || props.isTrick ? 'transform' : 'auto',
      outline: '1px solid transparent',
      ...style 
  }), [style, props.isHand, props.isTrick, props.isSmall]);

  // --- CORNER INDEX COMPONENT ---
  const CornerIndex = ({ positionClass }: { positionClass: string }) => (
      <div className={`absolute ${positionClass} z-30 flex flex-col items-center pointer-events-none`}>
          <div className={`flex flex-col items-center leading-none`} style={{ ...engravedTextStyle as any }}>
              <span className={`${props.isSmall ? 'text-[12px] -mb-[2px]' : 'text-3xl md:text-4xl -mb-1'} font-black font-serif tracking-tighter ${rankColorClass} leading-none`}>
                  {getPokerDisplay(card.value)}
              </span>
              <span className={`${props.isSmall ? 'text-[8px]' : 'text-lg md:text-xl'} leading-none`} style={{ color: symbolHexColor }}>
                  {suitSymbol}
              </span>
          </div>
      </div>
  );

  const CardFaceContent = () => {
      if (props.isFaceDown) {
          return (
              <div className="w-full h-full rounded-[inherit] overflow-hidden relative">
                  <skin.card.BackComponent isSmall={props.isSmall} />
              </div>
          );
      }

      const useIconMode = !props.isSmall && (card.suit === Suit.COINS || card.suit === Suit.TEXTS);
      
      // [FIX] Layout Strategy: Reduced padding for isSmall mode + vertical text
      const contentContainerClass = props.isSmall 
          ? (isVerticalText ? "absolute inset-0 z-10 flex items-center justify-center pl-[20%] pr-[2%] pt-[15%] pb-[5%]" : "absolute inset-0 z-10 flex items-center justify-center pl-[32%] pr-[2%] pt-[18%] pb-[5%]")
          : "absolute top-[24%] bottom-[8%] left-[14%] right-[6%] z-10 flex items-center justify-center";

      return (
          <div className={`w-full h-full rounded-[inherit] overflow-hidden relative shadow-[inset_0_0_20px_rgba(0,0,0,0.05)]`} style={faceBgStyle}>
              {enableTexture && (<div className="absolute inset-0 pointer-events-none mix-blend-multiply z-0 opacity-40" style={{ backgroundImage: textureOverlay }}></div>)}
              
              <div className="absolute inset-[3px] border-[0.5px] border-black/5 rounded-[3px] pointer-events-none z-10"></div>

              <div className={contentContainerClass}>
                  {useIconMode ? (
                      <MahjongLayout 
                          suit={card.suit} 
                          value={card.value} 
                          mainColor={rankHexColor} 
                          isSmall={props.isSmall || false} 
                          cardId={card.id} 
                          uid={uid} 
                      />
                  ) : (
                      <div className={`flex flex-col items-center justify-center leading-none ${props.isSmall ? 'gap-0' : 'gap-1'} w-full h-full px-1`}>
                          {isVerticalText && (!props.isSmall || props.textLayout === 'vertical') ? (
                              card.name.split('').map((char, i) => (
                                  <span key={i} className={`block font-calligraphy ${props.isSmall ? 'text-xs' : 'text-3xl md:text-4xl'} ${rankColorClass} font-bold`} style={engravedTextStyle as any}>
                                      {char}
                                  </span>
                              ))
                          ) : (
                              <span className={`font-calligraphy ${props.isSmall ? 'text-[10px]' : 'text-2xl md:text-3xl'} ${rankColorClass} whitespace-nowrap font-bold`} style={engravedTextStyle as any}>
                                  {card.name}
                              </span>
                          )}
                      </div>
                  )}
              </div>

              <CornerIndex positionClass={props.isSmall ? "top-[1px] left-[1px]" : "top-[4px] left-[6px]"} />
              
              {props.isBanker && (
                  <div className="absolute top-1 right-1 z-30" style={rotationStyle}>
                      <div className="w-5 h-5 md:w-6 md:h-6 rounded-full bg-[#8c1c0b] border border-[#d4af37] flex items-center justify-center shadow-lg">
                          <span className="text-[9px] text-[#fff] font-serif font-black">庄</span>
                      </div>
                  </div>
              )}
              {props.isHand && suitStatus && suitStatus !== 'NEUTRAL' && (
                  <div className="absolute bottom-2 left-2 z-30 pointer-events-none">
                      <div className={`w-2 h-2 rounded-full border border-black/10 ${suitStatus === 'FORBIDDEN' ? 'bg-[#991b1b]' : 'bg-[#065f46]'}`} />
                  </div>
              )}
              <skin.card.EffectOverlay effect={props.leadingEffect || (props.isWinner ? 'GOLD' : null)} />
          </div>
      );
  };

  return (
    <div id={domId} 
         // [FIX] Added props.className to allow external overrides (e.g. shadow removal)
         className={`${containerClass} ${riskBorderClass} relative aspect-[2/3] ${skin.card.getBorderClass(props)} ${skin.card.getShadowClass(props)} ${isLocked ? '!cursor-default !transform-none !transition-none pointer-events-none' : ''} ${props.className || ''} flex-shrink-0`} 
         style={finalStyle} 
         onClick={props.isDisabled || isLocked ? undefined : onClick} 
    >
      <div className={`absolute inset-0 z-20 rounded-[inherit] ${props.isSmall ? '' : 'backface-hidden'}`} 
           style={{ transform: props.isSmall ? 'none' : `translateZ(${THICKNESS_PX}px)` }}>
          <CardFaceContent />
      </div>

      {effectiveRisk && !props.isFaceDown && !props.isSmall && (
          <div className="absolute -top-3 -right-3 z-[100] opacity-0 group-hover:opacity-100 transition-all duration-300 transform group-hover:scale-110 pointer-events-none backface-hidden" style={{ transform: `translateZ(${THICKNESS_PX + 2}px)` }}>
              <div className={`w-6 h-6 rounded-full flex items-center justify-center border-2 border-[#0a0807] shadow-lg ${effectiveRisk === 'PENALTY' ? 'bg-red-600' : 'bg-amber-500'}`}>
                  <span className="text-white text-xs font-black font-serif select-none">!</span>
              </div>
          </div>
      )}

      {!props.isSmall && [...Array(4)].map((_, i) => (
          <div key={`edge-${i}`} className="absolute inset-0 rounded-[inherit] pointer-events-none z-10" style={{ background: edgeColor, transform: `translateZ(${THICKNESS_PX - i * 1.0}px)`, filter: `brightness(${1 - i * 0.1})` }}></div>
      ))}
      
      {!props.isSmall && (
          <div className="absolute inset-0 backface-hidden z-20 rounded-[inherit]" style={{ transform: `rotateY(180deg) translateZ(${THICKNESS_PX}px)` }}>
              <div className="w-full h-full rounded-[inherit] overflow-hidden relative bg-[#050303]"><skin.card.BackComponent isSmall={props.isSmall} /></div>
          </div>
      )}
    </div>
  );
};

export default React.memo(CardBase);
