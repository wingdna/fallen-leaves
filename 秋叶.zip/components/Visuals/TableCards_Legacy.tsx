
import React from 'react';
import CardComponent from '../Card';
import { GamePhase, Card, Player, KaiChongDetail } from '../../types';
import { Player3DConfig } from '../../services/layoutConfig';

interface PotPileProps {
    pot: Card[];
    currentIndex: number;
    phase: GamePhase;
    cardScale: number;
    quality: string;
    players: Player[];
    history?: KaiChongDetail[];
}

export const PotPile = React.memo(({ pot, currentIndex, phase, cardScale, quality, players, history = [] }: PotPileProps) => {
    if (phase !== GamePhase.KAI_CHONG || !pot) return null;
    const isLow = quality === 'LOW';
    const spacingPercent = 13;

    return (
        <div className="absolute inset-0 pointer-events-none" style={{ transformStyle: isLow ? 'flat' : 'preserve-3d' }}>
            {pot.map((card, i) => {
                const match = history.find((h) => h.matchedCard.id === card.id);
                let flyTransform = '';
                let opacity = 1;
                if (match) {
                    const winner = players.find((p) => p.id === match.playerId);
                    const pos = winner?.position;
                    const FLY_DIST = 800;
                    if (pos === 'Top') flyTransform = `translateY(${-FLY_DIST}px) translateZ(100px)`;
                    else if (pos === 'Bottom') flyTransform = `translateY(${FLY_DIST}px) translateZ(100px)`;
                    else if (pos === 'Left') flyTransform = `translateX(${-FLY_DIST}px) translateZ(100px)`;
                    else if (pos === 'Right') flyTransform = `translateX(${FLY_DIST}px) translateZ(100px)`;
                    opacity = 0;
                }
                const isActive = i === currentIndex;
                const isRevealed = i < currentIndex || !!match;
                const activeTransform = isActive ? `translateZ(50px) scale(1.2)` : `scale(1.0)`;

                return (
                    <div key={card.id} className="absolute transition-all duration-[800ms]" 
                         style={{ 
                            left: `${50 + (i - 3) * spacingPercent}%`, top: '50%',
                            width: 96 * cardScale, height: 144 * cardScale,
                            marginLeft: -(96 * cardScale) / 2, marginTop: -(144 * cardScale) / 2,
                            transform: match ? flyTransform : `translateZ(${40 + i * 2}px) ${activeTransform}`,
                            opacity: opacity,
                            transformStyle: isLow ? 'flat' : 'preserve-3d',
                            zIndex: isActive ? 100 : 50 + i
                         }}>
                        <CardComponent card={card} isFaceDown={!isRevealed} isSmall={false} isInverted={true} className="w-full h-full shadow-2xl" />
                    </div>
                );
            })}
        </div>
    );
});

interface WonCardPilesProps {
    players: Player[];
    players3DConfig: Record<string, Player3DConfig>;
    cardScale: number;
    quality: string;
    highlightedCardIds?: Set<string>;
}

export const WonCardPiles = React.memo(({ players, players3DConfig, cardScale, quality, highlightedCardIds }: WonCardPilesProps) => {
    const isLow = quality === 'LOW';
    const wonScale = cardScale * 0.9;
    const cardW = 96 * wonScale;
    const cardH = 144 * wonScale;

    return (
        <div className="absolute inset-0 pointer-events-none" style={{ transformStyle: isLow ? 'flat' : 'preserve-3d' }}>
            {players.map((p) => {
                const cards = p.capturedCards || [];
                if (cards.length === 0) return null;
                const config = players3DConfig[p.position];
                if (!config?.wonCardsTablePos) return null;
                const pos = config.wonCardsTablePos;
                const isSide = Math.abs(pos.rotateZ || 0) === 90 || Math.abs(pos.rotateZ || 0) === 270;
                
                let transformStr = `translateZ(2px) ${isSide ? 'translateY(-50%)' : 'translateX(-50%)'}`;
                const anchorStyle: React.CSSProperties = { 
                    position: 'absolute', transform: transformStr, transformStyle: isLow ? 'flat' : 'preserve-3d', zIndex: 20,
                    top: pos.top, bottom: pos.bottom, left: pos.left, right: pos.right
                };

                return (
                    <div key={`won-${p.id}`} style={anchorStyle}>
                        <div className="bg-[#050302]/80 border border-white/5 rounded-md p-1.5 flex" 
                             style={{ 
                                 transform: `rotateZ(${isSide ? 0 : (pos.rotateZ || 0)}deg)`, 
                                 flexDirection: isSide ? 'column' : 'row',
                                 width: isSide ? (cardH + 20) : 'auto', height: isSide ? 'auto' : (cardH + 12)
                             }}>
                            <div className={`flex ${isSide ? '-space-y-12 flex-col' : '-space-x-8 flex-row'} items-center`}>
                                {cards.map((card, idx) => (
                                    <div key={`${card.id}-${idx}`} style={{ 
                                        width: cardW, 
                                        height: cardH, 
                                        flexShrink: 0, 
                                        transform: `translateZ(${idx * 0.5}px) rotateZ(${isSide ? (pos.rotateZ || 90) : 0}deg)`,
                                    }}>
                                        <div className="w-full h-full relative">
                                            {/* [VISUAL UPDATE] Dark Overlay for Won Cards */}
                                            <div className="absolute inset-0 z-50 bg-black/40 pointer-events-none rounded-[inherit]"></div>
                                            <CardComponent card={card} isSmall={false} isLocked={true} isInverted={!!card.isPot} className="w-full h-full" />
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                );
            })}
        </div>
    );
});
