
import React, { useMemo } from 'react';
import { GamePhase } from '../../types';
import { useSkin } from '../../contexts/SkinContext';
import { Compass, StoveLighting, TableBorderFlow } from './TableEffects';
import { useGameSettings } from '../../hooks/useGameSettings';
import { useLayoutEngine } from '../../hooks/useLayoutEngine';
import { TableSlab } from './TableSlab';
import { TableCards, WonCardPiles, PotPile } from './TableCards';
import CardComponent from '../Card';
import { Sky, Stars } from '@react-three/drei';

// --- LAYER 1: STATIC ENVIRONMENT (Background & Table Body) ---
const StaticEnvironment = React.memo(({ skin, layout, quality, timeOfDay }: any) => {
    const isLow = quality === 'LOW';
    const parallax = isLow ? { rotateX: 0, rotateY: 0, translateX: 0, translateY: 0 } : (layout.parallax || { rotateX: 0, rotateY: 0, translateX: 0, translateY: 0 });
    
    const tableTransform: React.CSSProperties = {
        top: `${layout.table.yOffset}px`, 
        width: layout.table.width, 
        height: layout.table.height,
        transform: 'translate(-50%, -50%)',
        transformStyle: isLow ? 'flat' : 'preserve-3d',
    };

    // Calculate Sun Position based on Time (0-24)
    // 6:00 = Rise, 12:00 = Zenith, 18:00 = Set, 24:00 = Nadir
    const sunAngle = ((timeOfDay - 6) / 24) * Math.PI * 2;
    const sunY = Math.sin(sunAngle) * 100;
    const sunZ = Math.cos(sunAngle) * 100;
    const isDay = timeOfDay > 6 && timeOfDay < 18;

    return (
        <>
            {/* 1. Atmosphere (Background Layer) */}
            <div className="absolute inset-0 pointer-events-none z-0" 
                 style={{ 
                     transform: `scale(1.15) translate(${parallax.translateX}px, ${parallax.translateY}px)`,
                     transition: 'transform 0.1s linear'
                 }}>
                {quality !== 'LOW' && skin?.layout?.atmosphereComponent && <skin.layout.atmosphereComponent quality={quality} timeOfDay={timeOfDay} />}
            </div>

            {/* 2. Table Structure (ABSOLUTELY STATIC) */}
            <div className="absolute inset-0 w-full h-full" 
                 style={{ 
                    transform: `
                        translateZ(${layout.camera.z}px) 
                        rotateX(${layout.camera.rotateX}deg) 
                    `,
                    transformStyle: isLow ? 'flat' : 'preserve-3d',
                    transition: 'transform 0.5s ease-out'
                 }}>
                
                <div className="absolute left-1/2 top-0" style={tableTransform}>
                    <TableSlab skin={skin} width="100%" height="100%" thickness={layout.table.thickness} quality={quality} timeOfDay={timeOfDay} />
                </div>
            </div>
        </>
    );
}, (prev, next) => {
    // Re-render on time change (every minute or so if cycling)
    if (Math.abs(prev.timeOfDay - next.timeOfDay) > 0.1) return false;
    return prev.layout === next.layout && prev.skin === next.skin && prev.quality === next.quality; 
});

// --- LAYER 2: DYNAMIC GAMEPLAY (Cards, Chips, Effects) ---
const DynamicLayer = ({ players, tableCards, mianZhangCard, phase, currentPlayerIndex, bankerId, trickWinnerId, pot, kaiChongCardIndex, kaiChongHistory, layout, skin, quality, interactionState, highlightedCardIds, timeOfDay }: any) => {
    const isLow = quality === 'LOW';
    
    const tableTransform: React.CSSProperties = {
        top: `${layout.table.yOffset}px`, 
        width: layout.table.width, 
        height: layout.table.height,
        transform: 'translate(-50%, -50%)',
        transformStyle: isLow ? 'flat' : 'preserve-3d',
    };

    const zSurface = layout.table.thickness / 2;
    const compassZ = 1; 

    const hasWonCards = useMemo(() => {
        return players.some((p: any) => p.capturedCards && p.capturedCards.length > 0);
    }, [players]);

    const baiLaoId = useMemo(() => {
        const revealed = players.find((p: any) => p.isBaiLaoRevealed);
        if (revealed) return revealed.id;
        const suspected = players.find((p: any) => p.isSuspectedBaiLao);
        return suspected ? suspected.id : undefined;
    }, [players]);

    const showMianZhang = !!mianZhangCard && !hasWonCards;

    // Adjust stove lighting intensity based on time
    const isNight = timeOfDay < 6 || timeOfDay > 18;
    const lightingQuality = isNight ? 'HIGH' : (quality === 'LOW' ? 'LOW' : 'MEDIUM');

    return (
        <div className="absolute inset-0 w-full h-full pointer-events-none" 
             style={{ 
                transform: `
                    translateZ(${layout.camera.z}px) 
                    rotateX(${layout.camera.rotateX}deg)
                `,
                transformStyle: isLow ? 'flat' : 'preserve-3d',
                transition: 'transform 0.5s ease-out'
             }}>
            
            <div className="absolute left-1/2 top-0" style={tableTransform}>
                
                <div className="absolute inset-0" style={{ transform: `translateZ(${zSurface}px)`, transformStyle: 'preserve-3d' }}>
                    
                    {/* 1. Effects Layer - Brighter Stove at Night */}
                    <StoveLighting activePlayerId={currentPlayerIndex} quality={lightingQuality} />
                    <TableBorderFlow quality={quality} />
                    
                    {/* 2. Game Objects */}
                    <WonCardPiles 
                        players={players} 
                        players3DConfig={layout.players3D} 
                        cardScale={layout.cardScale} 
                        quality={quality} 
                        highlightedCardIds={highlightedCardIds} 
                    />
                    
                    {showMianZhang && (
                        <div className="absolute z-10"
                                style={{
                                    top: layout.mianZhangPos.top,
                                    left: layout.mianZhangPos.left,
                                    right: layout.mianZhangPos.right,
                                    bottom: layout.mianZhangPos.bottom,
                                    transform: `rotateZ(${layout.mianZhangPos.rotateZ || 0}deg) translateZ(10px)`,
                                    transformStyle: isLow ? 'flat' : 'preserve-3d',
                                    width: `${96 * layout.cardScale * layout.tableCardConfig.scale}px`,
                                    height: `${144 * layout.cardScale * layout.tableCardConfig.scale}px`
                                }}>
                            <CardComponent card={mianZhangCard} isSmall={false} isFaceDown={false} isInverted={true} className="w-full h-full shadow-lg" />
                        </div>
                    )}

                    <div className="absolute inset-0 flex items-center justify-center" 
                            style={{ 
                            transform: `translateY(${layout.compass.yOffset}px) translateZ(${compassZ}px)`, 
                            transformStyle: isLow ? 'flat' : 'preserve-3d' 
                            }}>
                        <div style={{ width: layout.compass.size, height: layout.compass.size }} className="aspect-square relative pointer-events-none">
                            
                            <Compass 
                                activePlayerId={currentPlayerIndex} 
                                bankerId={bankerId} 
                                baiLaoId={baiLaoId}
                                tableCards={tableCards}
                                shape={layout.compass.shape}
                                needleScale={layout.compass.needleScale}
                            />
                            
                            <div className="absolute inset-0" style={{ transformStyle: isLow ? 'flat' : 'preserve-3d' }}>
                                <PotPile 
                                    pot={pot} 
                                    currentIndex={kaiChongCardIndex} 
                                    phase={phase} 
                                    cardScale={layout.cardScale}
                                    quality={quality} 
                                    players={players}
                                    history={kaiChongHistory}
                                />
                                <TableCards 
                                    cards={tableCards} 
                                    winnerId={trickWinnerId} 
                                    config={layout.tableCardConfig} 
                                    spread={layout.tableCardSpread}
                                    centerOffset={layout.cardCenterOffset}
                                    cardScale={layout.cardScale}
                                    players={players} 
                                    quality={quality} 
                                />
                                
                                {interactionState?.onActionClick && !layout.hide3DActionPlate && (
                                     <div 
                                        className="absolute inset-0 z-[200] cursor-pointer" 
                                        onClick={interactionState.onActionClick}
                                        style={{ transform: `translateZ(60px)` }}
                                     ></div>
                                )}
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    );
};

export const Scene3D = React.memo(({ players, tableCards, mianZhangCard, phase, currentPlayerIndex, bankerId, trickWinnerId, pot, kaiChongCardIndex, kaiChongHistory, interactionState, highlightedCardIds }: any) => {
    const { skin } = useSkin();
    const { graphicsQuality, timeOfDay } = useGameSettings();
    const layout = useLayoutEngine(); 

    return (
        <div className="absolute w-full h-full overflow-hidden" style={{ perspective: layout.camera.perspective }}>
            {/* Background Layer */}
            <StaticEnvironment skin={skin} layout={layout} quality={graphicsQuality} timeOfDay={timeOfDay} />
            
            {/* Gameplay Layer */}
            <DynamicLayer 
                players={players}
                tableCards={tableCards}
                mianZhangCard={mianZhangCard}
                phase={phase}
                currentPlayerIndex={currentPlayerIndex}
                bankerId={bankerId}
                trickWinnerId={trickWinnerId}
                pot={pot}
                kaiChongCardIndex={kaiChongCardIndex}
                kaiChongHistory={kaiChongHistory}
                layout={layout}
                skin={skin}
                quality={graphicsQuality}
                interactionState={interactionState}
                highlightedCardIds={highlightedCardIds}
                timeOfDay={timeOfDay}
            />
        </div>
    );
});
