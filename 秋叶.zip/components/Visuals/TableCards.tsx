
// @ARCHITECT_LOCK: DESKTOP TABLETOP LAYOUT & CARD FLOW
// -------------------------------------------------------------------------
// ⛔️ CRITICAL SAFETY WARNING ⛔️
// Optimized for performance. Custom equality check prevents timer jitter.
// -------------------------------------------------------------------------

import React, { useMemo } from 'react';
import CardComponent from '../Card';
import { Card, Player } from '../../types';
import { TableCardConfig } from '../../services/layoutConfig';

interface TableCard {
    card: Card;
    playerId: number;
    isFaceDown: boolean;
}

interface TableCardsProps {
    cards: TableCard[];
    winnerId: number | null;
    config: TableCardConfig;
    spread: { x: number, y: number };
    centerOffset: { x: number, y: number };
    cardScale: number;
    players: Player[];
    quality: string;
}

const calculateCardTransform = (
    playerPos: string | undefined,
    spread: { x: number, y: number },
    centerOffset: { x: number, y: number },
    isWinner: boolean,
    winnerPos: string | undefined,
    config: TableCardConfig,
    scale: number
): React.CSSProperties => {
    let tx = 0, ty = 0;
    const { x: spreadX, y: spreadY } = spread;
    const { x: cx, y: cy } = centerOffset;

    if (playerPos === 'Bottom') { tx = 0; ty = spreadY; }
    else if (playerPos === 'Top') { tx = 0; ty = -spreadY; }
    else if (playerPos === 'Left') { tx = -spreadX; ty = 0; }
    else if (playerPos === 'Right') { tx = spreadX; ty = 0; }

    tx += cx; ty += cy;

    let flyX = 0, flyY = 0;
    if (isWinner && winnerPos) {
        const FLY_DIST = 600; 
        if (winnerPos === 'Bottom') flyY = FLY_DIST;
        else if (winnerPos === 'Top') flyY = -FLY_DIST;
        else if (winnerPos === 'Left') flyX = -FLY_DIST;
        else if (winnerPos === 'Right') flyX = FLY_DIST;
    }

    const baseZ = isWinner ? config.winnerLiftZ : config.baseZ;
    const naturalRotation = playerPos === 'Left' ? 90 : (playerPos === 'Right' ? -90 : (playerPos === 'Top' ? 180 : 0));
    const finalRotateZ = config.forceUpright ? 0 : naturalRotation;

    return {
        position: 'absolute', left: '50%', top: '50%',
        width: 96 * scale * config.scale, height: 144 * scale * config.scale,
        transform: `translate(-50%, -50%) translate(${tx + flyX}px, ${ty + flyY}px) translateZ(${baseZ}px) rotateX(${config.rotationX}deg) rotateZ(${finalRotateZ}deg)`,
        willChange: 'transform',
        zIndex: isWinner ? 100 : 10,
        transition: isWinner ? 'transform 0.5s cubic-bezier(0.6, -0.28, 0.735, 0.045)' : 'transform 0.35s cubic-bezier(0.175, 0.885, 0.32, 1.275)',
        opacity: isWinner && (Math.abs(flyX) > 0 || Math.abs(flyY) > 0) ? 0 : 1
    };
};

interface BulletCardProps {
    card: Card;
    playerPos: string;
    spread: { x: number, y: number };
    centerOffset: { x: number, y: number };
    isFaceDown: boolean;
    isWinner: boolean;
    winnerPos?: string;
    quality: string;
    config: TableCardConfig;
    scale?: number;
}

const BulletCard = React.memo(({ card, playerPos, spread, centerOffset, isFaceDown, isWinner, winnerPos, quality, config, scale = 1.0 }: BulletCardProps) => {
    const isLow = quality === 'LOW';
    const containerStyle: React.CSSProperties = useMemo(() => ({
        ...calculateCardTransform(playerPos, spread, centerOffset, isWinner, winnerPos, config, scale),
        transformStyle: isLow ? 'flat' : 'preserve-3d'
    }), [playerPos, spread, centerOffset, isWinner, winnerPos, config, scale, isLow]);

    return (
        <div style={containerStyle}>
            <CardComponent card={card} isTrick isFaceDown={isFaceDown} isWinner={isWinner} isSmall={false} className="w-full h-full" />
        </div>
    );
}, (prev, next) => {
    // DEEP COMPARISON for Props
    if (prev.isWinner !== next.isWinner) return false;
    if (prev.isFaceDown !== next.isFaceDown) return false;
    if (prev.card.id !== next.card.id) return false;
    if (prev.playerPos !== next.playerPos) return false;
    if (prev.winnerPos !== next.winnerPos) return false;
    return true;
});

export const TableCards = React.memo(({ cards, winnerId, config, spread, centerOffset, cardScale, players, quality }: TableCardsProps) => {
    // Map players only when necessary
    const playerPosMap = useMemo(() => {
        const map: Record<number, string> = {};
        players.forEach(p => map[p.id] = p.position);
        return map;
    }, [players]); 

    const winner = winnerId !== null ? players.find(p => p.id === winnerId) : null;
    const winnerPos = winner?.position;

    return (
        <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', transformStyle: quality === 'LOW' ? 'flat' : 'preserve-3d', zIndex: 10 }}>
            {cards.map((tc) => (
                <BulletCard 
                    key={`${tc.card.id}-${tc.playerId}`} 
                    card={tc.card} 
                    playerPos={playerPosMap[tc.playerId] || 'Bottom'} 
                    spread={spread} 
                    centerOffset={centerOffset} 
                    isFaceDown={tc.isFaceDown} 
                    isWinner={winnerId !== null} 
                    winnerPos={winnerPos}
                    quality={quality} 
                    config={config} 
                    scale={cardScale} 
                />
            ))}
        </div>
    );
}, (prev, next) => {
    // [PERFORMANCE KERNEL] - TITANIUM GRADE
    // Strict Deep Equality Check to prevent React Rendering Thrashing during AI moves
    
    // 1. Primitive Checks
    if (prev.winnerId !== next.winnerId) return false;
    if (prev.cardScale !== next.cardScale) return false;
    if (prev.quality !== next.quality) return false;
    if (prev.cards.length !== next.cards.length) return false;

    // 2. Array Content Check (Card IDs)
    for (let i = 0; i < prev.cards.length; i++) {
        if (prev.cards[i].card.id !== next.cards[i].card.id) return false;
        if (prev.cards[i].isFaceDown !== next.cards[i].isFaceDown) return false;
    }

    // 3. Config Deep Check (Optional, but safe)
    if (prev.config.rotationX !== next.config.rotationX) return false;

    return true; // Skip re-render
});

// Re-exporting legacy components
export { PotPile, WonCardPiles } from './TableCards_Legacy';
