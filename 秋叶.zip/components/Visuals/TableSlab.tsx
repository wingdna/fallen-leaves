import React from 'react';

interface TableSlabProps {
    skin: any;
    width: string | number;
    height: string | number;
    thickness?: number;
    visualYOffset?: string;
    children?: React.ReactNode;
    quality: string;
    withLegs?: boolean;
    timeOfDay?: number;
}

export const TableSlab = React.memo(({ skin, width, height, thickness = 40, visualYOffset = '0px', children, quality, withLegs, timeOfDay }: TableSlabProps) => {
    const isLowQuality = quality === 'LOW';
    const zOrigin = thickness / 2;
    
    return (
        <div className="relative w-full h-full group" style={{ transformStyle: 'preserve-3d' }}>
            <div className="absolute inset-0 pointer-events-none" style={{ transform: `translateY(${visualYOffset})`, transformStyle: 'preserve-3d' }}>
                
                {/* TABLE SURFACE */}
                <div className={`absolute inset-0 z-0 ${skin.layout.tableSurfaceClass}`} 
                     style={{ 
                         transform: `translateZ(${zOrigin}px)`, 
                         transformStyle: 'preserve-3d',
                         background: skin.layout.tableBaseColor || '#050505'
                     }}>
                     
                     <div className="absolute inset-0 w-full h-full mix-blend-normal" style={{ backgroundImage: skin.layout.tableTexture || 'none', backgroundSize: skin.layout.tableTextureSize || 'auto', opacity: 1.0 }}></div>
                     
                     {skin.layout.tableReflectivity && !isLowQuality && (
                         <div className="absolute inset-0 bg-gradient-to-br from-white/10 via-transparent to-black/80 mix-blend-overlay"></div>
                     )}
                     
                     {!isLowQuality && (
                         <div className="absolute inset-0 pointer-events-none mix-blend-multiply bg-[radial-gradient(ellipse_at_center,transparent_40%,rgba(0,0,0,0.9)_100%)]"></div>
                     )}
                </div>
                
                {/* SIDES REMOVED: 移除了所有侧边厚度渲染，以消除在地面产生的视觉黑线干扰 */}
            </div>
            
            <div className="absolute inset-0 z-20 pointer-events-none" style={{ transform: `translateZ(${zOrigin}px)`, transformStyle: 'preserve-3d' }}>
                {children}
            </div>
        </div>
    );
});