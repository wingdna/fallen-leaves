// @ts-nocheck
import React, { useRef, useEffect, Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { useGLTF, useAnimations, Environment, Billboard, Image } from '@react-three/drei';
import * as THREE from 'three';

// --- 1. Pure 3D GLB Component (Safe context for useGLTF) ---
const GLBAvatar: React.FC<{ url: string; position: 'Top' | 'Left' | 'Right' | 'Bottom' }> = ({ url, position }) => {
    const group = useRef<THREE.Group>(null);
    // This hook will only run when this component is mounted
    const { scene, animations } = useGLTF(url);
    const { actions } = useAnimations(animations, group);

    useEffect(() => {
        if (actions && Object.keys(actions).length > 0) {
            const firstAnim = Object.keys(actions)[0];
            actions[firstAnim]?.reset().fadeIn(0.5).play();
        }
    }, [actions]);

    const rotation: [number, number, number] = (() => {
        switch (position) {
            case 'Top': return [0, 0, 0];
            case 'Left': return [0, -Math.PI / 2, 0];
            case 'Right': return [0, Math.PI / 2, 0];
            case 'Bottom': return [0, Math.PI, 0];
            default: return [0, 0, 0];
        }
    })();

    const positionAdjust: [number, number, number] = [0, -1.8, 0]; 

    return (
        <group ref={group} dispose={null}>
            <primitive 
                object={scene} 
                scale={2.2} 
                position={positionAdjust} 
                rotation={rotation}
            />
        </group>
    );
};

// --- 2. 2D Fallback Component (For JPG/PNG avatars in 3D space) ---
const ImageAvatar: React.FC<{ url: string; position: 'Top' | 'Left' | 'Right' | 'Bottom' }> = ({ url, position }) => {
    // Rotate billboard to face the center/table based on seat
    // Note: Billboard usually faces camera, but we can lock axis if needed.
    // For simplicity, we just place it and let Billboard face camera (User).
    
    // Adjust position to sit on chair
    const pos: [number, number, number] = [0, 0.6, 0]; 

    return (
        <group position={pos}>
            <Billboard follow={true} lockX={false} lockY={false} lockZ={false}>
                <Image url={url} scale={[1.2, 1.2]} transparent radius={0.5} />
            </Billboard>
        </group>
    );
};

interface SeatedModelProps {
    url: string;
    position: 'Top' | 'Left' | 'Right' | 'Bottom';
}

// --- 3. Main Switcher Component ---
// Export this pure 3D component so it can be used inside other Canvases
export const SeatedAvatarModel: React.FC<SeatedModelProps> = ({ url, position }) => {
    // Strict check for 3D formats
    const is3D = url && (url.toLowerCase().endsWith('.glb') || url.toLowerCase().endsWith('.gltf'));

    if (is3D) {
        return <GLBAvatar url={url} position={position} />;
    } else {
        return <ImageAvatar url={url} position={position} />;
    }
};

interface SeatedAvatarProps {
    url: string;
    seatPosition: 'Top' | 'Left' | 'Right' | 'Bottom';
    quality?: 'HIGH' | 'MEDIUM' | 'LOW';
}

// Wrapper component for standalone usage (e.g. inside a DIV)
export const SeatedAvatar: React.FC<SeatedAvatarProps> = ({ url, seatPosition, quality }) => {
    const dpr = quality === 'HIGH' ? [1, 2] : [1, 1];

    return (
        <div className="w-full h-full relative">
            <Canvas 
                frameloop="demand"
                dpr={dpr}
                camera={{ position: [0, 0.5, 3.5], fov: 25 }}
                gl={{ preserveDrawingBuffer: true, alpha: true }}
            >
                <ambientLight intensity={0.6} />
                <spotLight position={[2, 5, 2]} angle={0.5} penumbra={1} intensity={1.2} color="#ffd700" />
                <pointLight position={[-2, 2, 2]} intensity={0.5} color="#c5a059" />
                <Environment preset="city" />

                <Suspense fallback={null}>
                    <SeatedAvatarModel url={url} position={seatPosition} />
                </Suspense>
            </Canvas>
            
            <div className="absolute bottom-0 left-0 w-full h-1/4 bg-gradient-to-t from-black/80 to-transparent pointer-events-none"></div>
        </div>
    );
};