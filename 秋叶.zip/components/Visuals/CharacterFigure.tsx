
import React, { useMemo } from 'react';
import { Player } from '../../types';
import { useSkin } from '../../contexts/SkinContext';
import { useGameSettings } from '../../hooks/useGameSettings';
import { SeatedAvatar } from './SeatedAvatar';

const PAPER_NOISE = "data:image/svg+xml,%3Csvg viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.8' numOctaves='3'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.2'/%3E%3C/svg%3E";

interface CharacterFigureProps {
    player: Player;
    position: 'Top' | 'Left' | 'Right' | 'Bottom'; 
    isActive: boolean;
    isBanker: boolean;
    isBaiLao: boolean;
    statusText: string;
    quality?: 'HIGH' | 'MEDIUM' | 'LOW'; 
}

export const CharacterFigure: React.FC<CharacterFigureProps> = React.memo(({ player, position, isActive, isBanker, isBaiLao, statusText, quality }) => {
    const { skin } = useSkin();
    const { graphicsQuality: globalQuality } = useGameSettings();
    const currentQuality = quality || globalQuality;

    const profile = player.profile;
    const avatarUrl = profile?.avatar_url;
    
    // Check if we should render 3D
    // Condition: URL is GLB/GLTF AND Quality is HIGH (Performance Guard)
    const is3DModel = avatarUrl?.endsWith('.glb') || avatarUrl?.endsWith('.gltf');
    const shouldRender3D = is3DModel && currentQuality === 'HIGH';

    // Fallback Avatar
    const avatarImage = avatarUrl && !is3DModel ? avatarUrl : `https://api.dicebear.com/9.x/miniavs/svg?seed=${player.name}&backgroundColor=transparent`;

    // --- VISUAL CORRECTION LOGIC (2D Only) ---
    // Removed old body composition logic. 
    // Simply flipping avatar if needed based on seat.
    const imageTransform = useMemo(() => {
        let transform = 'scale(1.0)';
        if (position === 'Left') return 'scaleX(-1)'; // Face inward
        if (position === 'Right') return 'scaleX(-1)'; // Face inward
        return transform;
    }, [position]);

    // --- CONFIGURATION BASED ON POSITION ---
    const config = useMemo(() => {
        const base = {
            chairScale: 'scale(1.1)',
            chairY: '0%',
            chairX: '0%',
            portraitY: '15%', // Adjusted for pure portrait mode
            lightingGradient: 'radial-gradient(circle at 50% 30%, rgba(255,255,255,0.1), rgba(0,0,0,0) 80%)',
        };

        if (position === 'Top') {
            return { ...base, portraitY: '10%' };
        }
        if (position === 'Left') {
            return { ...base, chairX: '5%', portraitY: '12%' };
        }
        if (position === 'Right') {
            return { ...base, chairX: '-5%', portraitY: '12%' };
        }
        return base;
    }, [position]);

    const getStatusColor = (status: string) => {
        if (status === '赤脚') return 'bg-[#5c0b00] border-red-400 text-white shadow-[0_0_8px_rgba(220,38,38,0.6)]';
        if (status === '正本') return 'bg-[#1c1917] border-stone-400 text-stone-100 shadow-[0_0_8px_rgba(87,83,78,0.6)]';
        if (status === '得吊') return 'bg-[#064e3b] border-emerald-400 text-emerald-50 shadow-[0_0_8px_rgba(16,185,129,0.6)]';
        if (status === '双吊') return 'bg-[#065f46] border-[#34d399] text-white shadow-[0_0_10px_rgba(52,211,153,0.8)]';
        return 'bg-black/90 border-stone-600';
    };

    const textFlipStyle = position === 'Top' ? { transform: 'rotateY(180deg)' } : undefined;

    // --- LIVE PORTRAIT ANIMATIONS (2D Only) ---
    const breathingClass = isActive ? 'animate-breathe-deep' : 'animate-breathe-idle';

    return (
        <div 
            className={`
                relative w-96 h-96 flex items-end justify-center pointer-events-none 
                transition-all duration-700 ease-out select-none
                ${isActive ? 'z-50 filter brightness-110 drop-shadow-[0_0_25px_rgba(255,215,0,0.3)]' : 'opacity-95'}
            `} 
            style={{ 
                transformStyle: 'preserve-3d',
                transformOrigin: 'bottom center',
                transform: isActive ? 'scale(1.08) translateY(-5px)' : 'scale(1.0)'
            }}
        >
            <style>{`
                @keyframes breatheIdle {
                    0%, 100% { transform: translateY(0) scale(1); }
                    50% { transform: translateY(-2px) scale(1.01); }
                }
                @keyframes breatheDeep {
                    0%, 100% { transform: translateY(0) scale(1); }
                    50% { transform: translateY(-4px) scale(1.03); }
                }
                .animate-breathe-idle { animation: breatheIdle 6s ease-in-out infinite; }
                .animate-breathe-deep { animation: breatheDeep 3s ease-in-out infinite; }
            `}</style>

            {/* LAYER 0: FLOOR SHADOW */}
            <div className="absolute bottom-0 w-[80%] h-[10%] bg-black/80 blur-xl rounded-[100%] transform scale-y-50 -z-10 translate-y-4"></div>

            {/* LAYER 1: CHAIR (Shared) */}
            <div 
                className="absolute bottom-[2%] z-0 origin-bottom filter brightness-[0.6] contrast-125 saturate-50 drop-shadow-2xl"
                style={{ 
                    transform: `translateZ(-20px) ${config.chairScale} translateX(${config.chairX}) translateY(${config.chairY})`,
                    width: '100%',  
                    height: '100%'  
                }}
            >
                <skin.character.chairComponent position={position} quality={currentQuality} />
            </div>

            {/* LAYER 2: CHARACTER CONTENT */}
            
            {shouldRender3D ? (
                // --- 3D MODE ---
                <div className="absolute inset-0 z-20 pointer-events-none" style={{ transform: 'translateZ(10px)' }}>
                    <SeatedAvatar url={avatarUrl!} seatPosition={position} quality={currentQuality} />
                </div>
            ) : (
                // --- 2D MODE: PURE PORTRAIT (No Paper Doll) ---
                // Replaced complex composite with a singular, framed avatar image
                <div 
                    className={`absolute bottom-[18%] z-10 ${breathingClass}`}
                    style={{ 
                        width: '200px', 
                        height: '200px',
                        transformOrigin: 'bottom center'
                    }}
                >
                    <div className="relative w-full h-full rounded-full border-4 border-[#3e2b22] bg-[#1a100a] shadow-[0_10px_30px_rgba(0,0,0,0.8)] overflow-hidden">
                        <img 
                            src={avatarImage} 
                            alt="avatar" 
                            className="w-full h-full object-cover"
                            style={{ 
                                filter: 'contrast(1.1) saturate(0.9)', 
                                transform: imageTransform 
                            }}
                        />
                        {/* Overlay Gradient for integration */}
                        <div className="absolute inset-0 pointer-events-none mix-blend-overlay" style={{ background: config.lightingGradient }}></div>
                        <div className="absolute inset-0 pointer-events-none shadow-[inset_0_0_20px_rgba(0,0,0,0.8)]"></div>
                        {currentQuality === 'HIGH' && (
                            <div className="absolute inset-0 pointer-events-none opacity-20 mix-blend-multiply" style={{ backgroundImage: `url("${PAPER_NOISE}")` }}></div>
                        )}
                    </div>
                </div>
            )}

            {/* STATUS BADGES (Common) */}
            <div className="absolute top-[20%] w-full flex flex-col items-center justify-center z-40 pointer-events-none" 
                style={{ transform: 'translateZ(30px) scale(0.35)', transformOrigin: 'top center', width: '300%', left: '-100%' }}>
                <div className="flex flex-col gap-4 items-center justify-center w-full" style={textFlipStyle}>
                    {(isBanker || isBaiLao) && (
                        <div className="flex gap-6 items-center justify-center">
                            {isBanker && (
                                <div className="w-28 h-28 rounded-full bg-gradient-to-br from-[#aa1d1d] via-[#8c1c0b] to-[#450a0a] border-[6px] border-[#ffd700] shadow-[0_20px_40px_black] flex items-center justify-center text-[#fff] font-serif font-black text-7xl tracking-tighter ring-4 ring-black/40 z-10 animate-pulse-slow-opacity">
                                    <span className="drop-shadow-[0_4px_8px_rgba(0,0,0,0.9)] relative -top-1">庄</span>
                                </div>
                            )}
                            {isBaiLao && (
                                <div className="w-28 h-28 rounded-full bg-gradient-to-br from-[#10b981] via-[#047857] to-[#064e3b] border-[6px] border-[#34d399] shadow-[0_20px_40px_black] flex items-center justify-center text-[#ecfdf5] font-serif font-black text-7xl tracking-tighter ring-4 ring-black/40 z-10">
                                    <span className="drop-shadow-[0_2px_0_rgba(255,255,255,0.4)] relative -top-1">百</span>
                                </div>
                            )}
                        </div>
                    )}
                    {statusText && statusText !== '-' && (
                        <div className={`px-8 py-3 rounded-[12px] shadow-[0_15px_30px_rgba(0,0,0,0.9)] border-[4px] backdrop-blur-xl flex items-center h-24 mt-2 ${getStatusColor(statusText)}`}>
                            <span className="text-6xl font-serif font-black tracking-widest drop-shadow-md whitespace-nowrap" style={{ textShadow: '0 4px 8px rgba(0,0,0,0.6)' }}>
                                {statusText}
                            </span>
                        </div>
                    )}
                </div>
            </div>

            {isActive && currentQuality === 'HIGH' && (
                <div className="absolute inset-0 -z-10 bg-radial-gradient from-[#ffaa00]/15 to-transparent blur-3xl transform scale-125 translate-y-[-10%] mix-blend-screen animate-pulse-slow-opacity"></div>
            )}
        </div>
    );
});
