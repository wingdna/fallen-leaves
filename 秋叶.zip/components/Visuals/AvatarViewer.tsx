import React, { useRef, useEffect, Component, ReactNode, Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { useGLTF, useAnimations, Environment, ContactShadows, OrbitControls, Html } from '@react-three/drei';
import * as THREE from 'three';

// [FIX] 更换为稳定的 Ready Player Me 官方示例模型，防止 404 导致崩溃
const DEFAULT_AVATAR_URL = "https://models.readyplayer.me/63c5a772f4357e626e27b233.glb";

// --- Internal Error Boundary for 3D Context ---
// 防止因为模型加载失败导致整个 App 崩溃
interface ErrorBoundaryProps { children: ReactNode; fallback: ReactNode; }
interface ErrorBoundaryState { hasError: boolean; }

class ModelErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
    public state: ErrorBoundaryState = { hasError: false };
    declare public props: ErrorBoundaryProps;

    static getDerivedStateFromError() { return { hasError: true }; }
    componentDidCatch(error: any) { console.error("3D Model Load Failed:", error); }
    render() {
        if (this.state.hasError) return this.props.fallback;
        return this.props.children;
    }
}

interface AvatarModelProps {
    url: string;
    animation?: string;
}

const AvatarModel: React.FC<AvatarModelProps> = ({ url, animation = "Idle" }) => {
    const group = useRef<THREE.Group>(null);
    // useGLTF 会挂起组件 (Suspense) 或抛出错误 (ErrorBoundary)
    const { scene, animations } = useGLTF(url);
    const { actions } = useAnimations(animations, group);

    useEffect(() => {
        if (actions && Object.keys(actions).length > 0) {
            const act = actions[Object.keys(actions)[0]];
            act?.reset().fadeIn(0.5).play();
        }
        scene.traverse((child: any) => {
            if (child.isMesh) {
                child.castShadow = true;
                child.receiveShadow = true;
            }
        });
    }, [scene, actions]);

    return (
        // @ts-ignore
        <group ref={group} dispose={null}>
            {/* @ts-ignore */}
            <primitive object={scene} scale={2} position={[0, -2, 0]} />
        {/* @ts-ignore */}
        </group>
    );
};

interface AvatarViewerProps {
    avatarUrl?: string;
    className?: string;
}

const Loader = () => (
    <Html center>
        <div className="text-[#c5a059] text-xs font-serif animate-pulse tracking-widest">
            正在穿戴...
        </div>
    </Html>
);

const ErrorFallback = () => (
    <Html center>
        <div className="text-red-500 text-xs font-serif text-center w-48 bg-black/80 p-2 border border-red-500/50 rounded">
            ⚠️ 模型加载失败<br/>可能是网络原因或链接失效
        </div>
    </Html>
);

export const AvatarViewer: React.FC<AvatarViewerProps> = ({ 
    avatarUrl = DEFAULT_AVATAR_URL,
    className = "w-full h-full"
}) => {
    // 确保 url 有值，避免空字符串传给 useGLTF
    const safeUrl = avatarUrl || DEFAULT_AVATAR_URL;

    return (
        <div className={className}>
            <Canvas shadows camera={{ position: [0, 1.5, 4], fov: 40 }}>
                {/* 增加容错层，防止整站崩溃 */}
                <ModelErrorBoundary fallback={<ErrorFallback />}>
                    <Suspense fallback={<Loader />}>
                        {/* @ts-ignore */}
                        <ambientLight intensity={0.7} />
                        {/* @ts-ignore */}
                        <spotLight 
                            position={[5, 10, 5]} 
                            angle={0.15} 
                            penumbra={1} 
                            intensity={1.5} 
                            castShadow 
                            shadow-mapSize={[1024, 1024]}
                        />
                        <Environment preset="sunset" />
                        
                        <AvatarModel url={safeUrl} />
                        
                        <ContactShadows resolution={1024} scale={10} blur={1} opacity={0.5} far={10} color="#000000" />
                        <OrbitControls 
                            enablePan={false} 
                            minPolarAngle={Math.PI / 2.5} 
                            maxPolarAngle={Math.PI / 1.8} 
                            minDistance={2} 
                            maxDistance={6} 
                        />
                    </Suspense>
                </ModelErrorBoundary>
            </Canvas>
        </div>
    );
};