
import React, { useMemo, useEffect, useState } from 'react';
import { GamePhase } from '../../types';
import { useGameSettings } from '../../hooks/useGameSettings';

// --- 护眼色板 (Eye-Care Palette) ---
const EYE_CARE_WHITE = "#e6e2d8"; // 柔和米白，替代刺眼纯白
const BANKER_RED = "#c0392b";     // 沉稳朱红
// [UPDATED] Emerald Green for Bai Lao
const BAILAO_GREEN = "#10b981";   // 碧绿翡翠色
const PLAYER_AMBER = "#d68910";   // 琥珀金
const INK_BLACK = "#2c3e50";      // 墨色
const OBSIDIAN_NEEDLE = "#1a1a1a"; // 黑曜石色

// --- 罗盘圆周边缘弧 (Circumference Edge Arc) ---
// 修正：status 仅接受 'played' | 'idle'。
// 修复：移除 Idle 状态的 return null，恢复霜冻效果。
const SectorArc = React.memo(({ sectorId, status, isBanker, isBaiLao }: { sectorId: number, status: 'played' | 'idle', isBanker: boolean, isBaiLao: boolean }) => {
    
    const activeColor = useMemo(() => {
        if (isBanker) return BANKER_RED;
        if (isBaiLao) return BAILAO_GREEN;
        return PLAYER_AMBER; 
    }, [isBanker, isBaiLao]);

    // 0:Bottom, 1:Right, 2:Top, 3:Left
    // 对应角度 (CSS旋转): 
    // Arc 默认绘制在 Top (12点钟)。需要旋转到对应玩家位置。
    // P0(Bottom): 180, P1(Right): 90, P2(Top): 0, P3(Left): 270(-90)
    const baseAngles = [180, 90, 0, 270]; 
    const rotation = baseAngles[sectorId];

    // [FIX] 不再因为 idle 就返回 null，而是渲染“霜冻”底座
    const isPlayed = status === 'played';

    // 绘制 86度 圆弧 (留出4度间隔)
    // r=96 (贴近边缘 200x200 容器, strokeWidth=4~6)
    // Start angle -43, End angle 43
    // Radians: -43deg = -0.75, 43deg = 0.75
    const r = 96;
    const startX = 100 + r * Math.sin(-0.75);
    const startY = 100 - r * Math.cos(-0.75);
    const endX = 100 + r * Math.sin(0.75);
    const endY = 100 - r * Math.cos(0.75);

    const arcPath = `M ${startX} ${startY} A ${r} ${r} 0 0 1 ${endX} ${endY}`;
    // Arc length approx: 2 * PI * 96 * (86/360) ≈ 144
    const pathLength = 144; 

    return (
        <div className="absolute inset-0 pointer-events-none" style={{ transform: `rotate(${rotation}deg)`, transformStyle: 'preserve-3d' }}>
            <style>{`
                @keyframes drawArcQuick {
                    from { stroke-dashoffset: ${pathLength}; opacity: 0; }
                    to { stroke-dashoffset: 0; opacity: 1; }
                }
            `}</style>
            
            <svg viewBox="0 0 200 200" className="w-full h-full absolute overflow-visible">
                {/* 霜冻底座 (Frost Base) - 永远显示，但在 Played 状态下会被覆盖或淡化 */}
                {!isPlayed && (
                    <path 
                        d={arcPath} 
                        fill="none" 
                        stroke="rgba(200, 230, 255, 0.15)" // 冰蓝微光
                        strokeWidth="3" 
                        strokeLinecap="round"
                        strokeDasharray="2 6" // 虚线效果增加通透感
                        style={{
                            filter: `drop-shadow(0 0 2px rgba(200, 230, 255, 0.3))`
                        }}
                    />
                )}

                {/* 动态进度条 - 快速绘制出现，表示已出牌确认 */}
                {isPlayed && (
                    <path 
                        d={arcPath} 
                        fill="none" 
                        stroke={activeColor} 
                        strokeWidth="6" 
                        strokeLinecap="round"
                        strokeDasharray={pathLength}
                        strokeDashoffset="0"
                        style={{
                            animation: `drawArcQuick 0.4s cubic-bezier(0.2, 0.8, 0.2, 1) forwards`,
                            filter: `drop-shadow(0 0 4px ${activeColor})`
                        }}
                    />
                )}
            </svg>
        </div>
    );
});

// --- 绝世宝石 (Peerless Gemstones) ---
export const GemStone = React.memo(({ type, label, isActive, identityColor, className, rotate = 0 }: { type: 'mountain' | 'river_stone' | 'flat' | 'sharp', label: string, isActive: boolean, identityColor: string, className?: string, rotate?: number }) => {
    const { graphicsQuality } = useGameSettings();
    const isHighQuality = graphicsQuality === 'HIGH';
    const seed = useMemo(() => Math.floor(Math.random() * 100), []);

    // 宝石类型判定
    const gemType = useMemo(() => {
        if (identityColor === '#d91e18') return 'RUBY';    // 兼容旧代码传入的色值，但在内部映射到护眼色
        if (identityColor === '#10b981' || identityColor === BAILAO_GREEN) return 'EMERALD'; 
        return 'AMBER';                                    
    }, [identityColor]);

    // 实际渲染颜色映射 (Eye Care)
    const renderColor = useMemo(() => {
        if (gemType === 'RUBY') return BANKER_RED;
        if (gemType === 'EMERALD') return BAILAO_GREEN;
        return PLAYER_AMBER;
    }, [gemType]);

    // 判定特殊身份（红/绿）
    const isSpecialRole = useMemo(() => {
        return gemType === 'RUBY' || gemType === 'EMERALD';
    }, [gemType]);

    // 圆润饱满的鹅卵石路径
    const paths = {
        mountain: "M50,10 C75,10 90,30 90,60 C90,85 70,95 50,95 C30,95 10,85 10,60 C10,30 25,10 50,10 Z",
        river_stone: "M50,15 C80,15 95,35 95,60 C95,80 75,90 50,90 C25,90 5,80 5,60 C5,35 20,15 50,15 Z",
        flat: "M50,20 C75,20 90,35 90,60 C90,80 70,85 50,85 C30,85 10,80 10,60 C10,35 25,20 50,20 Z",
        sharp: "M50,5 C70,20 85,50 85,70 C85,85 70,95 50,95 C30,95 15,85 15,70 C15,50 30,20 50,5 Z"
    };

    const filterObsidian = `obsidian-${type}-${seed}`;
    const filterGem = `gem-${type}-${seed}`;

    return (
        <div className={`${className} transition-all duration-700 ease-out ${isActive ? 'scale-110 z-50 drop-shadow-[0_0_15px_rgba(0,0,0,0.5)]' : 'scale-100 z-10 drop-shadow-[0_5px_10px_rgba(0,0,0,0.3)]'}`} 
             style={{ transform: `rotate(${rotate}deg)` }}>
            
            <style>{`
                @keyframes gemBreatheColor {
                    0%, 100% { filter: brightness(1) drop-shadow(0 0 5px ${renderColor}40); }
                    50% { filter: brightness(1.2) drop-shadow(0 0 15px ${renderColor}80); }
                }
                .animate-gem-breathe { animation: gemBreatheColor 2.5s ease-in-out infinite; }
            `}</style>

            <svg viewBox="0 0 100 100" className="w-full h-full overflow-visible" preserveAspectRatio="xMidYMid meet">
                <defs>
                    {/* 1. 黑曜石滤镜 (Idle: Obsidian) */}
                    <filter id={filterObsidian} x="-20%" y="-20%" width="140%" height="140%">
                        <feTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves="3" result="noise" seed={seed} />
                        <feColorMatrix type="matrix" values="0.1 0 0 0 0  0 0.1 0 0 0  0 0 0.1 0 0  0 0 0 1 0" in="noise" result="darkNoise" />
                        <feGaussianBlur stdDeviation="1.0" in="SourceAlpha" result="blur" />
                        <feSpecularLighting in="blur" surfaceScale="5" specularConstant="0.8" specularExponent="30" lightingColor={EYE_CARE_WHITE} result="specOut">
                            <fePointLight x="-20" y="-50" z="100" />
                        </feSpecularLighting>
                        <feComposite in="specOut" in2="SourceAlpha" operator="in" result="specOut" />
                        <feComposite in="SourceGraphic" in2="specOut" operator="arithmetic" k1="0" k2="1" k3="1" k4="0" />
                    </filter>

                    {/* 2. 宝石滤镜 (Active: Colored Crystal) - 本色发光 */}
                    <filter id={filterGem} x="-20%" y="-20%" width="140%" height="140%">
                        {/* 内部晶体结构 */}
                        <feTurbulence type="fractalNoise" baseFrequency="1.5" numOctaves="2" result="crystalStruct" seed={seed+1} />
                        <feColorMatrix type="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 0.1 0" in="crystalStruct" result="softCrystal" />
                        
                        {/* 表面光泽 */}
                        <feGaussianBlur stdDeviation="1.5" in="SourceAlpha" result="blur" />
                        <feSpecularLighting in="blur" surfaceScale="6" specularConstant="1.0" specularExponent="40" lightingColor={EYE_CARE_WHITE} result="specOut">
                            <fePointLight x="-30" y="-60" z="80" />
                        </feSpecularLighting>
                        <feComposite in="specOut" in2="SourceAlpha" operator="in" result="specOut" />
                        
                        {/* 内部自发光 - 使用 renderColor (本色) */}
                        <feMorphology operator="erode" radius="4" in="SourceAlpha" result="eroded" />
                        <feGaussianBlur stdDeviation="6" in="eroded" result="innerBlur" />
                        <feFlood floodColor={renderColor} floodOpacity="0.6" result="glowColor" />
                        <feComposite in="glowColor" in2="innerBlur" operator="in" result="innerGlow" />

                        <feBlend mode="screen" in="innerGlow" in2="SourceGraphic" result="glowingBody" />
                        <feComposite in="glowingBody" in2="specOut" operator="arithmetic" k1="0" k2="1" k3="0.6" k4="0" />
                    </filter>

                    {/* 黑曜石渐变 */}
                    <radialGradient id={`grad-obsidian-${seed}`} cx="30%" cy="30%" r="80%">
                        <stop offset="0%" stopColor="#4a4a4a" />
                        <stop offset="100%" stopColor="#0a0a0a" />
                    </radialGradient>

                    {/* 宝石渐变库 */}
                    <radialGradient id={`grad-RUBY-${seed}`} cx="40%" cy="30%" r="80%">
                        <stop offset="0%" stopColor="#e74c3c" stopOpacity="0.95" />   
                        <stop offset="60%" stopColor="#922b21" stopOpacity="0.9" />   
                        <stop offset="100%" stopColor="#641e16" stopOpacity="0.95" /> 
                    </radialGradient>
                    <radialGradient id={`grad-EMERALD-${seed}`} cx="40%" cy="30%" r="80%">
                        <stop offset="0%" stopColor="#2ecc71" stopOpacity="0.95" />
                        <stop offset="60%" stopColor="#1e8449" stopOpacity="0.9" />
                        <stop offset="100%" stopColor="#145a32" stopOpacity="0.95" />
                    </radialGradient>
                    <radialGradient id={`grad-AMBER-${seed}`} cx="40%" cy="30%" r="80%">
                        <stop offset="0%" stopColor="#f1c40f" stopOpacity="0.95" />
                        <stop offset="60%" stopColor="#b7950b" stopOpacity="0.9" />
                        <stop offset="100%" stopColor="#7d6608" stopOpacity="0.95" />
                    </radialGradient>
                </defs>

                {/* Shadow */}
                <path d={paths[type]} fill="#000" transform="translate(3, 6) scale(1.0)" filter="blur(3px)" opacity="0.5" style={{ mixBlendMode: 'multiply' }} />

                {/* --- LAYER 1: OBSIDIAN (IDLE) --- */}
                <g style={{ opacity: isActive ? 0 : 1, transition: 'opacity 0.6s ease-in-out' }} filter={isHighQuality ? `url(#${filterObsidian})` : undefined}>
                    <path d={paths[type]} fill={`url(#grad-obsidian-${seed})`} stroke="none" />
                </g>

                {/* --- LAYER 2: GEMSTONE (ACTIVE) --- */}
                <g style={{ opacity: isActive ? 1 : 0, transition: 'opacity 0.4s ease-out' }} className={isActive ? 'animate-gem-breathe' : ''}>
                    <g filter={isHighQuality ? `url(#${filterGem})` : undefined}>
                        <path d={paths[type]} fill={`url(#grad-${gemType}-${seed})`} stroke="none" />
                    </g>
                </g>

                {/* Identity Text */}
                <g transform="translate(50, 60)">
                    <text 
                        textAnchor="middle" 
                        fill={isActive ? EYE_CARE_WHITE : (isSpecialRole ? renderColor : "rgba(200,200,200,0.4)")} 
                        fontSize="28" 
                        fontFamily="serif" 
                        fontWeight="900" 
                        className="select-none" 
                        style={{ 
                            textShadow: isActive 
                                ? `0 0 10px ${renderColor}` 
                                : (isSpecialRole ? '0 1px 1px rgba(0,0,0,0.8)' : '0 1px 2px rgba(0,0,0,0.9)'),
                            mixBlendMode: 'normal',
                            transition: 'all 0.5s'
                        }}
                        transform={`rotate(${-rotate} 0 0)`}
                    >
                        {label}
                    </text>
                </g>
            </svg>
        </div>
    );
});

export const StoveLighting = React.memo(({ activePlayerId, quality }: { activePlayerId: number; quality?: string }) => {
    if (quality === 'LOW') return null;
    return (
        <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[180%] h-[180%] opacity-15"
                 style={{
                     background: 'radial-gradient(circle at center, rgba(230,126,34,0.1) 0%, transparent 70%)',
                     mixBlendMode: 'screen'
                 }}></div>
        </div>
    );
});

export const TableBorderFlow = React.memo(({ quality }: { quality?: string }) => {
    if (quality === 'LOW') return null;
    return (
        <div className="absolute inset-0 pointer-events-none rounded-[inherit] overflow-hidden">
            <div className="absolute inset-0 shadow-[inset_0_0_80px_rgba(0,0,0,0.7)] z-10"></div>
            <div className="absolute inset-0 border border-white/5 opacity-15 z-20"></div>
        </div>
    );
});

// --- 晶体指针 (Crystal Needle) - 极致美化版 ---
const CrystalNeedle = React.memo(({ rotation, color }: { rotation: number, color: string }) => {
    // Increased size to w-64 (16rem) from w-48
    const gradId = `needleGrad-${color.replace('#', '')}`;
    
    return (
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center"
             style={{
                 transform: `rotate(${rotation}deg) translateZ(25px)`, 
                 transition: 'transform 1.0s cubic-bezier(0.19, 1, 0.22, 1)',
                 transformOrigin: 'center center'
             }}>
            {/* The Monolith: Enlarged & Sharpened */}
            <div className="relative w-64 h-64 origin-center drop-shadow-[0_15px_10px_rgba(0,0,0,0.5)]">
                <svg viewBox="0 0 100 100" className="w-full h-full overflow-visible">
                    <defs>
                        <linearGradient id={gradId} x1="0%" y1="0%" x2="100%" y2="0%">
                            <stop offset="0%" stopColor={color} stopOpacity="1" /> 
                            <stop offset="40%" stopColor={color} stopOpacity="0.8" /> 
                            <stop offset="100%" stopColor="#050505" stopOpacity="0.6" /> 
                        </linearGradient>
                        
                        <linearGradient id="needleEdge" x1="0%" y1="0%" x2="0%" y2="100%">
                            <stop offset="0%" stopColor="rgba(255,255,255,0.9)" />
                            <stop offset="50%" stopColor="rgba(255,255,255,0.2)" />
                            <stop offset="100%" stopColor="rgba(255,255,255,0)" />
                        </linearGradient>

                        <filter id="needleGlow">
                            <feGaussianBlur stdDeviation="1.5" in="SourceGraphic" result="blur" />
                            <feComposite in="SourceGraphic" in2="blur" operator="over" />
                        </filter>
                    </defs>
                    
                    <g transform="translate(50, 50) rotate(0)">
                        {/* Core Glow */}
                        <path d="M -18,0 L 0,-5 L 95,0 L 0,5 Z" fill={color} filter="url(#needleGlow)" opacity="0.4" mix-blend-mode="screen" />
                        
                        {/* Main Body - Sharper Dragon Spine Shape */}
                        <path d="M -18,0 L 0,-6 L 95,0 L 0,6 Z" fill={`url(#${gradId})`} stroke="none" />
                        
                        {/* Facet Shader (Dark Side) */}
                        <path d="M -18,0 L 0,6 L 95,0 Z" fill="#000" opacity="0.5" />
                        
                        {/* Edge Highlight - The "Blade" */}
                        <path d="M -18,0 L 95,0" stroke="url(#needleEdge)" strokeWidth="0.8" opacity="0.9" />
                        
                        {/* Central Hub Gem */}
                        <circle cx="-12" cy="0" r="4" fill="#1a1a1a" stroke={color} strokeWidth="1.5" />
                        <circle cx="-12" cy="0" r="1.5" fill="white" opacity="0.8" />
                    </g>
                </svg>
            </div>
        </div>
    );
});

export const Compass = React.memo(({ activePlayerId, bankerId, baiLaoId, tableCards = [], shape = 'circle', needleScale = 1.0 }: any) => {
    const { graphicsQuality } = useGameSettings();
    const isHighQuality = graphicsQuality === 'HIGH';

    const rotation = useMemo(() => {
        const angles = [90, 0, -90, 180]; 
        return angles[activePlayerId % 4] || 0;
    }, [activePlayerId]);

    const isBankerActive = activePlayerId === bankerId;
    const isBaiLaoActive = activePlayerId === baiLaoId;
    const playedPlayerIds = useMemo(() => new Set(tableCards.map((tc: any) => tc.playerId)), [tableCards]);

    const needleColor = useMemo(() => {
        if (isBankerActive) return BANKER_RED;
        if (isBaiLaoActive) return BAILAO_GREEN;
        // [MODIFIED] Default Needle Color is Obsidian instead of White
        return OBSIDIAN_NEEDLE; 
    }, [isBankerActive, isBaiLaoActive]);

    const getIdentityColor = (pid: number) => {
        if (pid === bankerId) return '#d91e18';
        if (pid === baiLaoId) return BAILAO_GREEN;
        return '#5c544d'; 
    };

    const getLabel = (pid: number, defaultDir: string) => {
        if (pid === bankerId) return '庄';
        if (pid === baiLaoId) return '百';
        return defaultDir;
    };

    if (shape === 'zen') {
        const rockSize = "24%"; 
        
        return (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none" style={{ transformStyle: 'preserve-3d' }}>
                {/* 盆景边缘容器 - [VISUAL] Darker Shell */}
                <div className="relative w-full h-full rounded-full shadow-[0_30px_70px_rgba(0,0,0,0.5),inset_0_5px_20px_rgba(0,0,0,0.8)] border-[4px] border-[#2b221f]"
                     style={{ 
                         background: '#1a1614', // Darker casing
                         transform: 'translateZ(2px)', 
                         transformStyle: 'preserve-3d'
                     }}>
                    
                    {/* 高级沙粒纹理定义 */}
                    {isHighQuality && (
                        <svg className="absolute inset-0 w-full h-full opacity-0">
                            <filter id="sandGrain">
                                <feTurbulence type="fractalNoise" baseFrequency="1.2" numOctaves="4" result="noise" />
                                <feColorMatrix type="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 0.35 0" in="noise" />
                                <feComposite operator="in" in2="SourceGraphic" />
                            </filter>
                        </svg>
                    )}

                    <div className="w-full h-full rounded-full relative overflow-hidden" 
                         style={{ transform: 'translateZ(1px)', transformStyle: 'preserve-3d' }}>
                         
                         {/* [枯山水白沙基底] - [VISUAL] Darkened to Twilight Sand */}
                         <div className="absolute inset-0" 
                              style={{ 
                                  background: 'radial-gradient(circle, #c8c2b5 0%, #a89f91 100%)', // Dimmer, greyer tones
                              }}>
                             
                             {/* 耙痕 (Rake Marks) - 增强对比度 */}
                             <div className="absolute inset-0 opacity-30 mix-blend-multiply"
                                  style={{
                                      backgroundImage: `repeating-radial-gradient(circle at center, #786f66 0, #786f66 2px, transparent 4px, transparent 16px)`
                                  }}></div>
                             
                             {/* 颗粒纹理 (Grain) - 增强物理感 */}
                             {isHighQuality && <div className="absolute inset-0 opacity-30 mix-blend-overlay" style={{ filter: 'url(#sandGrain)' }}></div>}
                             
                             {/* 内阴影 - 增强纵深 */}
                             <div className="absolute inset-0 shadow-[inset_0_0_60px_rgba(20,15,12,0.8)] pointer-events-none"></div>
                         </div>
                         
                         {/* 晶体指针 */}
                         <CrystalNeedle rotation={rotation} color={needleColor} />

                         {/* 嶙峋奇石 (绝世宝石) */}
                         <div className="absolute left-1/2 top-[8%]" 
                              style={{ width: rockSize, height: rockSize, marginLeft: `-${parseFloat(rockSize)/2}%`, marginTop: '-5%', transform: `translateZ(15px)` }}>
                             <GemStone type="mountain" label={getLabel(2, '北')} isActive={activePlayerId === 2} identityColor={getIdentityColor(2)} rotate={180} className="w-full h-full" />
                         </div>
                         
                         <div className="absolute left-1/2 bottom-[8%]" 
                              style={{ width: rockSize, height: rockSize, marginLeft: `-${parseFloat(rockSize)/2}%`, marginBottom: '-5%', transform: `translateZ(15px)` }}>
                             <GemStone type="flat" label={getLabel(0, '南')} isActive={activePlayerId === 0} identityColor={getIdentityColor(0)} rotate={0} className="w-full h-full" />
                         </div>
                         
                         <div className="absolute top-1/2 right-[8%]" 
                              style={{ width: rockSize, height: rockSize, marginTop: `-${parseFloat(rockSize)/2}%`, marginRight: '-5%', transform: `translateZ(15px)` }}>
                             <GemStone type="river_stone" label={getLabel(1, '东')} isActive={activePlayerId === 1} identityColor={getIdentityColor(1)} rotate={-90} className="w-full h-full" />
                         </div>
                         
                         <div className="absolute top-1/2 left-[8%]" 
                              style={{ width: rockSize, height: rockSize, marginTop: `-${parseFloat(rockSize)/2}%`, marginLeft: '-5%', transform: `translateZ(15px)` }}>
                             <GemStone type="sharp" label={getLabel(3, '西')} isActive={activePlayerId === 3} identityColor={getIdentityColor(3)} rotate={90} className="w-full h-full" />
                         </div>

                         {/* [New] 边缘光流进度条 (Edge Progress Arc) */}
                         <div className="absolute inset-0" style={{ transform: 'translateZ(2px)', transformStyle: 'preserve-3d' }}>
                            {[0, 1, 2, 3].map(pid => (
                                <SectorArc key={pid} sectorId={pid} 
                                    status={playedPlayerIds.has(pid) ? 'played' : 'idle'} 
                                    isBanker={pid === bankerId} isBaiLao={pid === baiLaoId} 
                                />
                            ))}
                         </div>

                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="relative w-full h-full rounded-full border-4 border-[#3e2b22] bg-black/40 flex items-center justify-center">
            <div className="absolute inset-0 flex items-center justify-center" style={{ transform: `rotate(${rotation}deg)`, transition: 'transform 0.8s' }}>
                <div className="w-1.5 h-[50%] bg-[#c5a059] rounded-full"></div>
            </div>
        </div>
    );
});
