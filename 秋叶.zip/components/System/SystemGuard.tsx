
import React from 'react';
import { usePerformanceObserver } from '../../hooks/usePerformanceObserver';
import { useGameSettings } from '../../hooks/useGameSettings';

export const SystemGuard: React.FC = () => {
    const { isDowngrading, fps } = usePerformanceObserver();
    const { graphicsQuality } = useGameSettings();

    // Only show FPS in dev or if very low
    const showFps = fps < 20 || process.env.NODE_ENV === 'development';

    return (
        <div className="fixed top-0 left-0 w-full h-0 z-[9999] pointer-events-none font-serif">
            {/* FPS Counter (Subtle) */}
            {showFps && (
                <div className={`absolute top-2 right-2 text-[9px] font-mono font-bold px-2 py-1 rounded bg-black/40 border border-white/10 ${fps < 24 ? 'text-red-500' : 'text-green-500/50'}`}>
                    FPS: {fps}
                </div>
            )}

            {/* Performance Downgrade Notification (Imperial Style) */}
            <div className={`absolute top-16 left-1/2 -translate-x-1/2 transition-all duration-700 transform ${isDowngrading ? 'translate-y-0 opacity-100' : '-translate-y-10 opacity-0'}`}>
                <div className="bg-[#1a0f0a]/90 backdrop-blur-md border border-[#c5a059]/60 px-6 py-3 rounded-sm shadow-[0_10px_30px_rgba(0,0,0,0.8)] flex items-center gap-4">
                    <div className="w-8 h-8 rounded-full border border-[#c5a059] flex items-center justify-center bg-black/50 text-[#c5a059] animate-spin-slow">
                        ⚙️
                    </div>
                    <div className="flex flex-col">
                        <span className="text-[#c5a059] text-xs font-bold tracking-widest">系统卫士 (System Guard)</span>
                        <span className="text-[#e8e4d9] text-[10px] opacity-90">
                            检测到帧率波动，已自动优化画质至 <span className="text-[#ffd700] font-bold">{graphicsQuality}</span>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    );
};
