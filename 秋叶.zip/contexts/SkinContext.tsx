
import React, { createContext, useContext, useState, ReactNode } from 'react';
import { ISkin } from '../types/skin';
import { ImperialSkin } from '../skins/imperialSkin';
import { ChristmasSkin } from '../skins/christmasSkin';
import { MingSkin } from '../skins/mingSkin';
import { TaoistSkin } from '../skins/taoistSkin';

// Registry of available skins - Moved outside to ensure stable reference
const AVAILABLE_SKINS: ISkin[] = [ImperialSkin, ChristmasSkin, MingSkin, TaoistSkin];

interface SkinContextType {
    skin: ISkin;
    setSkinId: (id: string) => void;
    availableSkins: ISkin[];
}

const defaultContext: SkinContextType = {
    skin: ImperialSkin,
    setSkinId: () => {},
    availableSkins: AVAILABLE_SKINS
};

// Export Context for Bridge
export const SkinContext = createContext<SkinContextType>(defaultContext);

export const SkinProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    // Determine initial skin from storage or default
    const [currentSkin, setCurrentSkin] = useState<ISkin>(() => {
        try {
            const savedId = localStorage.getItem('ma_diao_skin_id');
            return AVAILABLE_SKINS.find(s => s.id === savedId) || ImperialSkin;
        } catch (e) {
            return ImperialSkin;
        }
    });

    const setSkinId = (id: string) => {
        const found = AVAILABLE_SKINS.find(s => s.id === id);
        if (found) {
            setCurrentSkin(found);
            try {
                localStorage.setItem('ma_diao_skin_id', id);
            } catch (e) {
                console.warn("Could not save skin preference", e);
            }
        }
    };

    return (
        <SkinContext.Provider value={{ skin: currentSkin, setSkinId, availableSkins: AVAILABLE_SKINS }}>
            {children}
        </SkinContext.Provider>
    );
};

export const useSkin = () => useContext(SkinContext);
