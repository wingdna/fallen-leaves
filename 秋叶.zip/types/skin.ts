
import React from 'react';
import { Card, Suit, CardRank, SuitStatus, LeadingEffectType } from '../types';

export interface CardStyleProps {
    isSelected?: boolean;
    isSmall?: boolean;
    isTrick?: boolean;
    isHand?: boolean;
    isFaceDown?: boolean;
    isInverted?: boolean;
    isRotated?: boolean;
    isBanker?: boolean;
    isBaiLao?: boolean;
    isSuspectedBaiLao?: boolean;
    suitStatus?: SuitStatus;
    isForbidden?: boolean;
    isDisabled?: boolean;
    isDraggable?: boolean;
    isSuggested?: boolean;
    isWinner?: boolean;
    leadingEffect?: LeadingEffectType;
}

export interface CharacterAssets {
    bodyFront: React.FC<{ colorTheme?: string; quality?: 'HIGH' | 'MEDIUM' | 'LOW' }>; 
    bodySideLeft: React.FC<{ colorTheme?: string; quality?: 'HIGH' | 'MEDIUM' | 'LOW' }>; 
    bodySideRight: React.FC<{ colorTheme?: string; quality?: 'HIGH' | 'MEDIUM' | 'LOW' }>; 
    headOutline: string; 
    chairComponent: React.FC<{ position?: string; quality?: 'HIGH' | 'MEDIUM' | 'LOW' }>; 
}

export interface ISkin {
    id: string;
    name: string;
    description: string;

    // 1. Scene & Atmosphere
    layout: {
        backgroundClass: string; 
        atmosphereComponent: React.FC<{ quality?: 'HIGH' | 'MEDIUM' | 'LOW' }>; 
        
        // TABLE SURFACE CONFIG (New Layered System)
        tableSurfaceClass: string;      // Tailwind classes for shape (rounded), shadow, border
        tableBaseColor: string;         // Hex code for the SOLID opaque background (Layer 1)
        tableTexture?: string;          // CSS background-image string for grain/pattern (Layer 2)
        tableTextureSize?: string;      // background-size property
        tableBorderClass: string;       // Class for the 3D sides (thickness)
        tableReflectivity?: boolean;    // Enables mirror/patina layer
        EnvironmentalShadows?: React.FC; // Optional dynamic shadows layer
    };

    // 2. Card Visuals
    card: {
        getContainerClass: (props: CardStyleProps) => string;
        getMainColorClass: (color: string, isInverted?: boolean) => string;
        getPokerColorClass: (suit: Suit, isInverted?: boolean) => string;
        getBorderClass: (props: CardStyleProps) => string;
        getShadowClass: (props: CardStyleProps) => string;
        BackComponent: React.FC<{ isSmall?: boolean }>;
        EffectOverlay: React.FC<{ effect: LeadingEffectType }>;
    };

    // 3. HUD & UI Elements
    hud: {
        // Updated signature to support Role Styling
        avatarContainerClass: (isMyTurn: boolean, isBanker?: boolean, isBaiLao?: boolean) => string;
        buttonClass: (disabled: boolean) => string;
        modalOverlayClass: string;
        modalContentClass: string;
    };
    
    // 4. Effects
    lighting: {
        StoveLighting: React.FC<{ activePlayerId: number; spotlightPos?: {x: string, y: string} | null; quality?: string }>;
        TableBorderFlow: React.FC<{ 
            activePlayerId: number; 
            playedPlayerIds?: number[]; 
            bankerId?: number; 
            baiLaoId?: number; 
            isVertical?: boolean; 
            quality?: string; 
            shape?: 'rect' | 'circle' | 'zen';
        }>; 
    };

    // 5. Characters
    character: CharacterAssets;
}
